package mjt;

import java.io.File;
import com.ardor3d.image.Texture;
import com.ardor3d.renderer.Camera;
import com.ardor3d.scenegraph.extension.Skybox;
import com.ardor3d.util.TextureManager;

public class SkyBox
{
	static Skybox skybox=null;
	
	public static Skybox load(String name)
	{
		final String dir = "textures/skybox/" + name;

		Util.println("Loading skybox " + name);
		skybox = new Skybox("#sky_" + name, 10, 10, 10);
		final Texture north = TextureManager.load(dir + "1.jpg", Texture.MinificationFilter.BilinearNearestMipMap, true);
		final Texture south = TextureManager.load(dir + "3.jpg", Texture.MinificationFilter.BilinearNearestMipMap, true);
		final Texture east = TextureManager.load(dir + "2.jpg", Texture.MinificationFilter.BilinearNearestMipMap, true);
		final Texture west = TextureManager.load(dir + "4.jpg", Texture.MinificationFilter.BilinearNearestMipMap, true);
		final Texture up = TextureManager.load(dir + "6.jpg", Texture.MinificationFilter.BilinearNearestMipMap, true);
		final Texture down = TextureManager.load(dir + "5.jpg", Texture.MinificationFilter.BilinearNearestMipMap, true);

		skybox.setTexture(Skybox.Face.North, north);
		skybox.setTexture(Skybox.Face.West, west);
		skybox.setTexture(Skybox.Face.South, south);
		skybox.setTexture(Skybox.Face.East, east);
		skybox.setTexture(Skybox.Face.Up, up);
		skybox.setTexture(Skybox.Face.Down, down);

		return skybox;
	}

	public static boolean exists(String name)
	{
		final String dir = "textures/skybox/" + name;
		File f = new File(Settings.resourceString + Settings.dataDir + dir + "1.jpg");
		if (f.exists() == false)
			return false;

		return true;
	}
	
	public static void update()
	{
		if (skybox != null)
			skybox.setTranslation(Camera.getCurrentCamera().getLocation());
	}

}
