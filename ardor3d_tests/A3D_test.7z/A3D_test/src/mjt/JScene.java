/*
 * FILEFORMAT:
 * 
 * #VERSIO
 * float camspeed;
 * SKYBOX: skybox-nimi ilman p��tett�
 * 
 * CAMERA: camname;
 * vec3 pos;
 * vec3 rot;
 * 
 * LIGHT: lightname;
 * vec3 pos;
 * vec3 dir;
 * vec3 col;
 *
 * TERRAIN: heightmap-nimi
 * vec3 scale
 * 
 * ja joka objektille:
 * MODEL: objectName; // obun nimi joka n�kyy scene-listassa
 * string filename; // modelin tiedostonimi
 * vector3 pos,rot,scale; // paikka ja asento
 *    MESH: meshin nimi
 *    string userdata
 * 
*/
package mjt;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import mjt.game.Base;
import com.ardor3d.light.SpotLight;
import com.ardor3d.math.ColorRGBA;
import com.ardor3d.math.Vector3;
import com.ardor3d.renderer.Camera;
import com.ardor3d.scenegraph.Node;
import com.ardor3d.scenegraph.extension.Skybox;

public class JScene
{
	public List<Model> models = new ArrayList<Model>();
	public List<Camera> cameras = new ArrayList<Camera>();

	public float camSpeed = 5;
	public Terrain terrain;
	public Skybox skybox;
	public Node node;

	public JScene()
	{
	}

	public JScene(String fileName) throws Exception
	{
		load(fileName);
	}

	public Node load(String fileName) throws Exception
	{
		node = new Node(fileName);

		fileName = Settings.resourceString + Settings.dataDir + "scenes/" + fileName;

		String data = "";
		String line;
		try
		{
			BufferedReader input = new BufferedReader(new FileReader(fileName));
			while ((line = input.readLine()) != null)
			{
				data += line + "\n";
			}
			input.close();
		} catch (Exception e)
		{
			e.printStackTrace();
		}

		String lines[] = data.split("\n");
		data = "";
		if (lines[0].contains("#011") == false)
			throw new Exception("Wrong scene fileformat!");

		camSpeed = Float.parseFloat(lines[1]);

		for (int c = 2; c < lines.length; c++)
		{
			if (lines[c].contains("SKYBOX:"))
			{
				String v[] = lines[c].split(" ");
				skybox = SkyBox.load(v[1]);
				node.attachChild(skybox);
				continue;
			}

			if (lines[c].contains("TERRAIN:"))
			{
				terrain = new Terrain();
				String v[] = lines[c].split(" ");
				String tname = v[1];
				v = lines[c].split(" ");
				terrain.X_SCALE = Float.parseFloat(v[0]);
				terrain.Y_SCALE = Float.parseFloat(v[1]);
				terrain.Z_SCALE = Float.parseFloat(v[2]);

				terrain.load(tname, true, 1, 1);

				node.attachChild(terrain.getNode());
				continue;
			}

			if (lines[c].contains("CAMERA:"))
			{
				/*
				 * CAMERA: camname;
				 * vec3 pos;
				 * vec3 rot;
				 */
				String val[];
				c++; // skip camera's name
				val = lines[c++].split(" ");
				float x = Float.parseFloat(val[0]);
				float y = Float.parseFloat(val[1]);
				float z = Float.parseFloat(val[2]);
				val = lines[c].split(" ");
				float rx = Float.parseFloat(val[0]);
				float ry = Float.parseFloat(val[1]);
				float rz = Float.parseFloat(val[2]);
				Camera cam = new Camera();
				cam.setLocation(x, y, z);
				cam.setDirection(new Vector3(rx, ry, rz));
				cameras.add(cam);
				continue;
			}
			if (lines[c].contains("LIGHT:"))
			{
				/*
				 * LIGHT: lightname;
				 * vec3 pos;
				 * vec3 dir;
				 * vec3 col;
				 */
				String val[];
				val = lines[c++].split(" ");
				String lname = lines[1];
				val = lines[c++].split(" ");
				float x = Float.parseFloat(val[0]);
				float y = Float.parseFloat(val[1]);
				float z = Float.parseFloat(val[2]);
				val = lines[c++].split(" ");
				float rx = Float.parseFloat(val[0]);
				float ry = Float.parseFloat(val[1]);
				float rz = Float.parseFloat(val[2]);
				val = lines[c].split(" ");
				float r = Float.parseFloat(val[0]);
				float g = Float.parseFloat(val[1]);
				float b = Float.parseFloat(val[2]);

				SpotLight sl = new SpotLight();
				sl.setName(lname);
				sl.setLocation(x, y, z);
				sl.setDirection(new Vector3(rx, ry, rz));
				sl.setDiffuse(new ColorRGBA(r, g, b, 1.0f));
				sl.setAmbient(new ColorRGBA(0.5f, 0.5f, 0.5f, 1.0f));
				sl.setAngle(90);
				sl.setEnabled(true);

				Base.lightState.attach(sl);

				continue;
			}

			if (lines[c].contains("MODEL:"))
			{
				String v[] = lines[c++].split(" ");
				String name = v[1];
				String fname = lines[c++];

				String val[];
				val = lines[c++].split(" ");
				float x = Float.parseFloat(val[0]);
				float y = Float.parseFloat(val[1]);
				float z = Float.parseFloat(val[2]);

				val = lines[c++].split(" ");
				float rx = Float.parseFloat(val[0]);
				float ry = Float.parseFloat(val[1]);
				float rz = Float.parseFloat(val[2]);

				val = lines[c++].split(" ");
				float sx = Float.parseFloat(val[0]);
				float sy = Float.parseFloat(val[1]);
				float sz = Float.parseFloat(val[2]);

				Model model = new Model();
				model.load(fname);

				model.spatial.setName(name);
				model.setPosition(x, y, z);
				model.setRotation(rx, ry, rz);
				model.setScale(sx, sy, sz);

				// parse meshes
				while (c < lines.length && lines[c].length() > 0)
				{
					if (lines[c].startsWith("MESH:") == false)
					{
						c++;
						continue;
					}

					for (MeshInfo m : model.meshes)
					{
						val = lines[c].split(" ");
						m.meshName = val[1];
						
						c++;
						String userdata = "";
						m.userData ="";
						
						while (c < lines.length)
						{
							userdata = lines[c];
							if (userdata.startsWith("MESH:") || userdata.length() == 0)
								break;
							m.userData += " " + userdata;
							c++;
						}
					
					}
					
				}

				model.updateMaterial();
				node.attachChild(model.spatial);
				continue;
			}
		}
		return node;
	}
}
