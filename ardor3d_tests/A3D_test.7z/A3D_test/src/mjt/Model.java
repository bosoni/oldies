package mjt;

import java.io.BufferedReader;
import java.io.FileReader;
import java.net.URL;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.List;
import com.ardor3d.bounding.BoundingBox;
import com.ardor3d.bounding.BoundingSphere;
import com.ardor3d.extension.animation.skeletal.AnimationManager;
import com.ardor3d.extension.animation.skeletal.SkinnedMesh;
import com.ardor3d.extension.animation.skeletal.blendtree.ClipSource;
import com.ardor3d.extension.animation.skeletal.blendtree.SimpleAnimationApplier;
import com.ardor3d.extension.animation.skeletal.clip.AbstractAnimationChannel;
import com.ardor3d.extension.animation.skeletal.clip.AnimationClip;
import com.ardor3d.extension.animation.skeletal.state.SteadyState;
import com.ardor3d.extension.model.collada.jdom.ColladaImporter;
import com.ardor3d.extension.model.collada.jdom.data.ColladaStorage;
import com.ardor3d.extension.model.collada.jdom.data.SkinData;
import com.ardor3d.extension.model.md2.Md2Importer;
import com.ardor3d.extension.model.obj.ObjGeometryStore;
import com.ardor3d.extension.model.obj.ObjImporter;
import com.ardor3d.image.Texture;
import com.ardor3d.math.ColorRGBA;
import com.ardor3d.math.Matrix3;
import com.ardor3d.math.Vector3;
import com.ardor3d.renderer.state.CullState;
import com.ardor3d.renderer.state.CullState.Face;
import com.ardor3d.renderer.state.GLSLShaderObjectsState;
import com.ardor3d.renderer.state.MaterialState;
import com.ardor3d.renderer.state.RenderState.StateType;
import com.ardor3d.renderer.state.TextureState;
import com.ardor3d.renderer.state.ZBufferState;
import com.ardor3d.scenegraph.FloatBufferData;
import com.ardor3d.scenegraph.Mesh;
import com.ardor3d.scenegraph.Spatial;
import com.ardor3d.scenegraph.hint.CullHint;
import com.ardor3d.scenegraph.visitor.Visitor;
import com.ardor3d.util.TextureManager;
import com.ardor3d.util.resource.MultiFormatResourceLocator;
import com.ardor3d.util.resource.ResourceLocatorTool;
import com.google.common.collect.Lists;

public class Model
{
	final int LIGHTMAP = 1, NORMALMAP = 2, SPHEREMAP = 3;

	public Spatial spatial = null;
	AnimationManager manager;
	List<SkinData> skinDatas;
	ColladaStorage storage = null;

	public boolean animated = false, gpuskinned = false;
	public String fileName = "", presetFileName = "";

	public List<MeshInfo> meshes = Lists.newArrayList();

	public int updateBoundingsEveryXFrame = 0; // jos 0, niin p�ivitet��n bboxit joka framella updateAnim() metodissa
	private int updateBoundingsEveryXFrameCounter = 0;

	public Model()
	{
	}

	public Model(String fileName)
	{
		load(fileName);
	}

	public Model(String fileName, float x, float y, float z)
	{
		load(fileName);
		spatial.setTranslation(x, y, z);
	}

	public void dispose()
	{
		manager = null;
		spatial = null;
		if (skinDatas != null)
			skinDatas.clear();
		if (meshes != null)
			meshes.clear();
	}

	public void setPosition(float x, float y, float z)
	{
		spatial.setTranslation(x, y, z);
	}

	public void setRotation(float x, float y, float z)
	{
		spatial.setRotation(new Matrix3().fromAngles(Math.toRadians(x), Math.toRadians(y), Math.toRadians(z)));
	}

	public void setScale(float x, float y, float z)
	{
		final float MIN = 0.0001f;
		if (x < MIN)
			x = MIN;
		if (y < MIN)
			y = MIN;
		if (z < MIN)
			z = MIN;
		spatial.setScale(x, z, y);
	}

	public void setValues(float x, float y, float z, float rx, float ry, float rz, float sx, float sy, float sz)
	{
		setPosition(x, y, z);
		setRotation(rx, ry, rz);
		setScale(sx, sy, sz);
	}

	public Spatial load(String fileName)
	{
		Util.println("Loading " + fileName);

		fileName = fileName.replace('\\', '/');
		try
		{
			if (fileName.toLowerCase().contains(".dae"))
			{
				final ColladaImporter importer = new ColladaImporter();
				// importer.setTextureLocator(new
				// SimpleResourceLocator(ResourceLocatorTool.getClassPathResource(Model.class,
				// Settings.dataDir + "textures/")));
				storage = importer.load(fileName);
				spatial = storage.getScene();
				spatial.setRotation(new Matrix3().fromAngleAxis(Math.toRadians(-90), Vector3.UNIT_X));
				setupAnimations(null);
			} else if (fileName.toLowerCase().contains(".obj"))
			{
				final ObjGeometryStore storage = new ObjImporter().load(fileName);
				spatial = storage.getScene();
			} else if (fileName.toLowerCase().contains(".md2"))
			{
				final Md2Importer importer = new Md2Importer();
				importer.setTextureLocator(new MultiFormatResourceLocator(
						ResourceLocatorTool.getClassPathResource(Model.class, Settings.dataDir + "textures/"), ".dds", ".jpg", ".png", ".tga", ".pcx"));
				spatial = importer.load(fileName).getScene();
				spatial.setRotation(new Matrix3().fromAngleAxis(Math.toRadians(-90), Vector3.UNIT_X));
			}
			this.fileName = fileName;

			spatial.setTranslation(0, 0, 0);

			// luodaan meshInfot ja ladataan normalmapit, lightmapit, ..
			// automaattisesti jos l�ytyy
			spatial.acceptVisitor(new Visitor()
			{
				public void visit(final Spatial spatial)
				{
					if (spatial instanceof Mesh)
					{
						// luo uus mesh info
						MeshInfo mi = new MeshInfo();
						mi.meshName = spatial.getName();
						meshes.add(mi);

						Mesh m = (Mesh) spatial;
						final CullState cs = new CullState();
						cs.setCullFace(Face.Back);
						spatial.setRenderState(cs);
						m.setModelBound(new BoundingBox());

						final ZBufferState buf = new ZBufferState();
						buf.setEnabled(true);
						buf.setFunction(ZBufferState.TestFunction.LessThanOrEqualTo);
						m.setRenderState(buf);

						TextureState ts = (TextureState) spatial.getLocalRenderState(StateType.Texture);
						if (ts == null)
							ts = new TextureState();

						if (ts.getTexture() != null && ts.getTexture().getTextureKey() != null && ts.getTexture().getTextureKey().getSource() != null)
						{
							String texName = ts.getTexture().getTextureKey().getSource().getName();
							String name = texName.substring(texName.lastIndexOf('/') + 1); // tiedostonimi ilman hakemistoa

							String data = mi.userData;
							data += "\nTEXTURE: " + name + "\n";
							Util.println("   texture: " + name);

							if (GLSLLoader.isGLSLSupported() && Settings.notUseNormalMaps == false)
							{

								/*
								 * jos texture on esim brick.png, niin : NormalMap+specular : brick_nms.png (eka etit��n t�t�, ja jos l�ytyy, k�ytet��n eri
								 * shaderia mit� normal mappingiin) NormalMap : brick_nm.png (ellei ylemp�� l�ydy, etit��n pelkk�� normal mappia)
								 */
								// lataa meshin texturen normalmap jos l�ytyy

								name = texName.substring(texName.lastIndexOf('/') + 1, texName.lastIndexOf('.')); // tiedostonimi ilman hakemistoa ja p��tett�
								URL url = Model.class.getClassLoader().getResource(Settings.dataDir + "textures/" + name + "_nms.png"); // normalmap + specular alpha-kanavassa
								if (url != null) // l�ytyyk� nms
								{
									Texture tex = TextureManager.load(url.getFile(), Texture.MinificationFilter.Trilinear, true);
									ts.setTexture(tex, NORMALMAP);
									data += "\nNORMALMAP: " + name + "_nms.png";
									data += "\nSHADER: basic_normalmap_specular.glsl\n";
									Util.println("   normalmap+specular: " + name + "_nms.png" + "   shader: basic_normalmap_specular.glsl");
								} else
								// ellei niin eti pelkk�� normalmappia
								{
									url = Model.class.getClassLoader().getResource(Settings.dataDir + "textures/" + name + "_nm.png"); // normalmap
									if (url != null)
									{
										Texture tex = TextureManager.load(url.getFile(), Texture.MinificationFilter.Trilinear, true);
										ts.setTexture(tex, NORMALMAP);
										data += "\nNORMALMAP: " + name + "_nm.png";
										data += "\nSHADER: basic_normalmap.glsl\n";
										Util.println("   normalmap: " + name + "_nm.png" + "   shader: basic_normalmap.glsl");
									}
								}
							}
							mi.userData = data;
						}

						// lataa meshille lightmap/AOmap jos l�ytyy
						String name = m.getName();
						if (name.contains("["))
							name = name.substring(0, m.getName().indexOf('[')); // ota nimi ennen [ merkki� (siit� alkaa materiaalinimi)

						URL url = Model.class.getClassLoader().getResource(Settings.dataDir + "textures/" + name + "_lm.png");
						if (url != null) // l�ytyyk� lightmap
						{
							Texture tex = TextureManager.load(url.getFile(), Texture.MinificationFilter.Trilinear, true);
							ts.setTexture(tex, LIGHTMAP);
							Util.println("   lightmap: " + name + "_lm.png");

						} else
						// ellei niin tsekkaa l�ytyyk� ao map
						{
							url = Model.class.getClassLoader().getResource(Settings.dataDir + "textures/" + name + "_ao.png");
							if (url != null)
							{
								Texture tex = TextureManager.load(url.getFile(), Texture.MinificationFilter.Trilinear, true);
								ts.setTexture(tex, LIGHTMAP);
								Util.println("   AOmap: " + name + "_lm.png");
							}
						}
						m.setRenderState(ts);
					}
				}
			}, false);

			Util.println("OK.");

		} catch (Exception e)
		{
			e.printStackTrace();
		}

		updateMaterial();

		return spatial;
	}

	public void changeBoundingVolume(final String meshName, final boolean bbox)
	{
		spatial.acceptVisitor(new Visitor()
		{
			public void visit(final Spatial spatial)
			{
				if (spatial instanceof Mesh)
				{
					if (spatial.getName().equals(meshName))
						if (bbox)
							((Mesh) spatial).setModelBound(new BoundingBox());
						else
							((Mesh) spatial).setModelBound(new BoundingSphere());
				}
			}
		}, false);
	}

	// kutsu aina kun materiaalia muutettu (texture tai v�ri vaihdettu jne)
	public void updateMaterial()
	{
		// k�y meshit l�pi ja asettaa oikeat materiaalit ja tilat (l�ytyy userdatasta)
		spatial.acceptVisitor(new Visitor()
		{
			int c=0;
			public void visit(final Spatial spatial)
			{
				if (spatial instanceof Mesh)
				{
					Mesh m = (Mesh) spatial;
					
					//MeshInfo mi = findMeshInfo(m.getName());
					//if (mi == null) return;

					MeshInfo mi = meshes.get(c++);

					final CullState cs = new CullState();
					cs.setCullFace(Face.Back);
					spatial.setRenderState(cs);

					final MaterialState ms = new MaterialState();
					// ms.setColorMaterial(ColorMaterial.Diffuse);

					TextureState ts = (TextureState) spatial.getLocalRenderState(StateType.Texture);
					if (ts == null)
						ts = new TextureState();

					String data = mi.userData;
					data = data.replace('\0', ' ');
					data = data.replace('\n', ' ');
					data = data.replace('\r', ' ');
					String strs[] = data.split(" ");

					for (int c = 0; c < strs.length; c++)
					{
						String s = strs[c];
						if (s.contains("PHYSICOBJ"))
						{
							float mass = Float.parseFloat(strs[c + 1]);
							mi.physicsObj = true;
							mi.mass = mass;
							c++;
						} else if (s.contains("COLOR:"))
						{
							int R = Integer.parseInt(strs[c + 1]), G = Integer.parseInt(strs[c + 2]), B = Integer.parseInt(strs[c + 3]), A = Integer
									.parseInt(strs[c + 4]);
							ColorRGBA color = new ColorRGBA((float) R / 256f, (float) G / 256f, (float) B / 256f, (float) A / 256f);
							ms.setDiffuse(color);
							// ms.setAmbient(color);
							ms.setAmbient(ColorRGBA.DARK_GRAY);
							c += 4;
						} else if (s.contains("SHADER:"))
						{
							if (GLSLLoader.isGLSLSupported() == false)
								continue;

							if (strs[c + 1].equals("-none-"))
							{
								if (mi.compiledShader.equals("") == false) // poistaa shaderin k�yt�st�
								{
									mi.compiledShader = "";
									m.setRenderState(new GLSLShaderObjectsState());
									// TODO fix t�� kyl poistaa shaderin mutta
									// sit saa typer�n warningin ettei ole
									// shadereita.
									// kenties l�ytyy parempi tapa poistaa
									// shader?
								}
								continue;
							}

							if (mi.compiledShader.equals(strs[c + 1])) // jos shaderi jo k��nnetty, ei tartte k��nt�� uudelleen
								continue;

							mi.shader = new GLSLShaderObjectsState();
							mi.shader.setEnabled(true);
							try
							{
								GLSLLoader sh = new GLSLLoader(strs[c + 1]);
								mi.compiledShader = strs[c + 1];
								c++;

								mi.shader.setVertexShader(sh.readVertexShader());
								mi.shader.setFragmentShader(sh.readFragmentShader());
								if (sh.frag.contains("colorMap"))
									mi.shader.setUniform("colorMap", 0);
								if (sh.frag.contains("normalMap"))
									mi.shader.setUniform("normalMap", NORMALMAP);
								if (sh.frag.contains("sphereMap"))
									mi.shader.setUniform("sphereMap", SPHEREMAP);
								m.setRenderState(mi.shader);

								// TODO fix: EI TOIMI, shaderi h�vitt�� meshin
								if (sh.isGPUSkinned() && spatial instanceof SkinnedMesh)
								{
									Util.println("debug: using gpuskinning");

									gpuskinned = true;
									// animoidulle obulle
									final SkinnedMesh skinnedMesh = (SkinnedMesh) spatial;
									skinnedMesh.setGPUShader(mi.shader);
									skinnedMesh.setGpuAttributeSize(3);
									skinnedMesh.setGpuUseMatrixAttribute(true);
									skinnedMesh.setUseGPU(true);
								}
							} catch (Exception e)
							{
								Util.println(e.toString());
							}
						} else if (s.contains("TEXTURE:"))
						{
							if (strs[c + 1].contains("-none-"))
								continue;
							Texture tex = TextureManager.load(strs[c + 1], Texture.MinificationFilter.Trilinear, true);
							c++;
							ts.setTexture(tex, 0); // korvaa alkup tex
						} else if (s.contains("NORMALMAP:") && Settings.notUseNormalMaps == false)
						{
							if (strs[c + 1].contains("-none-"))
								continue;
							if (GLSLLoader.isGLSLSupported() == false)
								continue;
							Texture tex = TextureManager.load(strs[c + 1], Texture.MinificationFilter.Trilinear, true);
							c++;
							m.getMeshData().copyTextureCoordinates(0, NORMALMAP, 1f);
							ts.setTexture(tex, NORMALMAP);
						} else if (s.contains("SPHEREMAP:"))
						{
							if (strs[c + 1].contains("-none-"))
								continue;
							Texture tex = TextureManager.load(strs[c + 1], Texture.MinificationFilter.Trilinear, true);
							c++;
							ts.setTexture(tex, SPHEREMAP);

							m.getMeshData().copyTextureCoordinates(0, SPHEREMAP, 1f);
							// TODO spheremapissa ei tietenk�� voida k�ytt��
							// normaaleita UV-arvoja vaan
							// pit�� laskea jotenki muuten. onnistuuko
							// fixed-pipeliness�? shaderilla sit ainaki.

							// TSEKKAA:::: http://www.ozone3d.net/tutorials/glsl_texturing_p04.php
						}
					}

					if (data.contains("BOUNDINGBOX"))
						changeBoundingVolume(spatial.getName(), true);
					else
						changeBoundingVolume(spatial.getName(), false);

					// note: vain ekalla kerralla objektin texture n�kyy oikein,
					// kun painaa uvscalen p��lle (koska alkup uv arvoja ei
					// s�ilytet� eik� n�it� p�ivitet� kun skaalataan).
					// * Oikea tapa on ensin skaalata meshit _lopulliseen_
					// kokoonsa, sitten klikata scaleuv p��lle jos haluaa *
					if (data.contains("SCALEUV"))
					{
						List<FloatBufferData> uvlist = ((Mesh) spatial).getMeshData().getTextureCoords();
						FloatBuffer uv = uvlist.get(0).getBuffer();
						for (int q = 0; q < uv.capacity() - 1; q += 2)
						{
							uv.put(q, uv.get(q) * mi.uScale);
							uv.put(q + 1, uv.get(q + 1) * mi.vScale);
						}
						mi.uScale = mi.vScale = 1; // ettei skaalata en�� uudelleen
					}

					if (data.contains("VISIBLE"))
						spatial.getSceneHints().setCullHint(CullHint.Dynamic);
					else
						spatial.getSceneHints().setCullHint(CullHint.Always);

					if (data.contains("DYNAMICREFLECTIONS") && Settings.notUseDynamicReflection == false)
						; // TODO

					if (data.contains("CASTSHADOW"))
						spatial.getSceneHints().setCastsShadows(true);
					else
						spatial.getSceneHints().setCastsShadows(false);

					m.setRenderState(ms);
					m.setRenderState(ts);
				}
			}
		}, false);
	}

	public void setupAnimations(List<AnimClip> anims)
	{
		// Check if there is any animationdata in the file
		if (storage == null || storage.getAnimationChannels().isEmpty() || storage.getSkins().isEmpty())
		{
			animated = false;
			return;
		}
		animated = true;
		skinDatas = storage.getSkins();

		// Make our manager
		manager = new AnimationManager(Util.timer, skinDatas.get(0).getPose());

		AnimationClip clip = null;

		if (anims == null)
		{
			clip = storage.extractChannelsAsClip("clip"); // ota collada-tiedostosta koko animaatio clippiin

			// Set some clip instance specific data - repeat, time scaling
			manager.getClipInstance(clip).setLoopCount(Integer.MAX_VALUE);

			// Add our "applier logic".
			manager.setApplier(new SimpleAnimationApplier());

			// Add our clip as a state in the default animation layer
			final SteadyState animState = new SteadyState("anim_state");
			animState.setSourceTree(new ClipSource(clip, manager));
			manager.getBaseAnimationLayer().addSteadyState(animState);

			// Set the current animation state on default layer
			manager.getBaseAnimationLayer().setCurrentState("anim_state", true);
		} else
		{
			// luodaan erilliset clipit
			List<AbstractAnimationChannel> animChannels = storage.getAnimationChannels();
			for (int q = 0; q < anims.size(); q++)
			{
				clip = new AnimationClip(anims.get(q).name);
				anims.get(q).clip = clip;

				for (int ch = 0; ch < animChannels.size(); ch++)
					clip.addChannel(animChannels.get(q).getSubchannelBySample(animChannels.get(q).getChannelName(), anims.get(q).start, anims.get(q).end));

				// Set some clip instance specific data - repeat, time scaling
				manager.getClipInstance(clip).setLoopCount(Integer.MAX_VALUE);

				// Add our "applier logic".
				manager.setApplier(new SimpleAnimationApplier());

				// Add our clip as a state in the default animation layer
				final SteadyState animState = new SteadyState("anim_state" + q);
				animState.setSourceTree(new ClipSource(clip, manager));
				manager.getBaseAnimationLayer().addSteadyState(animState);

				// Set the current animation state on default layer
				manager.getBaseAnimationLayer().setCurrentState("anim_state" + q, true);

				// TODO ei ehk� toimi iha n�in
			}
		}

	}

	public void updateAnim()
	{
		if (manager != null)
		{
			manager.update();

			if (updateBoundingsEveryXFrame == 0 || (updateBoundingsEveryXFrameCounter++ % updateBoundingsEveryXFrame == 0))
				spatial.acceptVisitor(new Visitor()
				{
					public void visit(final Spatial spatial)
					{
						if (spatial instanceof Mesh)
						{
							Mesh m = (Mesh) spatial;
							m.updateModelBound();
						}
					}
				}, false);
		}
	}
}
