package mjt;

import com.ardor3d.extension.animation.skeletal.clip.AnimationClip;

public class AnimClip
{
	AnimationClip clip;
	public String name;
	public int start, end;
}
