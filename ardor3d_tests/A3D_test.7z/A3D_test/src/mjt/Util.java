package mjt;

import com.ardor3d.util.Timer;

public class Util
{
	public final static Timer timer = new Timer();

	public static void println(String str)
	{
		if (Settings.DEBUG)
			System.out.println(str);
	}
}
