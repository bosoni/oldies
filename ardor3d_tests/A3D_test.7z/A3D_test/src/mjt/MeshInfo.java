package mjt;

import com.ardor3d.renderer.state.GLSLShaderObjectsState;

public class MeshInfo
{
	public String meshName = "";
	public String userData = "BOUNDINGBOX VISIBLE BLOCK CASTSHADOW";
	public String compiledShader = "";
	public GLSLShaderObjectsState shader = null;

	public float uScale = 1, vScale = 1;

	// fysiikkamoottoria varten:
	public float mass = 0;
	public boolean physicsObj = false;
}
