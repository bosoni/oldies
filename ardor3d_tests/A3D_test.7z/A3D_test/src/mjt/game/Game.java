package mjt.game;

import mjt.JScene;
import mjt.SkyBox;
import mjt.Terrain;
import mjt.Util;
import com.ardor3d.framework.DisplaySettings;
import com.ardor3d.light.DirectionalLight;
import com.ardor3d.math.ColorRGBA;
import com.ardor3d.math.MathUtils;
import com.ardor3d.math.Matrix3;
import com.ardor3d.math.Vector3;
import com.ardor3d.renderer.Camera;
import com.ardor3d.renderer.Renderer;
import com.ardor3d.renderer.RendererCallable;
import com.ardor3d.scenegraph.Spatial;
import com.ardor3d.scenegraph.controller.SpatialController;
import com.ardor3d.scenegraph.extension.Skybox;
import com.ardor3d.scenegraph.shape.Box;
import com.ardor3d.util.GameTaskQueueManager;

public class Game extends Base
{
	public Game(DisplaySettings settings, String name)
	{
		super(settings, name);
	}

	@Override
	protected void initialize()
	{
		try
		{
			
			JScene scene=new JScene("skene.jsce");
			rootNode.attachChild(scene.node);
			
			if(scene.cameras.size()>0)
			{
				//Camera.getCurrentCamera(). ;
				// TODO  aseta skenen camera
				// mutta getCurrentCamera == NULL
				
			}
			

		} catch (final Exception e)
		{
			e.printStackTrace();
			Util.println(e.toString());
		}

	}

	@Override
	protected void update(final double tpf)
	{
	
	}

	@Override
	protected void render(final Renderer renderer)
	{
		SkyBox.update();
		
		rootNode.onDraw(renderer);
		renderer.renderBuckets();
		uiNode.onDraw(renderer);
	}

}
