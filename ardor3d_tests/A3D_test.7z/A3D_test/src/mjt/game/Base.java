package mjt.game;

import java.net.URISyntaxException;
import mjt.Settings;
import mjt.Util;
import com.ardor3d.framework.DisplaySettings;
import com.ardor3d.framework.FrameHandler;
import com.ardor3d.framework.Scene;
import com.ardor3d.framework.Updater;
import com.ardor3d.framework.lwjgl.LwjglCanvas;
import com.ardor3d.framework.lwjgl.LwjglCanvasRenderer;
import com.ardor3d.image.util.AWTImageLoader;
import com.ardor3d.input.PhysicalLayer;
import com.ardor3d.input.control.FirstPersonControl;
import com.ardor3d.input.logical.LogicalLayer;
import com.ardor3d.input.lwjgl.LwjglControllerWrapper;
import com.ardor3d.input.lwjgl.LwjglKeyboardWrapper;
import com.ardor3d.input.lwjgl.LwjglMouseManager;
import com.ardor3d.input.lwjgl.LwjglMouseWrapper;
import com.ardor3d.intersection.PickResults;
import com.ardor3d.math.ColorRGBA;
import com.ardor3d.math.Ray3;
import com.ardor3d.math.Vector3;
import com.ardor3d.renderer.Renderer;
import com.ardor3d.renderer.TextureRendererFactory;
import com.ardor3d.renderer.lwjgl.LwjglTextureRendererProvider;
import com.ardor3d.renderer.state.LightState;
import com.ardor3d.renderer.state.ZBufferState;
import com.ardor3d.scenegraph.Node;
import com.ardor3d.ui.text.BasicText;
import com.ardor3d.util.Constants;
import com.ardor3d.util.ContextGarbageCollector;
import com.ardor3d.util.GameTaskQueue;
import com.ardor3d.util.GameTaskQueueManager;
import com.ardor3d.util.ReadOnlyTimer;
import com.ardor3d.util.resource.ResourceLocatorTool;
import com.ardor3d.util.resource.SimpleResourceLocator;
import com.ardor3d.util.stat.MultiStatSample;
import com.ardor3d.util.stat.StatCollector;
import com.ardor3d.util.stat.StatListener;
import com.ardor3d.util.stat.StatType;
import com.ardor3d.util.stat.StatValue;

public class Base implements Runnable, Updater, Scene
{
	protected final Node rootNode;
	protected final Node uiNode;
	protected final BasicText frameRateLabel;
	public static LightState lightState;
	FirstPersonControl fpsCam;

	final FrameHandler frameHandler = new FrameHandler(Util.timer);
	final DisplaySettings settings;
	final LwjglCanvas _canvas;
	final PhysicalLayer physicalLayer;
	final LwjglMouseManager mouseManager;
	final LogicalLayer logicalLayer = new LogicalLayer();
	boolean exit;

	public Base(DisplaySettings settings, String name)
	{
		this.settings = settings;

		// setup a node to act as root of our scene
		rootNode = new Node("root");
		// setup a node to act as root of our hud
		uiNode = new Node("UI");

		// add a text label
		frameRateLabel = BasicText.createDefaultTextLabel("fpsLabel", "test");
		frameRateLabel.setTranslation(0, 0, 0);
		frameRateLabel.setTextColor(ColorRGBA.WHITE);
		uiNode.attachChild(frameRateLabel);

		// add z-depth state
		final ZBufferState zbuff = new ZBufferState();
		zbuff.setFunction(ZBufferState.TestFunction.LessThanOrEqualTo);
		rootNode.setRenderState(zbuff);

		lightState = new LightState();
		lightState.setTwoSidedLighting(false);
		rootNode.setRenderState(lightState);
		registerInputTriggers();

		LwjglCanvasRenderer canvasRenderer = new LwjglCanvasRenderer(this);
		_canvas = new LwjglCanvas(settings, canvasRenderer);
		physicalLayer = new PhysicalLayer(new LwjglKeyboardWrapper(), new LwjglMouseWrapper(), new LwjglControllerWrapper(), (LwjglCanvas) _canvas);
		mouseManager = new LwjglMouseManager();
		TextureRendererFactory.INSTANCE.setProvider(new LwjglTextureRendererProvider());

		logicalLayer.registerInput(_canvas, physicalLayer);

		frameHandler.addUpdater(this);
		frameHandler.addCanvas(_canvas);

		_canvas.setTitle(name);

		AWTImageLoader.registerLoader();
		try
		{
			ResourceLocatorTool.addResourceLocator(ResourceLocatorTool.TYPE_MODEL,
					new SimpleResourceLocator(ResourceLocatorTool.getClassPathResource(Base.class, Settings.dataDir + "models/")));
			ResourceLocatorTool.addResourceLocator(ResourceLocatorTool.TYPE_TEXTURE,
					new SimpleResourceLocator(ResourceLocatorTool.getClassPathResource(Base.class, Settings.dataDir + "textures/")));
			ResourceLocatorTool.addResourceLocator(ResourceLocatorTool.TYPE_SHADER,
					new SimpleResourceLocator(ResourceLocatorTool.getClassPathResource(Base.class, Settings.dataDir + "shaders/")));
		} catch (final URISyntaxException ex)
		{
			ex.printStackTrace();
		}

		// DEBUG
		if (Settings.DEBUG)
			StatCollector.addStatListener(new StatListener()
			{
				@Override
				public void statsUpdated()
				{
					final MultiStatSample stats = StatCollector.lastStats();
					StatValue triStatValue = stats.getStatValue(StatType.STAT_TRIANGLE_COUNT);
					StatValue frameStatValue = stats.getStatValue(StatType.STAT_FRAMES);
					if (triStatValue != null && frameStatValue != null)
					{
						// Frames drawn in the last sample (1000 ms = 1 sec)
						int fps = (int) frameStatValue.getAccumulatedValue();
						// Triangle count in one frame of the last sample
						int tris = (int) triStatValue.getAccumulatedValue() / fps;

						Util.println("DEBUG: FPS=" + fps + "  TRIS=" + tris);
					}
				}
			});

	}

	public void run()
	{
		try
		{
			frameHandler.init();

			while (!exit)
			{
				frameHandler.updateFrame();
				Thread.yield();
			}
			// grab the graphics context so cleanup will work out.
			_canvas.getCanvasRenderer().makeCurrentContext();
			ContextGarbageCollector.doFinalCleanup(_canvas.getCanvasRenderer().getRenderer());
			_canvas.close();
		} catch (final Throwable t)
		{
			Util.println("Throwable caught in MainThread - exiting");
			t.printStackTrace(System.err);
		}
	}

	public void update(ReadOnlyTimer timer)
	{
		if (_canvas.isClosing())
			exit = true;

		// update stats, if enabled.
		if (Constants.stats && Settings.DEBUG)
			StatCollector.update();

		logicalLayer.checkTriggers(timer.getTimePerFrame());

		// Execute updateQueue item
		GameTaskQueueManager.getManager(_canvas.getCanvasRenderer().getRenderContext()).getQueue(GameTaskQueue.UPDATE).execute();

		update(timer.getTimePerFrame());

		// Update controllers/render states/transforms/bounds for rootNode.
		rootNode.updateGeometricState(timer.getTimePerFrame(), true);
	}

	public PickResults doPick(Ray3 pickRay)
	{
		return null;
	}

	public boolean renderUnto(Renderer renderer)
	{
		GameTaskQueueManager.getManager(_canvas.getCanvasRenderer().getRenderContext()).getQueue(GameTaskQueue.RENDER).execute(renderer);

		// Clean up card garbage such as textures, vbos, etc.
		ContextGarbageCollector.doRuntimeCleanup(renderer);

		// Draw the rootNode and all its children.
		if (!_canvas.isClosing())
		{
			render(renderer);
			renderer.draw(rootNode);
			return true;
		} else
			return false;
	}

	protected void registerInputTriggers()
	{
		fpsCam = FirstPersonControl.setupTriggers(logicalLayer, Vector3.UNIT_Y, false);
		fpsCam.setMoveSpeed(50);
		
		
	}

	@Override
	public void init()
	{
		initialize();
	}

	protected void initialize()
	{
	}

	protected void update(final double tpf)
	{

	}

	protected void render(final Renderer renderer)
	{
	}

}
