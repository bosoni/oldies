package mjt.game;

import mjt.Settings;

import com.ardor3d.framework.DisplaySettings;

public class Main
{
	public static void main(String[] args)
	{
		if (Settings.DEBUG)
			System.setProperty("ardor3d.stats", "1"); // debug

		DisplaySettings settings = new DisplaySettings(1024, 768, 24, 0, 0, 8, 0, 0, false, false);

		Base main = new Game(settings, "Test");
		//new Thread(main).start();
		main.run();
	}
}
