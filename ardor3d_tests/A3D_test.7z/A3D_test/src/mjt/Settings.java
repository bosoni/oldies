package mjt;

public final class Settings
{
	public static final boolean DEBUG = true;

	public static String dataDir = "media/";
	public static String resourceString = "resources/";

	public static boolean notUseShaders = false;
	public static boolean notUseNormalMaps = false;
	public static boolean notUseDynamicReflection = false;
	public static boolean notUsePostEffects = false;
}
