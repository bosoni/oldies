package mjt;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import com.ardor3d.renderer.ContextCapabilities;
import com.ardor3d.renderer.ContextManager;
import com.ardor3d.util.resource.ResourceLocatorTool;

public class GLSLLoader
{
	String data = "";
	String vert = "";
	String frag = "";

	public GLSLLoader(String fileName) throws Exception
	{
		if (isGLSLSupported() == false)
			return;

		Util.println("Load shader: " + fileName);
		InputStream is = ResourceLocatorTool.getClassPathResourceAsStream(GLSLLoader.class, "media/shaders/" + fileName);
		if (is == null)
		{
			System.out.println(" Cannot load " + fileName);
			return;
		}
		Writer writer = new StringWriter();
		char[] buffer = new char[1024];
		try
		{
			Reader reader = new BufferedReader(new InputStreamReader(is)); // , "UTF-8"));
			int n;
			while ((n = reader.read(buffer)) != -1)
			{
				writer.write(buffer, 0, n);
			}
		} finally
		{
			is.close();
		}
		data = writer.toString();

		int start = data.indexOf("[VERTEX_SHADER]") + "[VERTEX_SHADER]".length();
		int end = data.indexOf("[FRAGMENT_SHADER]");
		vert = data.substring(start, end);

		start = data.indexOf("[FRAGMENT_SHADER]") + "[FRAGMENT_SHADER]".length();
		end = data.length();
		frag = data.substring(start, end);
	}

	InputStream readVertexShader()
	{
		return new ByteArrayInputStream(vert.getBytes());
	}

	InputStream readFragmentShader()
	{
		return new ByteArrayInputStream(frag.getBytes());
	}

	boolean isGPUSkinned()
	{
		return vert.contains("JointPalette");
	}

	public static boolean isGLSLSupported()
	{
		final ContextCapabilities caps = ContextManager.getCurrentContext().getCapabilities();
		return caps.isGLSLSupported() && Settings.notUseShaders == false;
	}
}
