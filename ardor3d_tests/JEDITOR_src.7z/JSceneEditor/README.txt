JSceneEditor:

If you are using this in IDE, change DEBUG to true in Main. 

If you export jar, change DEBUG to false.

Exporting:

* in eclipse, File - Export...  and Runnable JAR file. 
 -> export to JEDITOR/ directory
 (copy lwjgl native-libraries to that same directory)
 
* you can delete media/ directory in .jar file (datas are not loaded from jar)


! needed libraries are in JEDITOR_bin.7z !
! this packet doesnt include models and textures. check JEDITOR_bin packet !
