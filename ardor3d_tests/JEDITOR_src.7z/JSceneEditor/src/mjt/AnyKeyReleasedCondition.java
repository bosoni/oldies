package mjt;

import com.ardor3d.input.InputState;
import com.ardor3d.input.logical.TwoInputStates;
import com.google.common.base.Predicate;

/**
 * Applicable whenever 'any' key has been released.
 */
public class AnyKeyReleasedCondition implements Predicate<TwoInputStates> {
    public boolean apply(final TwoInputStates twoInputStates) {
        final InputState currentState = twoInputStates.getCurrent();
        final InputState previousState = twoInputStates.getPrevious();

        return !currentState.getKeyboardState().getKeysReleasedSince(previousState.getKeyboardState()).isEmpty();
    }
}
