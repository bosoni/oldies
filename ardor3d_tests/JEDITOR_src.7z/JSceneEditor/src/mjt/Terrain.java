package mjt;

import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.io.File;
import java.io.IOException;
import java.nio.FloatBuffer;
import javax.imageio.ImageIO;
import mjt.editor.Main;
import com.ardor3d.bounding.BoundingBox;
import com.ardor3d.image.Texture;
import com.ardor3d.math.Vector3;
import com.ardor3d.renderer.IndexMode;
import com.ardor3d.renderer.state.CullState;
import com.ardor3d.renderer.state.CullState.Face;
import com.ardor3d.renderer.state.TextureState;
import com.ardor3d.renderer.state.ZBufferState;
import com.ardor3d.scenegraph.Mesh;
import com.ardor3d.scenegraph.MeshData;
import com.ardor3d.scenegraph.Node;
import com.ardor3d.util.TextureManager;
import com.ardor3d.util.geom.BufferUtils;

public class Terrain
{
	private int mapWidth = 0, mapHeight = 0;
	private int[] mapImg = null;
	private Node terrain;
	private Mesh area[][];

	private final float X_SCALE = 1f, Z_SCALE = 1f;
	private final float Y_SCALE = 1f; // height scale

	public Node getNode()
	{
		return terrain;
	}

	public float getY(float px, float pz)
	{
		int x = (int) (px / X_SCALE);
		int z = (int) (pz / Z_SCALE);

		if (x < 0)
			x = -x;
		if (z < 0)
			z = -z;

		float height;
		float v1, v2, v3;
		float xf, zf;

		v1 = mapGetHeight(x, z);
		v2 = mapGetHeight(x + 1, z);
		v3 = mapGetHeight(x, z + 1);

		xf = (px - x * X_SCALE) / X_SCALE;
		zf = (pz - z * Z_SCALE) / Z_SCALE;

		height = v1 + xf * (v2 - v1) + zf * (v3 - v1);
		return height * Y_SCALE;
	}

	float mapGetHeight(int x, int y)
	{
		x %= mapWidth;
		y %= mapHeight;
		return (float) mapImg[y * mapWidth + x];
	}

	public void load(String fileName, boolean calcY_UV, float scaleU, float scaleV) throws IOException
	{
		Main.println("Loading terrain..");

		// load heightmap
		BufferedImage image = null;
		image = ImageIO.read(new File(Settings.resourceString + Settings.dataDir + "textures/" + fileName));

		Raster r = image.getRaster();
		mapImg = r.getPixels(0, 0, image.getWidth(), image.getHeight(), mapImg);
		mapWidth = image.getWidth();
		mapHeight = image.getHeight();
		float[] normals = calculateNormals();

		terrain = new Node("#terrain");
		final CullState cs = new CullState();
		cs.setCullFace(Face.Back);
		terrain.setRenderState(cs);

		final ZBufferState buf = new ZBufferState();
		buf.setEnabled(true);
		buf.setFunction(ZBufferState.TestFunction.LessThanOrEqualTo);
		terrain.setRenderState(buf);

		final TextureState ts = new TextureState();
		terrain.setRenderState(ts);

		int w = 32, h = 32;
		area = new Mesh[mapHeight / h][mapWidth / w];
		for (int z = 0; z < mapWidth / w; z++)
		{
			for (int x = 0; x < mapHeight / h; x++)
			{
				createArea(x, z, w, h, normals, calcY_UV, scaleU, scaleV);
				terrain.attachChild(area[z][x]);
			}
		}

		Main.println("OK.");
	}

	void createArea(int xx, int zz, int w, int h, float[] normals, boolean calcY_UV, float scaleU, float scaleV)
	{
		Mesh mesh = new Mesh("#terrain_" + xx + "_" + zz);
		area[zz][xx] = mesh;
		xx *= w;
		zz *= h;

		final MeshData meshData = mesh.getMeshData();
		final FloatBuffer vertexBuffer = BufferUtils.createVector3Buffer(w * h * 6);
		final FloatBuffer normalBuffer = BufferUtils.createVector3Buffer(w * h * 6);
		final FloatBuffer uvBuffer = BufferUtils.createVector2Buffer(w * h * 6);

		for (int z = zz; z < zz + h; z++)
		{
			for (int x = xx; x < xx + w; x++)
			{
				float x2 = -mapWidth / 2 + x;
				float z2 = -mapHeight / 2 + z;

				float y = mapImg[z * mapWidth + x] * Y_SCALE;
				vertexBuffer.put(x2 * X_SCALE).put(y).put(z2 * Z_SCALE);
				normalBuffer.put(normals[(z * mapWidth + x) * 3]).put(normals[(z * mapWidth + x) * 3 + 1]).put(normals[(z * mapWidth + x) * 3 + 2]);

				y = mapImg[(z + 1) * mapWidth + x] * Y_SCALE;
				vertexBuffer.put(x2 * X_SCALE).put(y).put((z2 + 1) * Z_SCALE);
				normalBuffer.put(normals[((z + 1) * mapWidth + x) * 3]).put(normals[((z + 1) * mapWidth + x) * 3 + 1])
						.put(normals[((z + 1) * mapWidth + x) * 3 + 2]);

				y = mapImg[(z + 1) * mapWidth + x + 1] * Y_SCALE;
				vertexBuffer.put((x2 + 1) * X_SCALE).put(y).put((z2 + 1) * Z_SCALE);
				normalBuffer.put(normals[((z + 1) * mapWidth + (x + 1)) * 3]).put(normals[((z + 1) * mapWidth + (x + 1)) * 3 + 1])
						.put(normals[((z + 1) * mapWidth + (x + 1)) * 3 + 2]);

				y = mapImg[z * mapWidth + x] * Y_SCALE;
				vertexBuffer.put(x2 * X_SCALE).put(y).put(z2 * Z_SCALE);
				normalBuffer.put(normals[(z * mapWidth + x) * 3]).put(normals[(z * mapWidth + x) * 3 + 1]).put(normals[(z * mapWidth + x) * 3 + 2]);

				y = mapImg[(z + 1) * mapWidth + x + 1] * Y_SCALE;
				vertexBuffer.put((x2 + 1) * X_SCALE).put(y).put((z2 + 1) * Z_SCALE);
				normalBuffer.put(normals[((z + 1) * mapWidth + (x + 1)) * 3]).put(normals[((z + 1) * mapWidth + (x + 1)) * 3 + 1])
						.put(normals[((z + 1) * mapWidth + (x + 1)) * 3 + 2]);

				y = mapImg[z * mapWidth + x + 1] * Y_SCALE;
				vertexBuffer.put((x2 + 1) * X_SCALE).put(y).put(z2 * Z_SCALE);
				normalBuffer.put(normals[(z * mapWidth + (x + 1)) * 3]).put(normals[(z * mapWidth + (x + 1)) * 3 + 1])
						.put(normals[(z * mapWidth + (x + 1)) * 3 + 2]);

				if (calcY_UV == false)
				{
					uvBuffer.put((float) x * scaleU / (float) mapWidth).put(1 - ((float) z * scaleV / (float) mapHeight));
					uvBuffer.put((float) x * scaleU / (float) mapWidth).put(1 - ((float) (z + 1) * scaleV / (float) mapHeight));
					uvBuffer.put((float) (x + 1) * scaleU / (float) mapWidth).put(1 - ((float) (z + 1) * scaleV / (float) mapHeight));

					uvBuffer.put((float) x * scaleU / (float) mapWidth).put(1 - ((float) z * scaleV / (float) mapHeight));
					uvBuffer.put((float) (x + 1) * scaleU / (float) mapWidth).put(1 - ((float) (z + 1) * scaleV / (float) mapHeight));
					uvBuffer.put((float) (x + 1) * scaleU / (float) mapWidth).put(1 - ((float) z * scaleV / (float) mapHeight));
				} else
				{
					uvBuffer.put((float) x * scaleU / (float) mapWidth).put(((float) mapImg[z * mapWidth + x]) / 256f);
					uvBuffer.put((float) x * scaleU / (float) mapWidth).put(((float) mapImg[(z + 1) * mapWidth + x]) / 256f);
					uvBuffer.put((float) (x + 1) * scaleU / (float) mapWidth).put(((float) mapImg[(z + 1) * mapWidth + (x + 1)]) / 256f);

					uvBuffer.put((float) x * scaleU / (float) mapWidth).put(((float) mapImg[z * mapWidth + x]) / 256f);
					uvBuffer.put((float) (x + 1) * scaleU / (float) mapWidth).put(((float) mapImg[(z + 1) * mapWidth + (x + 1)]) / 256f);
					uvBuffer.put((float) (x + 1) * scaleU / (float) mapWidth).put(((float) mapImg[z * mapWidth + (x + 1)]) / 256f);
				}
			}
		}

		meshData.setVertexBuffer(vertexBuffer);
		meshData.setNormalBuffer(normalBuffer);
		meshData.setTextureBuffer(uvBuffer, 0);
		meshData.setIndexMode(IndexMode.Triangles);

		mesh.setModelBound(new BoundingBox());
		mesh.updateModelBound();
	}

	private float[] calculateNormals()
	{
		Vector3 norm = (Vector3) Vector3.ZERO;
		float normals[] = new float[mapWidth * mapHeight * 3];

		for (int i = 1; i < mapHeight - 1; i++)
			for (int j = 1; j < mapWidth - 1; j++)
			{
				norm = norm.add(terrainCrossProduct(j, i, j - 1, i, j, i + 1).normalizeLocal(), null);
				norm = norm.add(terrainCrossProduct(j, i, j, i + 1, j + 1, i).normalizeLocal(), null);
				norm = norm.add(terrainCrossProduct(j, i, j + 1, i, j, i - 1).normalizeLocal(), null);
				norm = norm.add(terrainCrossProduct(j, i, j, i - 1, j - 1, i).normalizeLocal(), null);
				norm = norm.normalizeLocal();
				normals[3 * (i * mapWidth + j) + 0] = norm.getXf();
				normals[3 * (i * mapWidth + j) + 1] = norm.getYf();
				normals[3 * (i * mapWidth + j) + 2] = norm.getZf();
			}
		return normals;
	}

	private Vector3 terrainCrossProduct(float x1, float z1, float x2, float z2, float x3, float z3)
	{
		Vector3 norm = new Vector3();
		float v1[], v2[];
		v1 = new float[3];
		v2 = new float[3];

		v1[0] = (x2 - x1) * X_SCALE;
		v1[1] = -mapImg[(int) z1 * mapWidth + (int) x1] + mapImg[(int) z2 * mapWidth + (int) x2] * Y_SCALE;
		v1[2] = (z2 - z1) * Z_SCALE;

		v2[0] = (x3 - x1) * X_SCALE;
		v2[1] = -mapImg[(int) z1 * mapWidth + (int) x1] + mapImg[(int) z3 * mapWidth + (int) x3] * Y_SCALE;
		v2[2] = (z3 - z1) * Z_SCALE;

		norm.setZ(v1[0] * v2[1] - v1[1] * v2[0]);
		norm.setX(v1[1] * v2[2] - v1[2] * v2[1]);
		norm.setY(v1[2] * v2[0] - v1[0] * v2[2]);

		return norm;
	}

	// k�yt� vain 1 texturea
	public void useTexture(String fileName)
	{
		final TextureState ts = new TextureState();
		Texture t = TextureManager.load(fileName, Texture.MinificationFilter.Trilinear, true);
		ts.setTexture(t);
		terrain.setRenderState(ts);
	}

}
