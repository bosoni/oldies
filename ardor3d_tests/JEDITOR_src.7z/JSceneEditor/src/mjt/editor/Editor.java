package mjt.editor;

import java.awt.Color;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.logging.Logger;

import javax.swing.JOptionPane;
import mjt.AnyKeyReleasedCondition;
import mjt.DragCamera;
import mjt.Settings;
import mjt.SkyBox;
import mjt.Terrain;
import com.ardor3d.annotation.MainThread;
import com.ardor3d.bounding.BoundingBox;
import com.ardor3d.extension.model.collada.jdom.ColladaImporter;
import com.ardor3d.extension.model.collada.jdom.data.ColladaStorage;
import com.ardor3d.extension.model.md2.Md2Importer;
import com.ardor3d.extension.model.obj.ObjGeometryStore;
import com.ardor3d.extension.model.obj.ObjImporter;
import com.ardor3d.framework.Canvas;
import com.ardor3d.framework.Scene;
import com.ardor3d.framework.Updater;
import com.ardor3d.image.Texture;
import com.ardor3d.input.Key;
import com.ardor3d.input.KeyboardState;
import com.ardor3d.input.MouseButton;
import com.ardor3d.input.MouseState;
import com.ardor3d.input.logical.AnyKeyCondition;
import com.ardor3d.input.logical.InputTrigger;
import com.ardor3d.input.logical.LogicalLayer;
import com.ardor3d.input.logical.MouseButtonPressedCondition;
import com.ardor3d.input.logical.MouseMovedCondition;
import com.ardor3d.input.logical.MouseWheelMovedCondition;
import com.ardor3d.input.logical.TriggerAction;
import com.ardor3d.input.logical.TwoInputStates;
import com.ardor3d.intersection.PickData;
import com.ardor3d.intersection.PickResults;
import com.ardor3d.intersection.PickingUtil;
import com.ardor3d.intersection.PrimitivePickResults;
import com.ardor3d.light.Light;
import com.ardor3d.light.SpotLight;
import com.ardor3d.math.ColorRGBA;
import com.ardor3d.math.MathUtils;
import com.ardor3d.math.Matrix3;
import com.ardor3d.math.Ray3;
import com.ardor3d.math.Vector2;
import com.ardor3d.math.Vector3;
import com.ardor3d.math.type.ReadOnlyMatrix3;
import com.ardor3d.renderer.Camera;
import com.ardor3d.renderer.ContextCapabilities;
import com.ardor3d.renderer.ContextManager;
import com.ardor3d.renderer.IndexMode;
import com.ardor3d.renderer.Renderer;
import com.ardor3d.renderer.state.CullState;
import com.ardor3d.renderer.state.CullState.Face;
import com.ardor3d.renderer.state.LightState;
import com.ardor3d.renderer.state.MaterialState;
import com.ardor3d.renderer.state.RenderState.StateType;
import com.ardor3d.renderer.state.TextureState;
import com.ardor3d.renderer.state.ZBufferState;
import com.ardor3d.scenegraph.Line;
import com.ardor3d.scenegraph.Mesh;
import com.ardor3d.scenegraph.Node;
import com.ardor3d.scenegraph.Spatial;
import com.ardor3d.scenegraph.event.DirtyType;
import com.ardor3d.scenegraph.extension.Skybox;
import com.ardor3d.scenegraph.hint.CullHint;
import com.ardor3d.scenegraph.hint.LightCombineMode;
import com.ardor3d.scenegraph.shape.Box;
import com.ardor3d.scenegraph.shape.Sphere;
import com.ardor3d.scenegraph.visitor.Visitor;
import com.ardor3d.util.ContextGarbageCollector;
import com.ardor3d.util.GameTaskQueue;
import com.ardor3d.util.GameTaskQueueManager;
import com.ardor3d.util.ReadOnlyTimer;
import com.ardor3d.util.TextureManager;
import com.ardor3d.util.geom.Debugger;
import com.ardor3d.util.resource.MultiFormatResourceLocator;
import com.ardor3d.util.resource.ResourceLocatorTool;

public class Editor implements Updater, Scene
{
	static String MESSAGE = "Hotkeys:\n\n" + "G        move\n" + "R        rotate\n" + "S        scale\n" + "X, Y, Z  lock axis\n" + "A        remove lock\n\n"
			+ "F5       randomize\n" + "F6       enable/disable autorand\n" + "F7       enable/disable grid snap\n" + "F8       enable/disable Force Y\n"
			+ "DEL      remove model\n\n" + "LEFT SHIFT    faster camera\n" + "numpad 7,1,3  change camera view\n"
			+ "Right mouse button turns camera, and then ASDW keys moves camera.\nMouse wheel + CTRL rotates model\nMouse wheel + SHIFT scales model.";

	static int objCount = 0;
	final Node rootNode = new Node("root");
	final Random random = new Random();
	final LogicalLayer logicalLayer;
	static float camSpeed = 5;
	DragCamera fpsControl;
	float gsize = 100;
	boolean kbShiftPressed = false, kbCtrlPressed = false;
	boolean editModel = false; // jos muokataan jo asetettua obua
	Spatial selectedSpatial; // valittu obu (liikkuu hiiren mukana)
	Line lineAxis, gridLine;
	String _loadedFile = "";
	Skybox sky = null;
	LightState lightState;
	HashMap<String, String> userDatas = new HashMap<String, String>();
	HashMap<String, String> guiDatas = new HashMap<String, String>();
	HashMap<String, String> fileDatas = new HashMap<String, String>();
	String skyName = "", terrainName = "";

	enum MovingModes
	{
		None, Move, Rotate, Scale
	};

	enum AxisLock
	{
		None, X, Y, Z
	};

	MovingModes movingMode = MovingModes.None;
	AxisLock axisLock = AxisLock.None;

	public Editor(final LogicalLayer logicalLayer)
	{
		this.logicalLayer = logicalLayer;
	}

	public static void showHotkeys()
	{
		JOptionPane.showMessageDialog(null, MESSAGE);
	}

	@MainThread
	public void init()
	{
		final ContextCapabilities caps = ContextManager.getCurrentContext().getCapabilities();
		Main.println("JSceneEditor (c) mjt 2012 [mixut@hotmail.com]\n");
		Main.println("Display Vendor: " + caps.getDisplayVendor());
		Main.println("Display Renderer: " + caps.getDisplayRenderer());
		Main.println("Display Version: " + caps.getDisplayVersion());
		Main.println("Shading Language Version: " + caps.getShadingLanguageVersion());

		setCamera(CamDirs.Startup);

		Mesh box = new Box("#floor (temp)", new Vector3(-gsize, -0.1f, -gsize), new Vector3(gsize, 0, gsize));
		box.getSceneHints().setCastsShadows(false);
		box.getSceneHints().setLightCombineMode(LightCombineMode.Off);
		box.setSolidColor(ColorRGBA.DARK_GRAY);
		box.setModelBound(new BoundingBox());
		rootNode.attachChild(box);
		GUI_Editor.treeScene.add("#floor (temp)");
		GUI_Editor.treeScene.add("#floor (temp)", "#box");
		GUI_TO_guiData(box);

		final ZBufferState buf = new ZBufferState();
		buf.setEnabled(true);
		buf.setFunction(ZBufferState.TestFunction.LessThanOrEqualTo);
		rootNode.setRenderState(buf);

		registerInputTriggers();

		createGrid();

		lightState = new LightState();
		lightState.setEnabled(true);
		rootNode.setRenderState(lightState);

		createLightOrCamera(2);
	}

	void createGrid()
	{
		ArrayList<Vector3> vertexList = new ArrayList<Vector3>();
		for (double x = -gsize; x < gsize; x += 2)
		{
			vertexList.add(new Vector3(x, 0.01, -gsize));
			vertexList.add(new Vector3(x, 0.01, gsize));

			vertexList.add(new Vector3(x + 1, 0.01, gsize));
			vertexList.add(new Vector3(x + 1, 0.01, -gsize));

			vertexList.add(new Vector3(x + 2, 0.01, -gsize));
		}

		for (double z = -gsize; z < gsize; z += 2)
		{
			vertexList.add(new Vector3(-gsize, 0.01, z));
			vertexList.add(new Vector3(gsize, 0.01, z));

			vertexList.add(new Vector3(gsize, 0.01, z + 1));
			vertexList.add(new Vector3(-gsize, 0.01, z + 1));

			vertexList.add(new Vector3(-gsize, 0.01, z + 2));
		}

		gridLine = new Line("grid", vertexList.toArray(new Vector3[vertexList.size()]), null, null, null);
		gridLine.getMeshData().setIndexMode(IndexMode.LineStrip);
		gridLine.updateModelBound();
		gridLine.getSceneHints().setLightCombineMode(LightCombineMode.Off);
		gridLine.setSolidColor(ColorRGBA.GRAY);
		rootNode.attachChild(gridLine);

		vertexList = new ArrayList<Vector3>();
		vertexList.add(new Vector3(-100, 0, 0));
		vertexList.add(new Vector3(100, 0, 0));
		lineAxis = new Line("axLine", vertexList.toArray(new Vector3[vertexList.size()]), null, null, null);
		lineAxis.getMeshData().setIndexMode(IndexMode.LineStrip);
		lineAxis.updateModelBound();
		lineAxis.getSceneHints().setLightCombineMode(LightCombineMode.Off);
	}

	private void registerInputTriggers()
	{
		fpsControl = DragCamera.setupTriggers(logicalLayer, Vector3.UNIT_Y, true);
		fpsControl.setMoveSpeed(camSpeed);

		logicalLayer.registerTrigger(new InputTrigger(new AnyKeyCondition(), new TriggerAction()
		{
			public void perform(final Canvas canvas, final TwoInputStates inputStates, final double tpf)
			{
				KeyboardState kb = inputStates.getCurrent().getKeyboardState();

				if (kb.isDown(Key.DELETE))
					deleteObjectFromList();

				if (kb.isDown(Key.ESCAPE))
				{
					// jos EI olla valkattu mit��n scene listasta, poista obu
					if (GUI_Editor.treeScene.getSelected() == null)
						rootNode.detachChild(selectedSpatial);

					editModel = false;
					selectedSpatial = null;
					axisLock = AxisLock.None;
					movingMode = MovingModes.None;
					GUI_Editor.txtTaskbar.setText("");
					GUI_Editor.txtTaskbar2.setText("");
					GUI_Editor.treeScene.clearSelection();
				}

				if (kb.isDown(Key.F1))
					showHotkeys();

				/*
				 * n�pp�inkomentoja:
				 * F5 randomize
				 * F6 enable/disable autorand
				 * F6 enable/disable grid snap
				 * F8 enable/disable Force Y
				 */
				if (kb.isDown(Key.F5))
					GUI_Editor.RandomizeSpinners();

				if (kb.isDown(Key.F6))
					GUI_Editor.chckbxAutorand.setSelected(!GUI_Editor.chckbxAutorand.isSelected());

				if (kb.isDown(Key.F7))
					GUI_Editor.chckbxGridSnapxz.setSelected(!GUI_Editor.chckbxGridSnapxz.isSelected());

				if (kb.isDown(Key.F8))
					GUI_Editor.chckbxForceY.setSelected(!GUI_Editor.chckbxForceY.isSelected());

				// 7,1,3 kamerakulman vaihto blenderin tapaan
				if (kb.isDown(Key.NUMPAD7))
					setCamera(CamDirs.Top);
				if (kb.isDown(Key.NUMPAD1))
					setCamera(CamDirs.Front);
				if (kb.isDown(Key.NUMPAD3))
					setCamera(CamDirs.Right);

				// kameran nopeudenmuutos
				if (kb.isDown(Key.LSHIFT))
				{
					fpsControl.setMoveSpeed(camSpeed * 5);
					kbShiftPressed = true;
				}

				if (kb.isDown(Key.LCONTROL))
				{
					kbCtrlPressed = true;
				}

				// n�m� toimii vain silloin ku ei oo hiiren oikee pohjassa
				if (DragCamera.rightPressed == false)
				{
					String txt = "";

					if (kb.isDown(Key.G) && selectedSpatial.getName().contains("#terrain") == false)
					{
						movingMode = MovingModes.Move;
						txt = "Mode: move";
					}

					if (kb.isDown(Key.R) && selectedSpatial.getName().contains("#terrain") == false)
					{
						movingMode = MovingModes.Rotate;
						txt = "Mode: rotate";
					}
					if (kb.isDown(Key.S))
					{
						movingMode = MovingModes.Scale;
						txt = "Mode: scale";
					}

					if (txt.equals("") == false)
						GUI_Editor.txtTaskbar.setText(txt);

					txt = "";
					if (kb.isDown(Key.X))
					{
						axisLock = AxisLock.X;
						txt = "Lock: X";
					}
					if (kb.isDown(Key.Y))
					{
						axisLock = AxisLock.Y;
						txt = "Lock: Y";
					}
					if (kb.isDown(Key.Z))
					{
						axisLock = AxisLock.Z;
						txt = "Lock: Z";
					}
					if (kb.isDown(Key.A))
					{
						axisLock = AxisLock.None;
						txt = " ";
					}

					if (txt.equals("") == false)
						GUI_Editor.txtTaskbar2.setText(txt);

				}
			}
		}));

		logicalLayer.registerTrigger(new InputTrigger(new AnyKeyReleasedCondition(), new TriggerAction()
		{
			public void perform(final Canvas canvas, final TwoInputStates inputStates, final double tpf)
			{
				KeyboardState kb = inputStates.getCurrent().getKeyboardState();

				if (!kb.isDown(Key.LSHIFT)) // kun vapautetaan shift, aseta normaali nopeus
				{
					fpsControl.setMoveSpeed(camSpeed);
					kbShiftPressed = false;
				}

				if (!kb.isDown(Key.LCONTROL)) // kun vapautetaan control
					kbCtrlPressed = false;
			}
		}));

		// hiiren liikutus
		logicalLayer.registerTrigger(new InputTrigger(new MouseMovedCondition(), new TriggerAction()
		{
			public void perform(final Canvas canvas, final TwoInputStates inputStates, final double tpf)
			{
				final MouseState mouse = inputStates.getCurrent().getMouseState();
				float dx = -mouse.getDx() * 0.01f;
				float dy = mouse.getDy() * 0.01f;

				if (mouse.getDx() != 0 || mouse.getDy() != 0)
				{
					if (DragCamera.middlePressed)
					{
						Camera.getCurrentCamera().setLocation(
								Camera.getCurrentCamera().getLocation().add(Camera.getCurrentCamera().getLeft().multiply(dx * camSpeed, null), null));
						Camera.getCurrentCamera().setLocation(
								Camera.getCurrentCamera().getLocation().add(Camera.getCurrentCamera().getUp().multiply(dy * camSpeed, null), null));
					}
				}

				if (movingMode == MovingModes.Move)
				{
					if (axisLock == AxisLock.None)
						pickWorldCoord(inputStates.getCurrent().getMouseState().getX(), inputStates.getCurrent().getMouseState().getY(), false);
					else
					{
						float MUL = 10;
						if (axisLock == AxisLock.X)
						{
							float x = Float.parseFloat(GUI_Editor.spinner.getValue().toString());
							GUI_Editor.spinner.setValue(x - dx * MUL);
						} else if (axisLock == AxisLock.Y)
						{
							float y = Float.parseFloat(GUI_Editor.spinner_1.getValue().toString());
							GUI_Editor.spinner_1.setValue(y + dy * MUL);

							// jos pakotetaan Y haluttuun kohtaan
							if (GUI_Editor.chckbxForceY.isSelected())
							{
								float Y = Float.parseFloat(GUI_Editor.spinner_1.getValue().toString());
								GUI_Editor.spinner_9.setValue(Y);
							}

						} else if (axisLock == AxisLock.Z)
						{
							float z = Float.parseFloat(GUI_Editor.spinner_2.getValue().toString());
							GUI_Editor.spinner_2.setValue(z - dy * MUL);
						}
					}
				} else if (movingMode == MovingModes.Rotate)
				{
					float MUL = 100;
					if (axisLock == AxisLock.None)
					{
						float x = Float.parseFloat(GUI_Editor.spinner_3.getValue().toString());
						GUI_Editor.spinner_3.setValue(x - dy * MUL);
						float y = Float.parseFloat(GUI_Editor.spinner_4.getValue().toString());
						GUI_Editor.spinner_4.setValue(y - dx * MUL);
					} else
					{
						if (axisLock == AxisLock.X)
						{
							float x = Float.parseFloat(GUI_Editor.spinner_3.getValue().toString());
							GUI_Editor.spinner_3.setValue(x - dy * MUL);
						} else if (axisLock == AxisLock.Y)
						{
							float y = Float.parseFloat(GUI_Editor.spinner_4.getValue().toString());
							GUI_Editor.spinner_4.setValue(y - dx * MUL);
						} else if (axisLock == AxisLock.Z)
						{
							float z = Float.parseFloat(GUI_Editor.spinner_5.getValue().toString());
							GUI_Editor.spinner_5.setValue(z + dx * MUL);
						}
					}
				} else if (movingMode == MovingModes.Scale)
				{
					float MUL = 10;
					if (axisLock == AxisLock.None)
					{
						float x = Float.parseFloat(GUI_Editor.spinner_6.getValue().toString());
						GUI_Editor.spinner_6.setValue(x + dy * MUL);
						float y = Float.parseFloat(GUI_Editor.spinner_7.getValue().toString());
						GUI_Editor.spinner_7.setValue(y + dy * MUL);
						float z = Float.parseFloat(GUI_Editor.spinner_8.getValue().toString());
						GUI_Editor.spinner_8.setValue(z + dy * MUL);
					} else
					{
						if (axisLock == AxisLock.X)
						{
							float x = Float.parseFloat(GUI_Editor.spinner_6.getValue().toString());
							GUI_Editor.spinner_6.setValue(x - dx * MUL);
						} else if (axisLock == AxisLock.Y)
						{
							float y = Float.parseFloat(GUI_Editor.spinner_7.getValue().toString());
							GUI_Editor.spinner_7.setValue(y + dy * MUL);
						} else if (axisLock == AxisLock.Z)
						{
							float z = Float.parseFloat(GUI_Editor.spinner_8.getValue().toString());
							GUI_Editor.spinner_8.setValue(z - dy * MUL);
						}
					}
				}
			}
		}));

		// hiiren rulla
		logicalLayer.registerTrigger(new InputTrigger(new MouseWheelMovedCondition(), new TriggerAction()
		{
			public void perform(final Canvas canvas, final TwoInputStates inputStates, final double tpf)
			{
				int w = inputStates.getCurrent().getMouseState().getDwheel();

				if (kbShiftPressed) // hiiren rulla + shift skaalaa objektia
				{
					if (selectedSpatial == null)
						return;

					double s = 1;
					if (w < 0)
						s = 1.2;
					else if (w > 0)
						s = 0.8;

					float sx = Float.parseFloat(GUI_Editor.spinner_6.getValue().toString());
					float sy = Float.parseFloat(GUI_Editor.spinner_7.getValue().toString());
					float sz = Float.parseFloat(GUI_Editor.spinner_8.getValue().toString());
					GUI_Editor.spinner_6.setValue(sx * s);
					GUI_Editor.spinner_7.setValue(sy * s);
					GUI_Editor.spinner_8.setValue(sz * s);
				} else if (kbCtrlPressed) // hiiren rulla + ctrl py�ritt�� objektia y-akselin ymp�ri
				{
					float ry = Float.parseFloat(GUI_Editor.spinner_4.getValue().toString());
					GUI_Editor.spinner_4.setValue(ry + 15 * (w > 0 ? 1 : -1));

				} else
				// rulla ilman shifti� -> liikutetaan kameraa eteen/taakse
				{
					Camera.getCurrentCamera().setLocation(
							Camera.getCurrentCamera().getLocation().add(Camera.getCurrentCamera().getDirection().multiply(-w * camSpeed, null), null));
				}
			}
		}));

		// hiiren napin painallus
		logicalLayer.registerTrigger(new InputTrigger(new MouseButtonPressedCondition(MouseButton.LEFT), new TriggerAction()
		{
			public void perform(final Canvas canvas, final TwoInputStates inputStates, final double tpf)
			{
				GUI_TO_guiData(selectedSpatial);

				// jos edit moodissa ja klikataan
				if (editModel == true)
				{
					selectedSpatial = null;
					movingMode = MovingModes.None;
					axisLock = AxisLock.None;
					GUI_Editor.txtTaskbar2.setText("");
				} else
				{
					movingMode = MovingModes.Move;
					axisLock = AxisLock.None;
				}

				// ei valintaa joten valitse objekti skenest�
				if (selectedSpatial == null)
				{
					pickWorldCoord(inputStates.getCurrent().getMouseState().getX(), inputStates.getCurrent().getMouseState().getY(), true);
					if (selectedSpatial != null)
					{
						editModel = true;
						showValues(selectedSpatial.getName());
					} else
						GUI_Editor.treeScene.clearSelection();

					return;
				}

				if (GUI_Editor.chckbxAutorand.isSelected())
					GUI_Editor.RandomizeSpinners(); // jos autorand niin aseta random arvot

				// objekti skeneen ja listaan

				Spatial newspatial = load(_loadedFile);
				newspatial.setTranslation(selectedSpatial.getTranslation());
				newspatial.setRotation(selectedSpatial.getRotation());
				newspatial.setScale(selectedSpatial.getScale());
				newspatial.setName(selectedSpatial.getName() + "_" + (Editor.objCount++));
				rootNode.attachChild(newspatial);

				fileDatas.put(newspatial.getName(), _loadedFile);

				GUI_Editor.treeScene.add(newspatial.getName());

				// n�ytt�� kaikki meshit listassa, asettaa alkup arvot
				GUI_TO_guiData(newspatial);
				final String parent = newspatial.getName();
				newspatial.acceptVisitor(new Visitor()
				{
					public void visit(final Spatial spatial)
					{
						if (spatial instanceof Mesh)
						{
							spatial.setName(parent + "." + spatial.getName());
							GUI_Editor.treeScene.add(parent, spatial.getName());
							GUI_TO_guiData(spatial);
						}
					}
				}, false);
				updateMaterial(newspatial);
			}
		}));
	}

	@MainThread
	public void update(final ReadOnlyTimer timer)
	{
		final double tpf = timer.getTimePerFrame();
		logicalLayer.checkTriggers(tpf);

		updateValues();

		rootNode.detachChild(lineAxis);
		if (axisLock != AxisLock.None && selectedSpatial != null)
		{
			rootNode.attachChild(lineAxis);
			lineAxis.setTransform(selectedSpatial.getTransform());
			if (axisLock == AxisLock.X)
			{
				lineAxis.setSolidColor(ColorRGBA.RED);
				lineAxis.setRotation(new Matrix3().fromAngles(Math.toRadians(0), Math.toRadians(0), Math.toRadians(0)));
			} else if (axisLock == AxisLock.Y)
			{
				lineAxis.setSolidColor(ColorRGBA.GREEN);
				lineAxis.setRotation(new Matrix3().fromAngles(Math.toRadians(0), Math.toRadians(0), Math.toRadians(90)));
			} else if (axisLock == AxisLock.Z)
			{
				lineAxis.setSolidColor(ColorRGBA.BLUE);
				lineAxis.setRotation(new Matrix3().fromAngles(Math.toRadians(0), Math.toRadians(90), Math.toRadians(0)));
			}

		}

		if (sky != null)
			sky.setTranslation(Camera.getCurrentCamera().getLocation());

		rootNode.updateGeometricState(tpf, true);
	}

	// 1=camera, 2=light
	void createLightOrCamera(int mode)
	{
		if (mode == 1) // cam
		{
			float gsize = 0.1f;
			Mesh box = new Box("#camera_" + (Editor.objCount), new Vector3(-gsize, -gsize, -gsize * 2), new Vector3(gsize, gsize, gsize * 2));
			box.getSceneHints().setCastsShadows(false);
			box.getSceneHints().setLightCombineMode(LightCombineMode.Off);
			box.setTranslation(Camera.getCurrentCamera().getLocation());

			Matrix3 store = new Matrix3();
			Vector3 at = Camera.getCurrentCamera().getLocation().add(Camera.getCurrentCamera().getDirection(), null);
			MathUtils.matrixLookAt(Camera.getCurrentCamera().getLocation(), at, Vector3.UNIT_Y, store);
			box.setRotation(store);
			rootNode.attachChild(box);
			GUI_Editor.treeScene.insert("#camera_" + (Editor.objCount++), 0);
			GUI_TO_guiData(box);

		} else if (mode == 2) // light
		{
			Sphere sphere = new Sphere("#light_" + (Editor.objCount), 8, 8, 0.1);
			sphere.getSceneHints().setCastsShadows(false);
			sphere.getSceneHints().setLightCombineMode(LightCombineMode.Off);
			sphere.setTranslation(Camera.getCurrentCamera().getLocation());

			final SpotLight light = new SpotLight();
			light.setName("#light_" + (Editor.objCount));
			light.setDiffuse(new ColorRGBA(1, 1, 1, 1));
			light.setAmbient(new ColorRGBA(0.5f, 0.5f, 0.5f, 1.0f));
			light.setLocation(Camera.getCurrentCamera().getLocation());
			light.setDirection(Camera.getCurrentCamera().getDirection());
			light.setAngle(90);
			light.setEnabled(true);
			lightState.attach(light);

			rootNode.attachChild(sphere);
			GUI_Editor.treeScene.insert("#light_" + (Editor.objCount++), 0);
			GUI_TO_guiData(sphere);

			rootNode.markDirty(DirtyType.RenderState);
		}

	}

	void removeFromList(String name)
	{
		// poista scene listasta obu
		GUI_Editor.treeScene.delete(name);
		GUI_Editor.treeScene.clearSelection();
	}

	void loadTileMap(String fileName)
	{
		// TODO

	}

	void loadSkybox(String name)
	{
		if (sky != null) // poista vanha sky jos on
		{
			rootNode.detachChild(sky);
			// poista listasta #sky
			removeFromList("#sky");
		}
		if (SkyBox.exists(name) == false)
		{
			Main.println("Cannot find skybox: " + name);
			return;
		}

		skyName = name;
		sky = SkyBox.load(name);
		rootNode.attachChild(sky);

		GUI_Editor.treeScene.insert("#sky", 0);
	}

	void loadTerrain(String fileName)
	{
		rootNode.detachChild(rootNode.getChild("#terrain")); // poista vanha terrain jos on
		removeFromList("#terrain");

		Terrain t = new Terrain();

		try
		{
			t.load(fileName, true, 1, 1);
			//t.loadJHMAP(fileName);
		} catch (Exception e)
		{
			Main.println(e.toString());
			return;
		}

		terrainName = fileName;
		rootNode.attachChild(t.getNode());
		GUI_Editor.treeScene.insert("#terrain", 0);

		GUI_TO_guiData(t.getNode());
	}

	void loadModel(String fileName)
	{
		if (selectedSpatial != null && editModel == false)
			rootNode.detachChild(selectedSpatial);

		resetValues();
		GUI_Editor.treeScene.clearSelection();
		movingMode = MovingModes.Move;
		axisLock = AxisLock.None;
		GUI_Editor.txtTaskbar2.setText("");
		editModel = false;

		selectedSpatial = load(fileName);
		_loadedFile = fileName;

		String n = fileName;
		n = n.replace('\\', '/');
		selectedSpatial.setName(n.substring(n.lastIndexOf('/') + 1, n.lastIndexOf('.'))); // tiedostonimi ilman hakemistoa ja p��tett�
		selectedSpatial.setTranslation(0, 0, 0);

		if (fileName.contains(".dae") || fileName.contains(".DAE"))
			GUI_Editor.spinner_3.setValue(-90);

		rootNode.attachChild(selectedSpatial);

		// alkup arvot
		selectedSpatial.acceptVisitor(new Visitor()
		{
			public void visit(final Spatial spatial)
			{
				if (spatial instanceof Mesh)
				{
					GUI_TO_guiData(spatial);
				}
			}
		}, false);

	}

	Spatial load(String fileName)
	{
		Spatial spatial = null;
		fileName = fileName.replace('\\', '/');
		try
		{
			if (fileName.toLowerCase().contains(".dae"))
			{
				final ColladaImporter importer = new ColladaImporter();
				ColladaStorage storage = importer.load(fileName);
				spatial = storage.getScene();
				spatial.setRotation(new Matrix3().fromAngleAxis(Math.toRadians(-90), Vector3.UNIT_X));
			} else if (fileName.toLowerCase().contains(".obj"))
			{
				final ObjGeometryStore storage = new ObjImporter().load(fileName);
				spatial = storage.getScene();
			} else if (fileName.toLowerCase().contains(".md2"))
			{
				final Md2Importer importer = new Md2Importer();
				importer.setTextureLocator(new MultiFormatResourceLocator(ResourceLocatorTool
						.getClassPathResource(Editor.class, Settings.dataDir + "textures/"), ".dds", ".jpg", ".png", ".tga", ".pcx"));
				spatial = importer.load(fileName).getScene();
				spatial.setRotation(new Matrix3().fromAngleAxis(Math.toRadians(-90), Vector3.UNIT_X));
			}
			spatial.setTranslation(0, 0, 0);

			spatial.acceptVisitor(new Visitor()
			{
				public void visit(final Spatial spatial)
				{
					if (spatial instanceof Mesh)
					{
						Mesh m = (Mesh) spatial;
						final CullState cs = new CullState();
						cs.setCullFace(Face.Back);
						spatial.setRenderState(cs);
						m.setModelBound(new BoundingBox());

						final ZBufferState buf = new ZBufferState();
						buf.setEnabled(true);
						buf.setFunction(ZBufferState.TestFunction.LessThanOrEqualTo);
						m.setRenderState(buf);

						TextureState ts = (TextureState) spatial.getLocalRenderState(StateType.Texture);
						if (ts == null)
							ts = new TextureState();

						m.setRenderState(ts);
					}
				}
			}, false);

		} catch (Exception e)
		{
			Main.println(e.toString());
			return null;
		}
		return spatial;
	}

	// objekti valittu scenelistasta
	void selectMesh(String name)
	{
		GUI_TO_guiData(selectedSpatial);

		if (selectedSpatial != null && editModel == false)
			rootNode.detachChild(selectedSpatial);

		GUI_Editor.txtTaskbar.setText("");
		GUI_Editor.txtTaskbar2.setText("");
		GUI_Editor.textArea.setText("");

		editModel = true;
		movingMode = MovingModes.None;
		axisLock = AxisLock.None;

		GUI_Editor.txtTaskbar.setText(name + " selected.");

		selectedSpatial = rootNode.getChild(name);
		if (selectedSpatial == null)
			return;

		showValues(name);
	}

	// poista obu skenelistasta
	void deleteObjectFromList()
	{
		if (GUI_Editor.treeScene.getSelected() == null)
			return;

		if (editModel)
		{
			String sel = GUI_Editor.treeScene.getSelected(); // valitun obun nimi

			if (selectedSpatial != null) // poista valittu obu
			{
				Main.println("Delete: " + selectedSpatial.getName());

				// poista scene listasta valittu obu
				removeFromList(selectedSpatial.getName());
				rootNode.detachChild(selectedSpatial);
				selectedSpatial = null;
				editModel = false;
			}

			if (sel.contains("#terrain"))
			{
				rootNode.detachChild(rootNode.getChild("#terrain"));
				removeFromList("#terrain");
				terrainName = "";
			}
			if (sel.contains("#sky"))
			{
				rootNode.detachChild(rootNode.getChild("#sky"));
				removeFromList("#sky");
				skyName = "";

			}
			if (sel.contains("#light"))
			{
				rootNode.detachChild(rootNode.getChild(sel));
				List<Light> ls = lightState.getLightList();
				for (Light l : ls)
				{
					if (l.getName().equals(sel))
					{
						lightState.detach(l);
						removeFromList(sel);
						rootNode.markDirty(DirtyType.RenderState);
						break;
					}
				}
			}

			GUI_Editor.treeScene.clearSelection();
		}

	}

	void resetValues()
	{
		// resetoidaan pos, rot ja scale arvot
		GUI_Editor.spinner.setValue(0);
		GUI_Editor.spinner_1.setValue(0);
		GUI_Editor.spinner_2.setValue(0);
		GUI_Editor.spinner_3.setValue(0);
		GUI_Editor.spinner_4.setValue(0);
		GUI_Editor.spinner_5.setValue(0);
		GUI_Editor.spinner_6.setValue(1);
		GUI_Editor.spinner_7.setValue(1);
		GUI_Editor.spinner_8.setValue(1);
	}

	void showValues(String name)
	{
		String usrdta = userDatas.get(name);
		if (usrdta != null)
			GUI_Editor.textArea.setText(usrdta);

		String guidta = guiDatas.get(name);
		if (guidta != null)
			guiData_TO_GUI(guidta);

		// ollaan valkattu obu joten nyt siit� pit�� ottaa arvot ja n�ytt�� ne
		if (selectedSpatial == null)
			return;

		GUI_Editor.spinner.setValue(selectedSpatial.getTranslation().getXf());
		GUI_Editor.spinner_1.setValue(selectedSpatial.getTranslation().getYf());
		GUI_Editor.spinner_2.setValue(selectedSpatial.getTranslation().getZf());

		ReadOnlyMatrix3 mat = selectedSpatial.getRotation();
		double[] angles = new double[3];
		mat.toAngles(angles);
		GUI_Editor.spinner_3.setValue(angles[0] * MathUtils.RAD_TO_DEG);
		GUI_Editor.spinner_4.setValue(angles[1] * MathUtils.RAD_TO_DEG);
		GUI_Editor.spinner_5.setValue(angles[2] * MathUtils.RAD_TO_DEG);

		GUI_Editor.spinner_6.setValue(selectedSpatial.getScale().getXf());
		GUI_Editor.spinner_7.setValue(selectedSpatial.getScale().getYf());
		GUI_Editor.spinner_8.setValue(selectedSpatial.getScale().getZf());
	}

	// ota arvot spinnereist�
	public void updateValues()
	{
		if (selectedSpatial == null)
			return;

		float x, y, z, rx, ry, rz, sx, sy, sz;
		x = Float.parseFloat(GUI_Editor.spinner.getValue().toString());
		y = Float.parseFloat(GUI_Editor.spinner_1.getValue().toString());
		z = Float.parseFloat(GUI_Editor.spinner_2.getValue().toString());
		rx = Float.parseFloat(GUI_Editor.spinner_3.getValue().toString());
		ry = Float.parseFloat(GUI_Editor.spinner_4.getValue().toString());
		rz = Float.parseFloat(GUI_Editor.spinner_5.getValue().toString());
		sx = Float.parseFloat(GUI_Editor.spinner_6.getValue().toString());
		sy = Float.parseFloat(GUI_Editor.spinner_7.getValue().toString());
		sz = Float.parseFloat(GUI_Editor.spinner_8.getValue().toString());
		if (sx < 0.0001)
		{
			GUI_Editor.spinner_6.setValue(0.0001);
			sx = 0.0001f;
		}
		if (sy < 0.0001)
		{
			GUI_Editor.spinner_7.setValue(0.0001);
			sy = 0.0001f;
		}
		if (sz < 0.0001)
		{
			GUI_Editor.spinner_8.setValue(0.0001);
			sz = 0.0001f;
		}

		selectedSpatial.setTranslation(x, y, z);
		selectedSpatial.setRotation(new Matrix3().fromAngles(Math.toRadians(rx), Math.toRadians(ry), Math.toRadians(rz)));
		selectedSpatial.setScale(sx, sy, sz);
	}

	@MainThread
	public boolean renderUnto(final Renderer renderer)
	{
		// Execute renderQueue item
		GameTaskQueueManager.getManager(ContextManager.getCurrentContext()).getQueue(GameTaskQueue.RENDER).execute(renderer);
		ContextGarbageCollector.doRuntimeCleanup(renderer);
		renderer.draw(rootNode);

		Debugger.drawBounds(selectedSpatial, renderer, false);
		return true;
	}

	// //////////// Picking //////////////////////////
	void pickWorldCoord(float mx, float my, boolean selectModel)
	{
		final Vector2 pos = Vector2.fetchTempInstance().set(mx, my);
		final Ray3 pickRay = new Ray3();
		Camera.getCurrentCamera().getPickRay(pos, false, pickRay);
		Vector2.releaseTempInstance(pos);

		if (selectedSpatial != null) // aseta objekti 3d-maailmaan
		{
			if (sky != null)
				rootNode.detachChild(sky);
			rootNode.detachChild(selectedSpatial);

			doPick(pickRay);

			rootNode.attachChild(selectedSpatial);
			if (sky != null)
				rootNode.attachChild(sky);
		} else if (selectModel)
			doPick(pickRay); // valitaan objekti
	}

	public PickResults doPick(final Ray3 pickRay)
	{
		final PrimitivePickResults pickResults = new PrimitivePickResults();
		pickResults.setCheckDistance(true);
		PickingUtil.findPick(rootNode, pickRay, pickResults);
		processPicks(pickResults);
		return pickResults;
	}

	protected void processPicks(final PrimitivePickResults pickResults)
	{
		if (selectedSpatial != null)
		{
			Vector3 v;
			if (pickResults.getNumber() > 0)
			{
				final PickData pick = pickResults.getPickData(0);
				v = pick.getIntersectionRecord().getIntersectionPoint(0);
			} else
				v = (Vector3) Vector3.ZERO;

			// jos pakotetaan Y haluttuun kohtaan
			if (GUI_Editor.chckbxForceY.isSelected())
			{
				float Y = Float.parseFloat(GUI_Editor.spinner_9.getValue().toString());
				GUI_Editor.spinner_1.setValue(Y);
				v.setY(Y);
			}

			// jos snap grid niin x ja z lasketaan sen mukaan
			if (GUI_Editor.chckbxGridSnapxz.isSelected())
			{
				int X = (int) v.getX(), Z = (int) v.getZ();
				v.setX(X);
				v.setZ(Z);
			}

			GUI_Editor.spinner.setValue((Float) v.getXf());
			GUI_Editor.spinner_1.setValue((Float) v.getYf());
			GUI_Editor.spinner_2.setValue((Float) v.getZf());
		} else
		{
			if (pickResults.getNumber() > 0)
			{
				final PickData pick = pickResults.getPickData(0);
				// get the name of the ancestor of this object that is right under the root node.
				if (pick.getTarget() instanceof Spatial)
				{
					selectedSpatial = getTopLevel((Spatial) pick.getTarget());
					GUI_Editor.txtTaskbar.setText(selectedSpatial.getName() + " selected.");

					// valitse scene listasta valittu obu
					GUI_Editor.treeScene.search(selectedSpatial.getName());

					movingMode = MovingModes.None;
					axisLock = AxisLock.None;
					GUI_Editor.txtTaskbar2.setText("");
				}
			} else
				GUI_Editor.txtTaskbar.setText("");

		}
	}

	void guiData_TO_GUI(String data)
	{
		// aseta data guihin
		data = data.replace('\0', ' ');
		data = data.replace('\n', ' ');
		String strs[] = data.split(" ");
		for (int c = 0; c < strs.length; c++)
		{
			String s = strs[c];
			if (s.contains("PHYSICOBJ"))
			{
				GUI_Editor.spinner_mass.setValue(Float.parseFloat(strs[c + 1]));
				c++;
			}
			if (s.contains("COLOR:"))
			{
				GUI_Editor.panelColor.setBackground(new Color(Integer.parseInt(strs[c + 1]), Integer.parseInt(strs[c + 2]), Integer.parseInt(strs[c + 3]),
						Integer.parseInt(strs[c + 4])));
//				GUI_Editor.panelColor.updateUI();
				c++;
			}
			if (s.contains("TEXTURE:"))
			{
				GUI_Editor.textField_texture.setText(strs[c + 1]);
//				GUI_Editor.textField_texture.updateUI();
				c++;
			}
			if (s.contains("SPHEREMAP:"))
			{
				GUI_Editor.textField_spheremap.setText(strs[c + 1]);
//				GUI_Editor.textField_spheremap.updateUI();
				c++;
			}
		}

		if (data.contains("PHYSICOBJ"))
			GUI_Editor.checkBoxPhysicObj.setSelected(true);
		else
			GUI_Editor.checkBoxPhysicObj.setSelected(false);
		if (data.contains("VISIBLE"))
			GUI_Editor.checkBoxVisible.setSelected(true);
		else
			GUI_Editor.checkBoxVisible.setSelected(false);
		if (data.contains("BLOCK"))
			GUI_Editor.checkBoxBlock.setSelected(true);
		else
			GUI_Editor.checkBoxBlock.setSelected(false);
		if (data.contains("CASTSHADOW"))
			GUI_Editor.checkBoxCastShadow.setSelected(true);
		else
			GUI_Editor.checkBoxCastShadow.setSelected(false);
	}

	void GUI_TO_guiData(Spatial sp)
	{
		if (sp == null)
			return;

		String data = "";

		if (GUI_Editor.checkBoxVisible.isSelected())
			data += "VISIBLE ";
		if (GUI_Editor.checkBoxBlock.isSelected())
			data += "BLOCK ";
		if (GUI_Editor.checkBoxCastShadow.isSelected())
			data += "CASTSHADOW ";

		if (GUI_Editor.checkBoxPhysicObj.isSelected())
		{
			data += "\nPHYSICOBJ ";
			data += Float.parseFloat(GUI_Editor.spinner_mass.getValue().toString()) + " ";
		}
		data += "\n";
		data += "COLOR: " + GUI_Editor.panelColor.getBackground().getRed() + " " + GUI_Editor.panelColor.getBackground().getGreen() + " "
				+ GUI_Editor.panelColor.getBackground().getBlue() + " " + GUI_Editor.panelColor.getBackground().getAlpha() + "\n";
		data += "TEXTURE: " + GUI_Editor.textField_texture.getText() + "\n";
		data += "SPHEREMAP: " + GUI_Editor.textField_spheremap.getText() + "\n";

		guiDatas.put(sp.getName(), data);
		userDatas.put(sp.getName(), GUI_Editor.textArea.getText());
	}

	private Spatial getTopLevel(final Spatial target)
	{
		if (target.getParent() == null || target.getParent().equals(rootNode))
			return target;
		else
			return getTopLevel(target.getParent());
	}

	public void updateMaterial()
	{
		updateMaterial(selectedSpatial);
	}

	// kutsu aina kun materiaalia muutettu (texture tai v�ri vaihdettu jne)
	public void updateMaterial(Spatial sp)
	{
		if (sp == null)
			return;

		updateSpatialMaterial(sp);

		// k�y meshit l�pi ja asettaa oikeat materiaalit ja tilat (l�ytyy userdatasta)
		sp.acceptVisitor(new Visitor()
		{
			public void visit(final Spatial spatial)
			{
				updateSpatialMaterial(spatial);
			}
		}, false);
	}

	void updateSpatialMaterial(Spatial spatial)
	{
		if (spatial instanceof Mesh)
		{
			Mesh m = (Mesh) spatial;

			final CullState cs = new CullState();
			cs.setCullFace(Face.Back);
			spatial.setRenderState(cs);

			final MaterialState ms = new MaterialState();
			// ms.setColorMaterial(ColorMaterial.Diffuse);

			TextureState ts = (TextureState) spatial.getLocalRenderState(StateType.Texture);
			if (ts == null)
				ts = new TextureState();

			String data = "";
			if (spatial.getName().contains("#terrain"))
				data = guiDatas.get("#terrain");
			else
				data = guiDatas.get(spatial.getName());

			data = data.replace('\0', ' ');
			data = data.replace('\n', ' ');
			data = data.replace('\r', ' ');
			String strs[] = data.split(" ");

			for (int c = 0; c < strs.length; c++)
			{
				String s = strs[c];
				if (s.contains("COLOR:"))
				{
					int R = Integer.parseInt(strs[c + 1]), G = Integer.parseInt(strs[c + 2]), B = Integer.parseInt(strs[c + 3]), A = Integer
							.parseInt(strs[c + 4]);
					ColorRGBA color = new ColorRGBA((float) R / 256f, (float) G / 256f, (float) B / 256f, (float) A / 256f);
					ms.setDiffuse(color);
					// ms.setAmbient(color);
					ms.setAmbient(ColorRGBA.DARK_GRAY);
					c += 4;
				}

				if (s.contains("TEXTURE:"))
				{
					if (strs[c + 1].contains("-none-"))
						continue;
					Texture tex = TextureManager.load(strs[c + 1], Texture.MinificationFilter.Trilinear, true);
					c++;
					ts.setTexture(tex, 0); // korvaa alkup tex
				}
			}

			if (data.contains("VISIBLE"))
				spatial.getSceneHints().setCullHint(CullHint.Dynamic);
			else
				spatial.getSceneHints().setCullHint(CullHint.Always);

			if (data.contains("CASTSHADOW"))
				spatial.getSceneHints().setCastsShadows(true);
			else
				spatial.getSceneHints().setCastsShadows(false);

			m.setRenderState(ms);
			m.setRenderState(ts);
		}
	}

	// ///////////// Kamera  /////////////////
	enum CamDirs
	{
		Startup, Top, Front, Right
	};

	private void setCamera(CamDirs cd)
	{
		switch (cd)
		{
		case Startup:
			Camera.getCurrentCamera().setLocation(0, 2, 5);
			break;
		case Top:
			Camera.getCurrentCamera().setLocation(0, 10, 0);
			break;
		case Front:
			Camera.getCurrentCamera().setLocation(0, 0, 10);
			break;
		case Right:
			Camera.getCurrentCamera().setLocation(10, 0, 0);
			break;
		}
		Camera.getCurrentCamera().lookAt(Vector3.ZERO, Vector3.UNIT_Y);
	}

	// ////// SAVE /////////
	public void save(String fileName)
	{
		Main.println("Saving " + fileName);

		/*
		 * FILEFORMAT:
		 * 
		 * #VERSIO
		 * float camspeed;
		 * SKYBOX: skybox-nimi ilman p��tett�
		 * 
		 * CAMERA: camname;
		 * vec3 pos;
		 * vec3 rot;
		 * 
		 * LIGHT: lightname;
		 * vec3 pos;
		 * vec3 dir;
		 * vec3 col;
		 *
		 * TERRAIN: heightmap-nimi
		 * vec3 scale
		 * 
		 * ja joka objektille:
		 * MODEL: objectName; // obun nimi joka n�kyy scene-listassa
		 * string filename; // modelin tiedostonimi
		 * vector3 pos,rot,scale; // paikka ja asento
		 *    MESH: meshin nimi
		 *    string userdata
		 * 
		 */

		try
		{
			FileWriter fstream = new FileWriter(fileName);
			BufferedWriter out = new BufferedWriter(fstream);
			out.write("#011\n"); // VERSIO
			out.write(camSpeed + "\n");

			String[] names = GUI_Editor.treeScene.getList();

			for (int q = 1; q < names.length; q++)
			{
				String curname = names[q];

				if (curname.contains("#camera"))
				{
					String data = "CAMERA: " + curname + "\n";
					Spatial sp = rootNode.getChild(curname);
					data += sp.getTranslation().getX() + " " + sp.getTranslation().getY() + " " + sp.getTranslation().getZ() + "\n";
					ReadOnlyMatrix3 mat = sp.getRotation();
					double[] angles = mat.toAngles(null);
					data += angles[0] * MathUtils.RAD_TO_DEG + " " + angles[1] * MathUtils.RAD_TO_DEG + " " + angles[2] * MathUtils.RAD_TO_DEG + "\n";
					out.write(data);
					continue;
				}
				if (curname.contains("#light"))
				{
					String data = "LIGHT: " + curname + "\n";
					List<Light> ls = lightState.getLightList();
					for (Light l : ls)
					{
						if (l.getName().equals(curname))
						{
							SpotLight sl = (SpotLight) l;
							data += sl.getLocation().getX() + " " + sl.getLocation().getY() + " " + sl.getLocation().getZ() + "\n";
							data += sl.getDirection().getX() + " " + sl.getDirection().getY() + " " + sl.getDirection().getZ() + "\n";
							data += "1.0 1.0 1.0\n"; // color  //sl.getDiffuse().getRed()+" "+sl.getDiffuse().getGreen()+" "+sl.getDiffuse().getBlue();
							break;
						}
					}
					out.write(data);
					continue;
				}

				if (curname.contains("#sky"))
				{
					out.write("SKYBOX: " + skyName + "\n");
					continue;
				}
				if (curname.contains("#terrain"))
				{
					out.write("TERRAIN: " + terrainName + "\n");
					String data = "";
					Spatial sp = rootNode.getChild(curname);
					data += sp.getScale().getX() + " " + sp.getScale().getY() + " " + sp.getScale().getZ() + "\n";
					out.write(data);
					continue;
				}

				String data = "";
				Spatial sp = rootNode.getChild(curname);
				String file = fileDatas.get(curname);

				if (file != null)
				{
					out.write("\nMODEL: " + curname + "\n");
					file = file.replace('\\', '/');
					file = file.substring(file.lastIndexOf('/') + 1, file.length());

					out.write(file + "\n");

					data += sp.getTranslation().getX() + " " + sp.getTranslation().getY() + " " + sp.getTranslation().getZ() + "\n";

					ReadOnlyMatrix3 mat = sp.getRotation();
					double[] angles = mat.toAngles(null);
					data += angles[0] * MathUtils.RAD_TO_DEG + " " + angles[1] * MathUtils.RAD_TO_DEG + " " + angles[2] * MathUtils.RAD_TO_DEG + "\n";

					data += sp.getScale().getX() + " " + sp.getScale().getY() + " " + sp.getScale().getZ() + "\n";
				} else
				{
					if (curname.equals("#floor (temp)") || curname.equals("#box"))
						continue;

					boolean write1 = false, write2 = false;

					if (guiDatas.get(curname).equals("VISIBLE BLOCK CASTSHADOW \nCOLOR: 255 255 255 255\nTEXTURE: -none-\nSPHEREMAP: -none-\n") == false)
						write1 = true;

					String dta = userDatas.get(curname);
					if (dta.length() > 0)
						write2 = true;

					// tallenna MESH jos dataa muutettu
					if (write1 || write2)
					{
						out.write("MESH: " + curname + "\n");
						if (write1)
							data += guiDatas.get(curname);

						if (write2)
							data += dta + "\n";
					}
				}

				out.write(data);
			}
			out.close();
			Main.println("OK.");
		} catch (Exception ex)
		{
			Main.println(ex.toString());
		}
	}
}
