package mjt.editor;

import java.io.File;
import java.util.concurrent.Callable;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import mjt.Settings;
import com.ardor3d.util.GameTaskQueueManager;

public class FileChooser_Save_Scene extends javax.swing.JFrame
{
	private javax.swing.JFileChooser jFileChooser1;

	public FileChooser_Save_Scene()
	{
		initComponents();

		final String PATH = Settings.resourceString + Settings.dataDir + "scenes";

		try
		{
			File f = new File(new File(PATH).getCanonicalPath());
			jFileChooser1.setCurrentDirectory(f);
		}
		catch (Exception e)
		{
		}

		jFileChooser1.setFileFilter(new Filter());
		int rVal = jFileChooser1.showSaveDialog(this);
		if (rVal == JFileChooser.APPROVE_OPTION)
		{
			final String name = jFileChooser1.getSelectedFile().getPath(); //.getName();

			GameTaskQueueManager.getManager(GUI_Editor.canvas.getCanvasRenderer().getRenderContext()).render(new Callable<Void>()
			{
				public Void call() throws Exception
				{
					String ext = "";
					if (name.contains(".jsce") == false)
						ext = ".jsce";
					Main.editor.save(name + ext);
					return null;
				}
			});
		}
	}

	private void initComponents()
	{
		jFileChooser1 = new javax.swing.JFileChooser();

		setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
		setAlwaysOnTop(true);
		setType(java.awt.Window.Type.POPUP);

		jFileChooser1.setDialogTitle("Save scene");

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				layout.createSequentialGroup().addComponent(jFileChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 473, javax.swing.GroupLayout.PREFERRED_SIZE).addContainerGap(
						javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				layout.createSequentialGroup().addComponent(jFileChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE).addContainerGap(
						javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));

		pack();
	}
}

class Filter extends FileFilter
{
	public boolean accept(File f)
	{
		if (f.isDirectory())
			return true;
		String s = f.getName();
		int i = s.lastIndexOf('.');

		if (i > 0 && i < s.length() - 1)
			if (s.substring(i + 1).toLowerCase().equals("jsce"))
				return true;

		return false;
	}

	public String getDescription()
	{
		return "Scene Files";
	}
}
