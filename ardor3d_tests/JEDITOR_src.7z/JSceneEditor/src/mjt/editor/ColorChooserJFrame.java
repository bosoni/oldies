package mjt.editor;

import java.util.concurrent.Callable;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import com.ardor3d.scenegraph.Mesh;
import com.ardor3d.scenegraph.Spatial;
import com.ardor3d.scenegraph.visitor.Visitor;
import com.ardor3d.util.GameTaskQueueManager;

public class ColorChooserJFrame extends javax.swing.JFrame implements ChangeListener
{
	private javax.swing.JColorChooser jColorChooser1;

	public ColorChooserJFrame()
	{
		initComponents();
		jColorChooser1.getSelectionModel().addChangeListener(this);
	}

	public void stateChanged(ChangeEvent e)
	{
		GUI_Editor.panelColor.setBackground(jColorChooser1.getColor());

		if (Main.editor.selectedSpatial == null)
			return;

		// run this in the opengl thread
		GameTaskQueueManager.getManager(GUI_Editor.canvas.getCanvasRenderer().getRenderContext()).render(new Callable<Void>()
		{
			public Void call() throws Exception
			{
				// ny pit�� vaihtaa modelin/meshin v�ri.
				// jos MODEL valittu, muuta kaikkien MESHIEN v�ri, mut jos valittuna meshi, muuta vain sen v�ri.

				if (GUI_Editor.treeScene.hasSelectedChildren()) // MODEL 
				{
					Main.editor.selectedSpatial.acceptVisitor(new Visitor() // k�y meshit l�pi
							{
								public void visit(final Spatial spatial)
								{
									if (spatial instanceof Mesh)
									{
										String data = Main.editor.guiDatas.get(spatial.getName());
										if (data == null)
											return;

										String col = "COLOR: " + GUI_Editor.panelColor.getBackground().getRed() + " "
												+ GUI_Editor.panelColor.getBackground().getGreen() + " " + GUI_Editor.panelColor.getBackground().getBlue()
												+ " " + GUI_Editor.panelColor.getBackground().getAlpha();
										String data2 = "";
										String dt[] = data.split("\n");
										for (String s : dt)
										{
											if (s.contains("COLOR"))
												s = col;
											data2 += s + "\n";
										}

										Main.editor.guiDatas.put(spatial.getName(), data2);
									}
								}
							}, false);
				} else
				{
					// MESH
					Main.editor.GUI_TO_guiData(Main.editor.selectedSpatial);
				}

				Main.editor.updateMaterial();
				
				return null;
			}
		});

	}

	private void initComponents()
	{
		jColorChooser1 = new javax.swing.JColorChooser();

		setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
		setTitle("Change color");
		setAlwaysOnTop(true);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				layout.createSequentialGroup()
						.addComponent(jColorChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 620, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				layout.createSequentialGroup()
						.addComponent(jColorChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		pack();
	}
}
