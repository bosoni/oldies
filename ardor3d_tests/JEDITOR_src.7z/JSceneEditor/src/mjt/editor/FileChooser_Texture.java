package mjt.editor;

import java.io.File;
import java.util.concurrent.Callable;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import mjt.Settings;
import com.ardor3d.scenegraph.Mesh;
import com.ardor3d.scenegraph.Spatial;
import com.ardor3d.scenegraph.visitor.Visitor;
import com.ardor3d.util.GameTaskQueueManager;

public class FileChooser_Texture extends javax.swing.JFrame
{
	private javax.swing.JFileChooser jFileChooser1;

	public FileChooser_Texture(final int mode)
	{
		initComponents();

		final String PATH = Settings.resourceString + Settings.dataDir + "textures";

		try
		{
			File f = new File(new File(PATH).getCanonicalPath());
			jFileChooser1.setCurrentDirectory(f);
		} catch (Exception e)
		{
		}

		jFileChooser1.setFileFilter(new ImageFilter());
		int rVal = jFileChooser1.showOpenDialog(this);
		if (rVal == JFileChooser.APPROVE_OPTION)
		{

			// run this in the opengl thread
			GameTaskQueueManager.getManager(GUI_Editor.canvas.getCanvasRenderer().getRenderContext()).render(new Callable<Void>()
			{
				public Void call() throws Exception
				{
					switch (mode)
					{
					case 1:
						GUI_Editor.textField_texture.setText(jFileChooser1.getSelectedFile().getName());
						break;
					case 2:
						GUI_Editor.textField_spheremap.setText(jFileChooser1.getSelectedFile().getName());
						break;

					case 3:
						Main.editor.loadTerrain(jFileChooser1.getSelectedFile().getName());
						break;
					case 4:
						Main.editor.loadTileMap(jFileChooser1.getSelectedFile().getName());
						break;

					}

					if (mode == 1 || mode == 2)
					{
						// ny pit�� vaihtaa modelin/meshin texture.
						// jos MODEL valittu, muuta kaikkien MESHIEN texture. jos mesh valittu, vaihda vain sen texture
						if (GUI_Editor.treeScene.hasSelectedChildren()) // MODEL 
						{
							Main.editor.selectedSpatial.acceptVisitor(new Visitor() // k�y meshit l�pi
									{
										public void visit(final Spatial spatial)
										{
											if (spatial instanceof Mesh)
											{
												String data = Main.editor.guiDatas.get(spatial.getName());
												String data2 = "";
												String dt[] = data.split("\n");

												if (mode == 1)
												{
													String t = "TEXTURE: " + GUI_Editor.textField_texture.getText();
													for (String s : dt)
													{
														if (s.contains("TEXTURE"))
															s = t;
														data2 += s + "\n";
													}
												} else
												{
													String t = "SPHEREMAP: " + GUI_Editor.textField_spheremap.getText();
													for (String s : dt)
													{
														if (s.contains("SPHEREMAP"))
															s = t;
														data2 += s + "\n";
													}
												}

												Main.editor.guiDatas.put(spatial.getName(), data2);
											}
										}
									}, false);
						} else
						{
							// MESH
							Main.editor.GUI_TO_guiData(Main.editor.selectedSpatial);
						}
					}

					Main.editor.updateMaterial();

					return null;
				}
			});

		}
	}

	private void initComponents()
	{
		jFileChooser1 = new javax.swing.JFileChooser();

		setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
		setAlwaysOnTop(true);
		setType(java.awt.Window.Type.POPUP);

		jFileChooser1.setDialogTitle("Choose texture");

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				layout.createSequentialGroup().addComponent(jFileChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 473, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				layout.createSequentialGroup().addComponent(jFileChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));

		pack();
	}
}

class ImageFilter extends FileFilter
{
	public boolean accept(File f)
	{
		if (f.isDirectory())
			return true;
		String s = f.getName();
		int i = s.lastIndexOf('.');

		if (i > 0 && i < s.length() - 1)
			if (s.substring(i + 1).toLowerCase().equals("jpg") || s.substring(i + 1).toLowerCase().equals("png")
					|| s.substring(i + 1).toLowerCase().equals("dds"))
				return true;

		return false;
	}

	public String getDescription()
	{
		return "Image Files";
	}
}
