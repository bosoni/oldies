package mjt.editor;

import java.net.URISyntaxException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import mjt.Settings;
import com.ardor3d.framework.DisplaySettings;
import com.ardor3d.framework.FrameHandler;
import com.ardor3d.framework.lwjgl.LwjglAwtCanvas;
import com.ardor3d.framework.lwjgl.LwjglCanvasRenderer;
import com.ardor3d.image.util.AWTImageLoader;
import com.ardor3d.input.ControllerWrapper;
import com.ardor3d.input.PhysicalLayer;
import com.ardor3d.input.awt.AwtFocusWrapper;
import com.ardor3d.input.awt.AwtKeyboardWrapper;
import com.ardor3d.input.awt.AwtMouseManager;
import com.ardor3d.input.awt.AwtMouseWrapper;
import com.ardor3d.input.logical.DummyControllerWrapper;
import com.ardor3d.input.logical.LogicalLayer;
import com.ardor3d.util.Timer;
import com.ardor3d.util.resource.ResourceLocatorTool;
import com.ardor3d.util.resource.SimpleResourceLocator;

public class Main
{
	public final static Timer timer = new Timer();
	static boolean running = true;
	static GUI_Editor gui;
	static Editor editor;

	public static void main(final String[] args) throws Exception
	{
		new Main();
	}

	public static void println(String str)
	{
		System.out.println(str);
	}

	public Main() throws Exception
	{
		// SETUP: //////////////////////////////////////////////////
		
		Settings.DEBUG = true; // use if you are using ide
		//Settings.DEBUG = false; // use if you export runnable jar

		///////////////////////////////////////////////////////////
		
		
		if(Settings.DEBUG==false) Settings.resourceString = "";
		
		try
		{
			javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getSystemLookAndFeelClassName());
		} catch (Exception ex)
		{
			Main.println(ex.toString());
		}

		final Timer timer = new Timer();
		final FrameHandler frameWork = new FrameHandler(timer);
		final LogicalLayer logicalLayer = new LogicalLayer();

		editor = new Editor(logicalLayer);
		frameWork.addUpdater(editor);
		AWTImageLoader.registerLoader();

		try
		{
			ResourceLocatorTool.addResourceLocator(ResourceLocatorTool.TYPE_MODEL,
					new SimpleResourceLocator(ResourceLocatorTool.getClassPathResource(Main.class, Settings.dataDir + "models/")));
			ResourceLocatorTool.addResourceLocator(ResourceLocatorTool.TYPE_TEXTURE,
					new SimpleResourceLocator(ResourceLocatorTool.getClassPathResource(Main.class, Settings.dataDir + "textures/")));
			//ResourceLocatorTool.addResourceLocator(ResourceLocatorTool.TYPE_SHADER, new SimpleResourceLocator(ResourceLocatorTool.getClassPathResource(Main.class, Settings.dataDir + "shaders/")));
		} catch (final URISyntaxException ex)
		{
			Main.println(ex.toString());
		}

		final LwjglCanvasRenderer canvasRenderer = new LwjglCanvasRenderer(editor);
		final DisplaySettings settings = new DisplaySettings(500, 500, 24, 0, 0, 16, 0, 0, false, false);
		final LwjglAwtCanvas theCanvas = new LwjglAwtCanvas(settings, canvasRenderer);
		final AwtKeyboardWrapper keyboardWrapper = new AwtKeyboardWrapper(theCanvas);
		final AwtFocusWrapper focusWrapper = new AwtFocusWrapper(theCanvas);
		final AwtMouseManager mouseManager = new AwtMouseManager(theCanvas);
		final AwtMouseWrapper mouseWrapper = new AwtMouseWrapper(theCanvas, mouseManager);
		final ControllerWrapper controllerWrapper = new DummyControllerWrapper();
		final PhysicalLayer pl = new PhysicalLayer(keyboardWrapper, mouseWrapper, controllerWrapper, focusWrapper);
		logicalLayer.registerInput(theCanvas, pl);

		gui = new GUI_Editor(theCanvas);
		frameWork.addCanvas(theCanvas);
		Thread.sleep(1000);
		editor.init();

		while (running)
		{
			Thread.sleep(1);
			frameWork.updateFrame();
			Thread.yield();
		}

		System.exit(0);
	}
}
