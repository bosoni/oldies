package mjt.editor;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Random;
import java.util.concurrent.Callable;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.MatteBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import mjt.Settings;
import mjt.TreeHelper;
import com.ardor3d.framework.lwjgl.LwjglAwtCanvas;
import com.ardor3d.renderer.Camera;
import com.ardor3d.util.GameTaskQueueManager;

public class GUI_Editor
{
	static Random rnd = new Random();
	static ArrayList<String> fileNames = new ArrayList<String>();
	static JSpinner spinner, spinner_1, spinner_2, spinner_3, spinner_4, spinner_5, spinner_6, spinner_7, spinner_8; // pos, rot, scale - xyz
	static JSpinner spinner_9, spinner_10, spinner_11, spinner_12, spinner_13, spinner_14, spinner_15, spinner_16, spinner_mass;
	static JCheckBox chckbxAutorand, chckbxGridSnapxz, chckbxForceY, checkBoxVisible, checkBoxBlock, checkBoxPhysicObj, checkBoxCastShadow;
	static JCheckBox checkBox, checkBox_1, checkBox_2, checkBox_3, checkBox_4, checkBox_5, checkBox_6, checkBox_7, checkBox_8, chckbxShowGrid;
	static LwjglAwtCanvas canvas;
	static JTextField txtTaskbar, txtTaskbar2, txtSearch;
	JFrame formMainWindow;
	JLabel collapseLabel;
	JLabel lblX, lblY, lblZ, lblMin, lblMax;
	JSplitPane splitPane;
	JScrollPane scrollPane, scrollPane_1;
	private JTree treeFiles, treeSceneObjects;
	static TreeHelper treeScene = new TreeHelper();
	static JPanel panel, panelColor;
	static String _tempString = "";
	private JMenuItem mntmImportTilemap;
	private JMenuItem mntmImportHeightmap;
	private JTextField textField;
	static JTextArea textArea;
	static JTextField textField_texture, textField_spheremap;

	public GUI_Editor(LwjglAwtCanvas canvas)
	{
		GUI_Editor.canvas = canvas;
		initialize();
		formMainWindow.setVisible(true);
		listFiles(true);
	}

	public boolean loadModel(String name)
	{
		if (name.toLowerCase().contains(".obj") || name.toLowerCase().contains(".dae") || name.toLowerCase().contains(".md2"))
		{
			for (String s : fileNames)
				if (s.contains(name))
				{
					name = s;
					break;
				}
			_tempString = name;

			// run this in the opengl thread
			GameTaskQueueManager.getManager(canvas.getCanvasRenderer().getRenderContext()).render(new Callable<Void>()
			{
				public Void call() throws Exception
				{
					textField_texture.setText("-none-");
					textField_spheremap.setText("-none-");
					panelColor.setBackground(Color.WHITE);
					
					Main.editor.loadModel(_tempString);

					canvas.requestFocus();
					return null;
				}
			});
			return true;
		}
		return false;
	}

	public static void RandomizeSpinners()
	{
		// pos
		float x = Float.parseFloat(spinner.getValue().toString());
		float y = Float.parseFloat(spinner_1.getValue().toString());
		float z = Float.parseFloat(spinner_2.getValue().toString());

		// spinnerit 10-15 min/max checkbox - checkbox8 random t�pit
		float pmin = Float.parseFloat(spinner_10.getValue().toString()); // pos
		float pmax = Float.parseFloat(spinner_11.getValue().toString());
		float rmin = Float.parseFloat(spinner_12.getValue().toString()); // rot
		float rmax = Float.parseFloat(spinner_13.getValue().toString());
		float smin = Float.parseFloat(spinner_14.getValue().toString()); // scale
		float smax = Float.parseFloat(spinner_15.getValue().toString());
		float pdist = pmax - pmin, rdist = rmax - rmin, sdist = smax - smin;

		if (checkBox.isSelected())
			GUI_Editor.spinner.setValue(x + pmin + pdist * rnd.nextFloat());
		if (checkBox_1.isSelected())
			GUI_Editor.spinner_1.setValue(y + pmin + pdist * rnd.nextFloat());
		if (checkBox_2.isSelected())
			GUI_Editor.spinner_2.setValue(z + pmin + pdist * rnd.nextFloat());

		if (checkBox_3.isSelected())
			GUI_Editor.spinner_3.setValue(rmin + rdist * rnd.nextFloat());
		if (checkBox_4.isSelected())
			GUI_Editor.spinner_4.setValue(rmin + rdist * rnd.nextFloat());
		if (checkBox_5.isSelected())
			GUI_Editor.spinner_5.setValue(rmin + rdist * rnd.nextFloat());

		if (checkBox_6.isSelected())
			GUI_Editor.spinner_6.setValue(smin + sdist * rnd.nextFloat());
		if (checkBox_7.isSelected())
			GUI_Editor.spinner_7.setValue(smin + sdist * rnd.nextFloat());
		if (checkBox_8.isSelected())
			GUI_Editor.spinner_8.setValue(smin + sdist * rnd.nextFloat());
	}

	private void initialize()
	{
		formMainWindow = new JFrame();
		formMainWindow.setTitle("JSceneEditor");
		formMainWindow.setBounds(100, 100, 930, 692);
		formMainWindow.getContentPane().setLayout(null);
		// formMainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		formMainWindow.addWindowListener(new WindowAdapter()
		{
			@Override
			public void windowClosing(final WindowEvent e)
			{
				Main.running = false;
			}
		});

		panel = new JPanel();
		panel.setBounds(0, 20, 394, 633);
		formMainWindow.getContentPane().add(panel);
		panel.setLayout(null);

		canvas.setBounds(panel.getWidth(), 0, 547, 654);
		formMainWindow.getContentPane().add(canvas);

		collapseLabel = new JLabel("[C]");
		collapseLabel.addMouseListener(new MouseAdapter()
		{
			@Override
			public void mouseClicked(MouseEvent arg0)
			{
				if (collapseLabel.getText() == "[C]") // collapse
				{
					expandFileList(treeFiles, false);
					collapseLabel.setText("[E]");
				} else
				// expand
				{
					expandFileList(treeFiles, true);
					collapseLabel.setText("[C]");
				}

			}
		});
		collapseLabel.setFont(new Font("Tahoma", Font.PLAIN, 11));
		collapseLabel.setBounds(200, 612, 15, 14);
		panel.add(collapseLabel);

		splitPane = new JSplitPane();
		splitPane.setResizeWeight(0.5);
		splitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
		splitPane.setBounds(192, 0, 202, 607);
		panel.add(splitPane);

		scrollPane = new JScrollPane();
		splitPane.setLeftComponent(scrollPane);

		treeSceneObjects = new JTree();
		treeSceneObjects.addMouseListener(new MouseAdapter()
		{
			@Override
			public void mousePressed(final MouseEvent arg0)
			{
				// run this in the opengl thread
				GameTaskQueueManager.getManager(canvas.getCanvasRenderer().getRenderContext()).render(new Callable<Void>()
				{
					public Void call() throws Exception
					{
						TreePath tp = treeSceneObjects.getPathForLocation(arg0.getX(), arg0.getY());
						if (tp != null)
						{
							Main.editor.selectMesh(treeScene.getSelected());
							canvas.requestFocus();
						}
						return null;
					}
				});
			}
		});

		treeSceneObjects.addKeyListener(new KeyAdapter()
		{
			@Override
			public void keyPressed(KeyEvent arg0)
			{
				// jos painetaan DEL niin poista obu listasta
				if (arg0.getKeyCode() == KeyEvent.VK_DELETE)
				{
					// run this in the opengl thread
					GameTaskQueueManager.getManager(canvas.getCanvasRenderer().getRenderContext()).render(new Callable<Void>()
					{
						public Void call() throws Exception
						{
							Main.editor.deleteObjectFromList();
							return null;
						}
					});
				}
			}
		});
		treeSceneObjects.setModel(new DefaultTreeModel(new DefaultMutableTreeNode("Scene")
		{
			{
			}
		}));
		scrollPane.setViewportView(treeSceneObjects);
		treeScene.use(treeSceneObjects);

		DefaultListModel<String> lm = new DefaultListModel<String>();

		scrollPane_1 = new JScrollPane();
		splitPane.setRightComponent(scrollPane_1);

		treeFiles = new JTree();
		treeFiles.setModel(new DefaultTreeModel(new DefaultMutableTreeNode("media")
		{
			{
			}
		}));
		scrollPane_1.setViewportView(treeFiles);

		JLabel label_2 = new JLabel("Position");
		label_2.setBounds(4, 0, 83, 14);
		panel.add(label_2);

		JLabel label_3 = new JLabel("Rotation");
		label_3.setBounds(4, 44, 83, 14);
		panel.add(label_3);

		JLabel label_4 = new JLabel("Scale");
		label_4.setBounds(4, 87, 83, 14);
		panel.add(label_4);

		spinner = new JSpinner();
		spinner.setModel(new SpinnerNumberModel(new Float(0), null, null, new Float(1f)));
		spinner.setBounds(4, 15, 60, 20);
		panel.add(spinner);

		spinner_1 = new JSpinner();
		spinner_1.setModel(new SpinnerNumberModel(new Float(0), null, null, new Float(1f)));
		spinner_1.setBounds(66, 15, 60, 20);
		panel.add(spinner_1);

		spinner_2 = new JSpinner();
		spinner_2.setModel(new SpinnerNumberModel(new Float(0), null, null, new Float(1f)));
		spinner_2.setBounds(128, 15, 60, 20);
		panel.add(spinner_2);

		spinner_3 = new JSpinner();
		spinner_3.setModel(new SpinnerNumberModel(new Float(0), null, null, new Float(10)));
		spinner_3.setBounds(4, 59, 60, 20);
		panel.add(spinner_3);

		spinner_4 = new JSpinner();
		spinner_4.setModel(new SpinnerNumberModel(new Float(0), null, null, new Float(10)));
		spinner_4.setBounds(66, 59, 60, 20);
		panel.add(spinner_4);

		spinner_5 = new JSpinner();
		spinner_5.setModel(new SpinnerNumberModel(new Float(0), null, null, new Float(10)));
		spinner_5.setBounds(128, 59, 60, 20);
		panel.add(spinner_5);

		spinner_6 = new JSpinner();
		spinner_6.setModel(new SpinnerNumberModel(new Double(1), new Double(0.0001f), null, new Double(0.1f)));
		spinner_6.setBounds(4, 102, 60, 20);
		panel.add(spinner_6);

		spinner_7 = new JSpinner();
		spinner_7.setModel(new SpinnerNumberModel(new Float(1), new Float(0.0001f), null, new Float(0.1f)));
		spinner_7.setBounds(66, 102, 60, 20);
		panel.add(spinner_7);

		spinner_8 = new JSpinner();
		spinner_8.setModel(new SpinnerNumberModel(new Float(1), new Float(0.0001f), null, new Float(0.1f)));
		spinner_8.setBounds(128, 102, 60, 20);
		panel.add(spinner_8);

		txtTaskbar = new JTextField();
		txtTaskbar.setFont(new Font("Segoe UI", Font.PLAIN, 10));
		txtTaskbar.setEditable(false);
		txtTaskbar.setEnabled(false);
		txtTaskbar.setText("Welcome to JSceneEditor.");
		txtTaskbar.setBounds(0, 612, 126, 20);
		panel.add(txtTaskbar);

		txtSearch = new JTextField();
		txtSearch.setText(".obj");
		txtSearch.addKeyListener(new KeyAdapter()
		{
			@Override
			public void keyTyped(KeyEvent e)
			{
				listFiles(true);
			}
		});
		txtSearch.setBounds(218, 609, 176, 20);
		panel.add(txtSearch);

		JLabel lblRandom = new JLabel("Random");
		lblRandom.setBounds(4, 146, 46, 14);
		panel.add(lblRandom);

		txtTaskbar2 = new JTextField();
		txtTaskbar2.setFont(new Font("Segoe UI", Font.PLAIN, 10));
		txtTaskbar2.setEnabled(false);
		txtTaskbar2.setEditable(false);
		txtTaskbar2.setBounds(128, 612, 62, 20);
		panel.add(txtTaskbar2);
		txtTaskbar2.setColumns(10);

		JLabel label = new JLabel("Position");
		label.setBounds(4, 165, 46, 14);
		panel.add(label);

		JLabel label_1 = new JLabel("Rotation");
		label_1.setBounds(4, 184, 51, 14);
		panel.add(label_1);

		JLabel label_5 = new JLabel("Scale");
		label_5.setBounds(4, 204, 46, 14);
		panel.add(label_5);

		lblX = new JLabel("X");
		lblX.setBounds(52, 146, 11, 14);
		panel.add(lblX);

		lblMin = new JLabel("Min");
		lblMin.setBounds(103, 146, 23, 14);
		panel.add(lblMin);

		lblMax = new JLabel("Max");
		lblMax.setBounds(149, 146, 26, 14);
		panel.add(lblMax);

		chckbxAutorand = new JCheckBox("AutoRand");
		chckbxAutorand.setBounds(112, 231, 74, 19);
		panel.add(chckbxAutorand);

		JButton btnRandomize = new JButton("Randomize");
		btnRandomize.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				RandomizeSpinners();
			}
		});
		btnRandomize.setBounds(2, 229, 85, 23);
		panel.add(btnRandomize);

		chckbxGridSnapxz = new JCheckBox("Grid Snap (XZ)");
		chckbxGridSnapxz.setBounds(4, 472, 122, 23);
		panel.add(chckbxGridSnapxz);

		chckbxForceY = new JCheckBox("Force Y");
		chckbxForceY.setBounds(4, 496, 83, 23);
		panel.add(chckbxForceY);

		spinner_9 = new JSpinner();
		spinner_9.setModel(new SpinnerNumberModel(new Float(0), null, null, new Float(0.1f)));
		spinner_9.setBounds(120, 499, 70, 20);
		panel.add(spinner_9);

		checkBox = new JCheckBox("");
		checkBox.setBounds(45, 159, 22, 23);
		panel.add(checkBox);

		checkBox_1 = new JCheckBox("");
		checkBox_1.setBounds(64, 159, 22, 23);
		panel.add(checkBox_1);

		checkBox_2 = new JCheckBox("");
		checkBox_2.setBounds(83, 159, 19, 23);
		panel.add(checkBox_2);

		lblY = new JLabel("Y");
		lblY.setBounds(71, 146, 11, 14);
		panel.add(lblY);

		lblZ = new JLabel("Z");
		lblZ.setBounds(89, 146, 11, 14);
		panel.add(lblZ);

		checkBox_3 = new JCheckBox("");
		checkBox_3.setBounds(45, 179, 22, 23);
		panel.add(checkBox_3);

		checkBox_4 = new JCheckBox("");
		checkBox_4.setBounds(64, 179, 22, 23);
		panel.add(checkBox_4);

		checkBox_5 = new JCheckBox("");
		checkBox_5.setBounds(83, 179, 19, 23);
		panel.add(checkBox_5);

		checkBox_6 = new JCheckBox("");
		checkBox_6.setBounds(45, 199, 22, 23);
		panel.add(checkBox_6);

		checkBox_7 = new JCheckBox("");
		checkBox_7.setBounds(64, 199, 22, 23);
		panel.add(checkBox_7);

		checkBox_8 = new JCheckBox("");
		checkBox_8.setBounds(83, 199, 18, 23);
		panel.add(checkBox_8);

		spinner_10 = new JSpinner();
		spinner_10.setModel(new SpinnerNumberModel(new Float(-0.1f), null, null, new Float(0.1f)));
		spinner_10.setBounds(103, 162, 46, 17);
		panel.add(spinner_10);

		spinner_11 = new JSpinner();
		spinner_11.setModel(new SpinnerNumberModel(new Float(0.1f), null, null, new Float(0.1f)));
		spinner_11.setBounds(147, 162, 46, 17);
		panel.add(spinner_11);

		spinner_12 = new JSpinner();
		spinner_12.setModel(new SpinnerNumberModel(new Float(0), null, null, new Float(5f)));
		spinner_12.setBounds(103, 182, 46, 17);
		panel.add(spinner_12);

		spinner_13 = new JSpinner();
		spinner_13.setModel(new SpinnerNumberModel(new Float(360), null, null, new Float(5f)));
		spinner_13.setBounds(147, 182, 46, 17);
		panel.add(spinner_13);

		spinner_14 = new JSpinner();
		spinner_14.setModel(new SpinnerNumberModel(new Float(0.8f), new Float(0), null, new Float(0.1f)));
		spinner_14.setBounds(103, 202, 46, 17);
		panel.add(spinner_14);

		spinner_15 = new JSpinner();
		spinner_15.setModel(new SpinnerNumberModel(new Float(1.2f), new Float(0), null, new Float(0.1f)));
		spinner_15.setBounds(147, 203, 46, 17);
		panel.add(spinner_15);

		JSeparator separator = new JSeparator();
		separator.setBounds(-2, 262, 196, 14);
		panel.add(separator);

		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(0, 133, 190, 14);
		panel.add(separator_1);

		chckbxShowGrid = new JCheckBox("Show Grid");
		chckbxShowGrid.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				if (chckbxShowGrid.isSelected())
					Main.editor.rootNode.attachChild(Main.editor.gridLine);
				else
					Main.editor.rootNode.detachChild(Main.editor.gridLine);
			}
		});
		chckbxShowGrid.setSelected(true);
		chckbxShowGrid.setBounds(4, 450, 97, 23);
		panel.add(chckbxShowGrid);

		JLabel lblCameraSpeed = new JLabel("Camera Speed");
		lblCameraSpeed.setBounds(8, 524, 98, 14);
		panel.add(lblCameraSpeed);

		spinner_16 = new JSpinner();
		spinner_16.addChangeListener(new ChangeListener()
		{
			public void stateChanged(ChangeEvent arg0)
			{
				Editor.camSpeed = Float.parseFloat((String) spinner_16.getValue().toString());
				Main.editor.fpsControl.setMoveSpeed(Editor.camSpeed);
			}
		});
		spinner_16.setModel(new SpinnerNumberModel(new Float(5), new Float(0), null, new Float(1)));
		spinner_16.setBounds(119, 521, 70, 20);
		panel.add(spinner_16);

		JLabel lblSkyboxName = new JLabel("Skybox");
		lblSkyboxName.setBounds(4, 278, 62, 14);
		panel.add(lblSkyboxName);

		textField = new JTextField();
		textField.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				// run this in the opengl thread
				GameTaskQueueManager.getManager(canvas.getCanvasRenderer().getRenderContext()).render(new Callable<Void>()
				{
					public Void call() throws Exception
					{
						Main.editor.loadSkybox(textField.getText());
						return null;
					}
				});
			}
		});
		textField.setBounds(52, 275, 136, 20);
		panel.add(textField);
		textField.setColumns(10);

		JLabel label_6 = new JLabel("UserData");
		label_6.setBounds(4, 550, 65, 14);
		panel.add(label_6);

		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(4, 564, 186, 43);
		panel.add(scrollPane_2);

		textArea = new JTextArea();
		textArea.setTabSize(4);
		textArea.setRows(4);
		textArea.setLineWrap(true);
		scrollPane_2.setViewportView(textArea);

		checkBoxVisible = new JCheckBox("Visible");
		checkBoxVisible.setSelected(true);
		checkBoxVisible.setBounds(4, 394, 60, 23);
		panel.add(checkBoxVisible);

		checkBoxBlock = new JCheckBox("Block");
		checkBoxBlock.setSelected(true);
		checkBoxBlock.setBounds(106, 394, 60, 23);
		panel.add(checkBoxBlock);

		checkBoxPhysicObj = new JCheckBox("PhysicObj");
		checkBoxPhysicObj.setBounds(4, 420, 87, 25);
		panel.add(checkBoxPhysicObj);

		spinner_mass = new JSpinner();
		spinner_mass.setBounds(134, 422, 58, 20);
		panel.add(spinner_mass);

		JLabel label_7 = new JLabel("Mass");
		label_7.setBounds(96, 425, 33, 14);
		panel.add(label_7);

		JLabel label_8 = new JLabel("Color");
		label_8.setBounds(128, 546, 35, 14);
		panel.add(label_8);

		panelColor = new JPanel();
		panelColor.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panelColor.setBackground(Color.WHITE);
		panelColor.setBounds(167, 544, 23, 20);
		panelColor.addMouseListener(new MouseAdapter()
		{
			@Override
			public void mousePressed(MouseEvent arg0)
			{
				ColorChooserJFrame window = new ColorChooserJFrame();
				window.setVisible(true);
			}
		});
		panel.add(panelColor);

		checkBoxCastShadow = new JCheckBox("Cast Shadow");
		checkBoxCastShadow.setSelected(true);
		checkBoxCastShadow.setBounds(4, 368, 115, 23);
		panel.add(checkBoxCastShadow);

		JLabel label_9 = new JLabel("Texture:");
		label_9.setBounds(4, 307, 60, 14);
		panel.add(label_9);

		textField_texture = new JTextField();
		textField_texture.setText("-none-");
		textField_texture.setColumns(10);
		textField_texture.setBounds(66, 304, 60, 20);
		panel.add(textField_texture);

		JButton button_opentexture = new JButton("Open");
		button_opentexture.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				new FileChooser_Texture(1);
			}
		});
		button_opentexture.setBounds(128, 303, 60, 23);
		panel.add(button_opentexture);

		JLabel label_10 = new JLabel("SphereMap:");
		label_10.setBounds(4, 329, 60, 14);
		panel.add(label_10);

		textField_spheremap = new JTextField();
		textField_spheremap.setText("-none-");
		textField_spheremap.setColumns(10);
		textField_spheremap.setBounds(66, 326, 60, 20);
		panel.add(textField_spheremap);

		JButton button_openspheremap = new JButton("Open");
		button_openspheremap.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				new FileChooser_Texture(2);
			}
		});
		button_openspheremap.setBounds(128, 325, 60, 23);
		panel.add(button_openspheremap);

		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 394, 21);
		formMainWindow.getContentPane().add(menuBar);

		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);

		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				Main.running = false;
			}
		});

		JMenuItem mntmNew = new JMenuItem("New (restart editor)");
		mntmNew.setEnabled(false);
		mntmNew.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				// TODO new
			}
		});
		mnFile.add(mntmNew);

		JMenuItem mntmOpen = new JMenuItem("Open");
		mntmOpen.setEnabled(false);
		mntmOpen.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				// TODO open
			}
		});
		mnFile.add(mntmOpen);

		JMenuItem mntmSaveAs = new JMenuItem("Save As...");
		mntmSaveAs.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				// save as
				new FileChooser_Save_Scene();
			}
		});
		mnFile.add(mntmSaveAs);

		mntmImportTilemap = new JMenuItem("Import TileMap");
		mntmImportTilemap.setEnabled(false); // TODO
		mntmImportTilemap.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				// run this in the opengl thread
				GameTaskQueueManager.getManager(canvas.getCanvasRenderer().getRenderContext()).render(new Callable<Void>()
				{
					public Void call() throws Exception
					{
						new FileChooser_Texture(4);
						return null;
					}
				});

			}
		});
		mnFile.add(mntmImportTilemap);

		mntmImportHeightmap = new JMenuItem("Import Heightmap");
		mntmImportHeightmap.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				// run this in the opengl thread
				GameTaskQueueManager.getManager(canvas.getCanvasRenderer().getRenderContext()).render(new Callable<Void>()
				{
					public Void call() throws Exception
					{
						new FileChooser_Texture(3);
						return null;
					}
				});
			}
		});
		mnFile.add(mntmImportHeightmap);
		mnFile.add(mntmExit);

		JMenu mnCamera = new JMenu("Create");
		menuBar.add(mnCamera);

		JMenuItem mntmCreateCamera = new JMenuItem("Create Camera");
		mntmCreateCamera.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				// run this in the opengl thread
				GameTaskQueueManager.getManager(canvas.getCanvasRenderer().getRenderContext()).render(new Callable<Void>()
				{
					public Void call() throws Exception
					{
						Main.editor.createLightOrCamera(1);
						return null;
					}
				});
			}
		});
		mnCamera.add(mntmCreateCamera);

		JMenuItem mntmCreateLight = new JMenuItem("Create Light");
		mnCamera.add(mntmCreateLight);
		mntmCreateLight.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				// run this in the opengl thread
				GameTaskQueueManager.getManager(canvas.getCanvasRenderer().getRenderContext()).render(new Callable<Void>()
				{
					public Void call() throws Exception
					{
						Main.editor.createLightOrCamera(2);
						return null;
					}
				});
			}
		});

		JMenu mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);

		JMenuItem mntmHotkeys = new JMenuItem("Hotkeys");
		mntmHotkeys.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				Editor.showHotkeys();
			}
		});
		mnHelp.add(mntmHotkeys);

		JMenuItem mntmAbout = new JMenuItem("About");
		mntmAbout.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				JOptionPane.showMessageDialog(null, "JSceneEditor\n(c) by mjt, 2012\nmixut@hotmail.com");
			}
		});
		mnHelp.add(mntmAbout);

		formMainWindow.addComponentListener(new ComponentAdapter()
		{
			@Override
			public void componentResized(ComponentEvent arg0)
			{
				canvas.setBounds(panel.getWidth(), 0, formMainWindow.getWidth() - panel.getWidth(), formMainWindow.getHeight());

				final Camera camera = Camera.getCurrentCamera();
				if (camera == null)
					return;

				camera.resize(canvas.getWidth(), canvas.getHeight());
				camera.setViewPort(0, 1, 0, 1);
				camera.update();

				// RESIZE ei oo oikein, meinaa skene skaalautuu ja pallosta tulee soikio.

				// alimmat komponentit laitetaan ruudun alareunaan. skaalataan my�s listat.
				panel.setBounds(0, 22, panel.getWidth(), formMainWindow.getHeight());
				splitPane.setBounds(192, 0, 202, formMainWindow.getHeight() - 85);
				splitPane.updateUI();
				txtTaskbar.setBounds(0, formMainWindow.getHeight() - 80, 126, 20);
				txtTaskbar2.setBounds(128, formMainWindow.getHeight() - 80, 62, 20);
				txtSearch.setBounds(218, formMainWindow.getHeight() - 80, 176, 20);
				collapseLabel.setBounds(200, formMainWindow.getHeight() - 80, 15, 14);
			}
		});
	}

	// ////////////////// list files & expanding /////////////////////////
	public void listFiles(boolean expand)
	{
		fileNames.clear();
		treeFiles.removeAll();
		String filter = txtSearch.getText().toLowerCase();
		treeFiles = new JTree(addFilesToTree(Settings.resourceString + Settings.dataDir, filter));
		treeFiles.addMouseListener(new MouseAdapter()
		{
			@Override
			public void mousePressed(MouseEvent arg0)
			{
				TreePath tp = treeFiles.getPathForLocation(arg0.getX(), arg0.getY());
				if (tp != null)
				{
					String name = (String) tp.getPath()[tp.getPathCount() - 1].toString();
					loadModel(name);
					txtTaskbar.setText(name + " selected.");
				}
			}
		});
		treeFiles.setFont(new Font("Tahoma", Font.PLAIN, 10));
		scrollPane_1.setViewportView(treeFiles);
		expandFileList(treeFiles, expand);
	}

	public DefaultMutableTreeNode addFilesToTree(String dirname, String filter)
	{
		File file = new File(dirname);
		DefaultMutableTreeNode root = new DefaultMutableTreeNode();
		root.setUserObject(file.getName());
		int c = 0;
		if (file.isDirectory()) // hakemisto
		{
			File files[] = file.listFiles();
			for (int i = 0; i < files.length; i++)
			{
				if (files[i].isDirectory())
				{
					root.insert(addFilesToTree(files[i].getPath(), filter), c++);
				} else if (files[i].getPath().toLowerCase().contains(filter))
					root.insert(addFilesToTree(files[i].getPath(), filter), c++);
			}
		} else
		{
			// dirname hakemistoineen tai tiedostonimi file.getName()
			fileNames.add(dirname);
		}

		return root;
	}

	public void expandFileList(JTree tree, boolean expand)
	{
		TreeNode root = (TreeNode) tree.getModel().getRoot();
		expandFileList(tree, new TreePath(root), expand);
	}

	private void expandFileList(JTree tree, TreePath parent, boolean expand)
	{
		// Traverse children
		TreeNode node = (TreeNode) parent.getLastPathComponent();
		if (node.getChildCount() >= 0)
		{
			for (Enumeration<?> e = node.children(); e.hasMoreElements();)
			{
				TreeNode n = (TreeNode) e.nextElement();
				TreePath path = parent.pathByAddingChild(n);
				expandFileList(tree, path, expand);
			}
		}

		// Expansion or collapse must be done bottom-up
		if (expand)
		{
			tree.expandPath(parent);
		} else
		{
			tree.collapsePath(parent);
		}
	}
}
