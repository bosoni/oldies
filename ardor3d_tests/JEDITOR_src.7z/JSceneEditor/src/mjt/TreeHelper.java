package mjt;

import java.util.Enumeration;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

public class TreeHelper
{
	private JTree tree;

	public void create(String rootName)
	{
		DefaultMutableTreeNode root = new DefaultMutableTreeNode(rootName);
		tree = new JTree(root);
	}

	public void use(JTree tree)
	{
		this.tree = tree;
	}

	public void add(String name)
	{
		DefaultMutableTreeNode child = new DefaultMutableTreeNode(name);
		DefaultMutableTreeNode root = (DefaultMutableTreeNode) tree.getModel().getRoot();
		root.add(child);
		clearSelection();
		tree.updateUI();
	}

	public void insert(String name, int index)
	{
		DefaultMutableTreeNode child = new DefaultMutableTreeNode(name);
		DefaultMutableTreeNode root = (DefaultMutableTreeNode) tree.getModel().getRoot();
		root.insert(child, index);
		clearSelection();
		tree.updateUI();
	}

	public void add(String parent, String name)
	{
		if (search(parent))
		{
			DefaultMutableTreeNode chosen = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
			DefaultMutableTreeNode child = new DefaultMutableTreeNode(name);
			chosen.add(child);
			clearSelection();
			//tree.updateUI();
		}
	}

	public boolean hasSelectedChildren()
	{
		DefaultMutableTreeNode chosen = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
		if (chosen == null)
			return true;
		if (chosen.getChildCount() > 0)
			return true;
		return false;
	}

	public void delete(String name)
	{
		try
		{
			if (search(name))
				deleteSelected();
			clearSelection();
			tree.updateUI();
		} catch (Exception e)
		{
		}
	}

	public String[] getList()
	{
		TreeModel model = tree.getModel();
		return getTreeText(model, model.getRoot()).split("\n");
	}

	String getTreeText(TreeModel model, Object object)
	{
		String myRow = object + "\n";
		for (int i = 0; i < model.getChildCount(object); i++)
		{
			myRow += getTreeText(model, model.getChild(object, i));
		}
		return myRow;
	}

	public void deleteSelected()
	{
		DefaultMutableTreeNode chosen = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
		((DefaultTreeModel) tree.getModel()).removeNodeFromParent(chosen);
	}

	public boolean search(String name)
	{
		TreePath root = tree.getPathForRow(0);
		searchTree(tree, root, name);
		if (name.equals(getSelected()))
			return true;
		return false;
	}

	private void searchTree(JTree tree, TreePath path, String q)
	{
		TreeNode node = (TreeNode) path.getLastPathComponent();
		if (node == null)
			return;
		if (node.toString().startsWith(q))
		{
			tree.setScrollsOnExpand(true);
			tree.setSelectionPath(path);
			return;
		}

		if (!node.isLeaf() && node.getChildCount() >= 0)
		{
			Enumeration e = node.children();
			while (e.hasMoreElements())
				searchTree(tree, path.pathByAddingChild(e.nextElement()), q);
		}
	}

	public JTree getTree()
	{
		return tree;
	}

	public String getSelected()
	{
		if (tree.getLastSelectedPathComponent() == null)
			return null;
		return tree.getLastSelectedPathComponent().toString();
	}

	public void clearSelection()
	{
		tree.clearSelection();
	}
}
