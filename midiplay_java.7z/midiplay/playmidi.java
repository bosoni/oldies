import java.io.IOException;
import java.net.URL;
import java.io.File;
import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.midi.Sequencer;

class playmidi
{
    public static void main(String args[])
    {
        if(args.length==0) return;
        MidiPlayer.PlayMidi(args[0]);
    }
}

class MidiPlayer
{
    static Sequencer sequencer=null;
    static void PlayMidi(String file)
    {
	URL url=null;
	File midiFile=null;
	try
	{
	    sequencer = MidiSystem.getSequencer();
	    if(sequencer==null) return;
	    
	    midiFile = new File(file);
     	    sequencer.setSequence(MidiSystem.getSequence(midiFile));

	    sequencer.open();
	    sequencer.start();
	}
	catch(MidiUnavailableException mue)
	{
	    sequencer=null;
	    System.out.println("Midi device unavailable!");
	}
	catch(InvalidMidiDataException imde)
	{
	    sequencer=null;
	    System.out.println("Invalid midi data!");
	}
	catch(IOException ioe)
	{
	    sequencer=null;
	    System.out.println("Invalid midi data!");
	}

    }
    static void CloseMidi()
    {
	if(sequencer!=null)
	{
	    sequencer.stop();
	    sequencer.close();
	}
    }

    static void StopMidi()
    {
	CloseMidi();
	sequencer=null;

	try
	{
	    Thread.sleep(300);
	}
	catch (InterruptedException e)
	{
	}
    }
}
