/**
 * @file ChatClient.java
 *
 * @author mjt, mixut@hotmail.com
 * @created 3.5.2006
 * graafinen k�ytt�liittym� 2.11.2006
 * 
 * pyyt�� ensin serverin osoitteen ja k�ytt�j�nimen, sitten luo yhteyden serveriin.
 * sen j�lkeen kirjoitetut tekstit menee serverin kautta
 * kaikille k�ytt�jille.
 *
 * 
 */
import java.awt.event.*;
import javax.swing.JScrollPane;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.io.*;
import java.net.*;

public class Chat extends JFrame
{

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JTextField userInputTextField = null;
	private static JTextArea textsTextArea = null;

	/**
	 * kirjoita rivi textareaan
	 * 
	 * @param str
	 */
	public static void write(String str)
	{
		if (textsTextArea != null)
		{
			textsTextArea.append(str + "\n");
			textsTextArea.setCaretPosition(textsTextArea.getDocument().getLength());
		}

	}

	String userStr = ""; // @jve:decl-index=0:
	public static String nick = ""; // @jve:decl-index=0:
	public static String host = ""; // @jve:decl-index=0:
	/**
	 * This method initializes userInputTextField
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getUserInputTextField()
	{
		if (userInputTextField == null)
		{
			userInputTextField = new JTextField();
			userInputTextField.setPreferredSize(new Dimension(250, 20));
			userInputTextField.addCaretListener(new javax.swing.event.CaretListener()
			{
				public void caretUpdate(javax.swing.event.CaretEvent e)
				{
					// lue k�ytt�j�n kirjoitus
					userStr = userInputTextField.getText();

				}
			});

			userInputTextField.addActionListener(new java.awt.event.ActionListener()
			{
				public void actionPerformed(java.awt.event.ActionEvent e)
				{
					// jos ENTER painettu

					// jos serverin osoitetta ei ole asetettu
					if (host.equals(""))
					{
						host = userStr;
						userStr = "";
						userInputTextField.setText("");
					}

					// jos nikkii ei viel asetettu,aseta se nyt
					if (nick.equals(""))
					{
						nick = userStr;

						userStr = "";
						userInputTextField.setText("");

						return;
					}

					// jos pelkk� enter
					if (userStr.equals(""))
						return;
					write(nick + ": " + userStr); // ruudulle
					Client.write(userStr); // servulle

					userStr = "";
					userInputTextField.setText("");

					textsTextArea.setCaretPosition(textsTextArea.getDocument().getLength());
				}
			});
		}
		return userInputTextField;
	}

	/**
	 * This method initializes textsTextArea
	 * 
	 * @return javax.swing.JTextArea
	 */
	private JTextArea getTextsTextArea()
	{
		if (textsTextArea == null)
		{
			textsTextArea = new JTextArea();
			textsTextArea.setEditable(false);
		}
		return textsTextArea;
	}

	static Client client = new Client(); // @jve:decl-index=0:
	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		Chat.write("[client test]");
		Chat.write("minichat v0.2 by mjt 2006");
		Chat chat = new Chat();
		chat.setVisible(true);

		Chat.write("Anna serverin IP.\nJos serveri on omalla koneella, niin localhost.");
		while (Chat.host.equals(""))
		{
			ChatIO.sleep(200);
		}

		client.setup(host);
		client.run();

	}

	/**
	 * @param owner
	 */
	public Chat()
	{
		super();
		initialize();
		userInputTextField.setText("");
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize()
	{
		this.setSize(300, 200);
		this.setTitle("Chat");
		this.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
		this.setVisible(true);
		this.setContentPane(getJContentPane());

		this.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				Client.write("/exit");
			}
		});

		userInputTextField.requestFocus();
	}
	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane()
	{
		if (jContentPane == null)
		{
			GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
			gridBagConstraints1.fill = GridBagConstraints.BOTH;
			gridBagConstraints1.gridy = 0;
			gridBagConstraints1.weightx = 1.0;
			gridBagConstraints1.weighty = 1.0;
			gridBagConstraints1.gridx = 0;
			GridBagConstraints gridBagConstraints = new GridBagConstraints();
			gridBagConstraints.fill = GridBagConstraints.VERTICAL;
			gridBagConstraints.gridy = 1;
			gridBagConstraints.weightx = 1.0;
			gridBagConstraints.gridx = 0;
			jContentPane = new JPanel();
			jContentPane.setLayout(new GridBagLayout());
			jContentPane.add(getUserInputTextField(), gridBagConstraints);

			JScrollPane scrollingResult = new JScrollPane(getTextsTextArea());
			// textsTextArea.setAutoscrolls(true);
			// scrollingResult.setAutoscrolls(true);
			jContentPane.add(scrollingResult, gridBagConstraints1);

		}
		return jContentPane;
	}

}

class Client
{
	static boolean alive = true;

	Socket socket = null;

	static DataInputStream input = null;
	static DataOutputStream output = null;

	void setup(String host)
	{
		Chat.write("Anna nimimerkkisi:");
		while (Chat.nick.equals("")) // odota kunnes nimimerki annettu
		{
			ChatIO.sleep(100);
		}

		Chat.write(">" + Chat.nick + " kirjautuu..");

		Chat.write("INFO: Kirjoita /exit kun lopetat.");

		create(host, 10000); // luo yhteys serveriin

	}

	void run()
	{

		// lis�t��n k�ytt�j� serverille
		ChatIO.write("ADD", output); // ensin ADD (eli lis�� k�ytt�j�)
		ChatIO.sleep(50); // odotas hetki
		ChatIO.write(Chat.nick, output); // nyt nimi

		while (alive)
		{
			// luetaan dataa serverilt�
			String str = ChatIO.read(input);
			if (str == null)
				break;

			// jos "!!exit" niin tapa clientti
			if (str.equals(("!!exit")))
			{
				Client.alive = false; // kuolema
				break;
			}

			// kirjoita ruudulle mit� serveri l�hetti
			Chat.write(str);

			ChatIO.sleep(50); // odotetaan hetki
		}

		// suljetaan socketit
		close();
		System.exit(0);
	}

	static public void write(String str)
	{
		// l�het� teksti servulle
		ChatIO.write(str, output);

		// jos sammutetaan clientti
		if (str.equals("/exit"))
		{
			// odotetaan kunnes clientti kuolee (saa "!!exit" viestin)
			while (alive)
			{
				ChatIO.sleep(200);
			}

		}
	}

	void create(String host, int portNumber)
	{

		try
		{
			socket = new Socket(host, portNumber);

			input = new DataInputStream(socket.getInputStream());
			output = new DataOutputStream(socket.getOutputStream());

		} catch (IOException e)
		{
			System.out.println(e);
		}

	}

	void close()
	{
		try
		{
			output.close();
			input.close();
			socket.close();
		} catch (IOException e)
		{
			System.out.println("close(): " + e);
		}

	}

}
