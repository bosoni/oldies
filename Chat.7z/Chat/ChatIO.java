/**
 * @file ChatIO.java
 *
 * @author mjt, mixut@hotmail.com
 * @created 3.5.2006
 *
 */
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.charset.UnsupportedCharsetException;

public class ChatIO
{

	static byte[] buf = new byte[1000];

	static String xorStr = "ManiaC";

	static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

	public void setXorStr(String str)
	{
		xorStr = str;
	}

	
	/**
	 * kirjoittaa txt:n out-streamiin 
	 * 
	 */
	public static void write(String txt, DataOutputStream out)
	{
		if (txt == null || txt.length() == 0)
			return;

		try
		{
			out.write(XOR(txt.getBytes(), xorStr.getBytes()));
		} catch (IOException e)
		{
			System.out.println(e);
		} 
	}

	/**
	 *  lukee teksti�
	 *
	 */
	public static String read(DataInputStream in)
	{
		int len = 0;
		for(int q=0; q<buf.length; q++) buf[q]=0;

		try
		{
			len = in.read(buf);

		} catch (IOException e)
		{
			System.out.println(e);
			return null;
		}
		

		byte[] rivi=null;

		rivi = XOR(buf, xorStr.getBytes());

		String str = "";
		for (int q = 0; q < len; q++)
		{
			str = str + (char) (rivi[q]&0xFF);

		}
		return str;
	}

	 /**
	  * XORraa tekti key:ll�
	  * 
	  */
	public static byte[] XOR(byte[] in, byte[] key)
	{

		int i = 0;
		byte[] out = new byte[in.length];

		if (in == null || in.length == 0)
			return out;

		i=0;
		while (true)
		{
			for (int q = 0; q < key.length; q++)
			{
				out[i] = (byte) (in[i] ^ key[q]);

				i++;

				if (i == out.length)
				{
					return out;
				}

			}
		}
	}

	/**
	 * lue n�pp�insy�te
	 * 
	 */
	public static String readKeyb()
	{
		String s = "";
		try
		{
			s = in.readLine();
		} catch (IOException e)
		{
			System.out.println(e);
		}
		return s;
	}

	/**
	 * tauko ms
	 * 
	 */
	public static void sleep(int ms)
	{
		try
		{
			Thread.sleep(ms);
		} catch (InterruptedException ie)
		{
			System.out.println("sleep(): " + ie);
		}
	}
}

