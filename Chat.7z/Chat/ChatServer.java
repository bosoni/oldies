/**
 * @file ChatServer.java
 *
 * @author mjt, mixut@hotmail.com
 * @created 3.5.2006
 * 
 * kuuntelee ja luo threadin jokaiselle clientille.
 * pit�� clientien tiedot vektorissa, poistuneet k�ytt�j�t
 * poistetaan vektorista ja thread tuhotaan.
 * 
 * palauttaa muutamilla k�skyill� clientille tietoa,
 * esim k�ytt�j�t.
 * 
 * kun vastaanotetaan clientilt� teksti, l�hetet��n se kaikille
 * muille clienteille.
 * 
 * 
 */

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

public class ChatServer
{
	static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	static Server chat = new Server();

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{

		System.out.println("[server test]");
		System.out.println("minichat server v0.2 by mjt 2006");

		chat.run();

		System.exit(0);
	}

}

class User extends Thread
{

	String nick = "";

	Socket socket = null;

	byte[] buf = new byte[1000];

	DataInputStream input = null;

	DataOutputStream output = null;

	boolean alive = false;

	public void killUser()
	{
		if(alive)
		{
			ChatIO.write("!!exit", output); // l�het� clietille !!exit jolloin se tappaa itsens�
			ChatIO.sleep(100);
			close();
			alive = false;
		}
	}

	public boolean isUserAlive()
	{
		return alive;
	}

	User(String name, Socket soc, DataInputStream in, DataOutputStream out)
	{
		super(name);

		alive = true;
		socket = soc;
		input = in;
		output = out;

	}

	public void run()
	{

		while (alive)
		{

			String txt = ChatIO.read(input);
			if (txt == null)
				break;

			if (txt.equals("ADD"))
			{
				nick = ChatIO.read(input);

				if(nick.equals("SHUTDOWNSERVER")) // serveri alas
				{
					Server.sendString("Serveri sammuu..", this);
					ChatIO.sleep(100);
					Server.running=false;
					break;
				}
				else
				Server.sendString("*** " + nick + " kirjautui. ***", this);

			} else if (txt.equals("/exit") == true)
			{
				Server.sendString("*** " + nick + " poistui.. ***", this);
				ChatIO.sleep(50);
				killUser();

				break;
			} else
			{
				// l�het� txt kaikille muille k�ytt�jille
				Server.sendString("<" + nick + "> " + txt, this);
			}

			ChatIO.sleep(200);
		}
		
	}

	boolean closed=false;
	void close()
	{
		if(closed) return;
		try
		{
			output.close();
			input.close();
			socket.close();
		} catch (IOException e)
		{
			System.out.println("close():"+e);
		}
		closed=true;
	}
}

class Server
{

	Socket socket = null;

	DataInputStream input = null;

	DataOutputStream output = null;

	ServerSocket service;

	int portNumber = 10000;

	static private Vector<User> users = new Vector<User>();

	int cc = 0;

	public static boolean running = true;

	/**
	 * l�het� txt kaikille muille k�ytt�jille paitsi sender:ille
	 * 
	 */
	static public void sendString(String txt, User sender)
	{

		// n�yt� txt serverill�
		System.out.println(txt);

		// l�het� txt kaikille paitsi txt:n kirjoittajalle
		for (int q = 0; q < users.size(); q++)
		{
			if (users.get(q) != sender && users.get(q).isAlive() == true)
			{
				ChatIO.write(txt, users.get(q).output);
			}
		}
	}

	void run()
	{

		try
		{
			service = new ServerSocket(portNumber);
		} catch (IOException e)
		{
			System.out.println("run(): "+e);
		}

		while (true)
		{
			try
			{
				// j�� odottamaan uutta k�ytt�j��
				socket = service.accept();
				input = new DataInputStream(socket.getInputStream());
				output = new DataOutputStream(socket.getOutputStream());
			} catch (IOException e)
			{
				System.out.println("run() new user: "+e);
			}

			// luo k�ytt�j� uuteen threadiin
			User usr = new User("usr" + cc++, socket, input, output);
			users.add(usr); // lis�� k�ytt�j� vektoriin
			usr.start(); // k�ynnist� thread

			
			// odota hetki ja tarkista, kuuluuko serverin olla viel� k�ynniss�
			// serverin saa suljettua kirjautuessa SHUTDOWNSERVER nikill�
			ChatIO.sleep(500);
			if (running == false)
				break;
			
			
			// jos k�ytt�j� on h�ipynyt, poista se vektorista
			for (int q = 0; q < users.size(); q++)
			{
				if (users.get(q).isUserAlive() == false)
				{
					users.get(q).close();
					users.removeElementAt(q);
				}

			}

		}

		// tapa kaikki
		for (int a = 0; a < users.size(); a++)
		{
			users.get(a).killUser();
		}
		
		
		try
		{
			service.close();
		} catch (IOException e)
		{
			System.out.println("shutdown: "+e);
		}
	}

}

