Client/server testi, yksinkertainen chat ohjelma
by mjt, 2006
mixut@hotmail.com

Luo ensin serveri, sitten asiakkaat voi kirjautua
siihen ja keskustella toistensa kanssa.
Viestit menev�t servun kautta kaikille k�ytt�jille.


link.bat k��nt�� ohjelmat
server.bat k�ynnist�� serverin
client.bat k�ynnist�� client-ohjelman


