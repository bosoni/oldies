/**
 * @file Intersection.java
 *
 * @author mjt, 2007-08
 * mixut@hotmail.com
 *
 * tutti:
 * http://nehe.gamedev.net/data/lessons/lesson.asp?lesson=30
 * http://www.gamedev.net/reference/articles/article1026.asp
 *
 * http://jgt.akpeters.com/papers/MollerTrumbore97/
 */
package jsat;

import org.lwjgl.util.vector.Vector3f;
import static org.lwjgl.opengl.GL11.*;

public class Intersection
{
    private static final float EPSILON = 0.00001f;

    public static float t, u, v;

    /*
     * tarkista osuuko start->end vektori johonkin polyyn. palauttaa true
     * jos osuu, muuten false.
     */
    public boolean checkIntersection(Vector3f start, Vector3f end, Node objs)
    {
	Vector3f dir = new Vector3f();
	Vector3f.sub(end, start, dir);

	// vektorin pituus
	float len = dir.lengthSquared();
	// float len=(float)Math.sqrt(dir.lengthSquared());
	if (len == 0)
	{
	    return false;
	}
	// len*=2;

	dir.normalise(dir);

	// joka objekti l�pi
	for (int q = 0; q < objs.getNumNodes(); q++)
	{

	    if (objs.getNode(q).getType() == ObjectInfo.OBJECT)
	    {
		Object3D obj = (Object3D) objs.getNode(q);
		for (int w = 0; w < obj.getNumMeshes(); w++)
		{
		    Mesh mesh = obj.getMesh(w);

		    for (int e = 0; e < mesh.faces.length; e++)
		    {
			// tarkista kolmio
			Vector3f v1 = mesh.vertex[mesh.faces[e][0]];
			Vector3f v2 = mesh.vertex[mesh.faces[e][1]];
			Vector3f v3 = mesh.vertex[mesh.faces[e][2]];

			Vector3f vv1 = new Vector3f();
			Vector3f vv2 = new Vector3f();
			Vector3f vv3 = new Vector3f();

			// otetaan paikka huomioon
			Vector3f.add(v1, obj.getWorldSpacePosition(), vv1);
			Vector3f.add(v2, obj.getWorldSpacePosition(), vv2);
			Vector3f.add(v3, obj.getWorldSpacePosition(), vv3);

			// HUOM! jos objektia k��nt��, t�m� ei ota sit�
			// huomioon.
			// vv?:t pit�isi varmaan kertoa rotation matriisilla?
			// todo fix

			if (intersectTriangle(start, dir, vv1, vv2, vv3) == 1)
			{
			    if (Settings.DEBUG)
			    {
				// debug -- renderoi poly
				Log.write(">" + e + " len=" + len + "  t=" + t);
				glDisable(GL_DEPTH_TEST);
				glDisable(GL_TEXTURE_2D);

				glBegin(GL_TRIANGLES);
				glVertex3f(vv1.x, vv1.y, vv1.z);
				glVertex3f(vv2.x, vv2.y, vv2.z);
				glVertex3f(vv3.x, vv3.y, vv3.z);
				glEnd();
				glEnable(GL_TEXTURE_2D);
				glEnable(GL_DEPTH_TEST);
			    }
			    // --------------------------------

			    if (Math.abs(t) > len)
			    {
				continue;
			    }

			    return true;
			}
		    }
		}
	    }
	}
	return false;
    }

    static Vector3f edge1 = new Vector3f();

    static Vector3f edge2 = new Vector3f();

    static Vector3f tvec = new Vector3f();

    static Vector3f pvec = new Vector3f();

    static Vector3f qvec = new Vector3f();

    public int intersectTriangle(Vector3f orig, Vector3f dir, Vector3f v0, Vector3f v1, Vector3f v2)
    {
	float det, inv_det;

	// find vectors for two edges sharing vert0
	Vector3f.sub(v1, v0, edge1);
	Vector3f.sub(v2, v0, edge2);

	// begin calculating determinant - also used to calculate U parameter
	Vector3f.cross(dir, edge2, pvec);

	// if determinant is near zero, ray lies in plane of triangle
	det = Vector3f.dot(edge1, pvec);

	if (det < EPSILON)
	{
	    return 0;
	}

	// calculate distance from vert0 to ray origin
	Vector3f.sub(orig, v0, tvec);

	// calculate U parameter and test bounds
	u = Vector3f.dot(tvec, pvec);
	if (u < 0.0 || u > det)
	{
	    return 0;
	}

	// prepare to test V parameter
	Vector3f.cross(tvec, edge1, qvec);

	// calculate V parameter and test bounds
	v = Vector3f.dot(dir, qvec);
	if (v < 0.0 || u + v > det)
	{
	    return 0;
	}

	// calculate t, scale parameters, ray intersects triangle
	t = Vector3f.dot(edge2, qvec);
	inv_det = 1.0f / det;

	t *= inv_det;
	u *= inv_det;
	v *= inv_det;
	return 1;
    }
}
