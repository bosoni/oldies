/**
 * @file Screen.java
 *
 * @author mjt, 2007-08
 * mixut@hotmail.com
 *
 * tut:
 * http://lwjgl.org/wiki/doku.php/lwjgl/tutorials/opengl/basicfbo
 *
 */
package jsat;

import java.nio.IntBuffer;
import org.lwjgl.BufferUtils;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.EXTFramebufferObject.*;

public class Screen
{
    static private int size = 256;

    static private int width = 256, height = 256;

    static GLSL[] filter = new GLSL[10];

    static final int textures = 2;

    static private int depthbuffer = 0;

    static private int[] framebuffer = new int[textures];

    static private Texture[] texture = new Texture[textures];

    static private Texture depthTexture = null;

    public static Texture texture()
    {
	return texture[1];
    }

    public static Texture depthTexture()
    {
	return depthTexture;
    }

    public static int getSize()
    {
	return size;
    }

    /**
     * screen texture koko (..., 64, 128, 256, 512, ...)
     */
    public static void setSize(int _size)
    {
	width = height = size = _size;
    }

    public void createBuffers()
    {
	// depth
	depthTexture = new Texture();
	depthTexture.createDepthTexture(width, height, GL_NEAREST, GL_NEAREST);
	IntBuffer intBuffer = BufferUtils.createIntBuffer(1);
	glGenFramebuffersEXT(intBuffer);
	depthbuffer = intBuffer.get();
	glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, depthbuffer);
	glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT, GL_DEPTH_ATTACHMENT_EXT, GL_TEXTURE_2D, depthTexture.getTexture(), 0);
	glDrawBuffer(GL_NONE);
	glReadBuffer(GL_NONE);

	// create depth renderbuffer
	intBuffer = BufferUtils.createIntBuffer(1);
	glGenRenderbuffersEXT(intBuffer);
	int depth = intBuffer.get();
	glBindRenderbufferEXT(GL_RENDERBUFFER_EXT, depth);
	glRenderbufferStorageEXT(GL_RENDERBUFFER_EXT, GL_DEPTH_COMPONENT, width, height); // GL14.GL_DEPTH_COMPONENT16,
	// width,
	// height);

	glDrawBuffer(GL_NONE);
	glReadBuffer(GL_NONE);
	for (int q = 0; q < textures; q++)
	{
	    texture[q] = new Texture();
	    texture[q].createTexture(width, height, GL_LINEAR, GL_LINEAR, GL_RGBA);

	    intBuffer = BufferUtils.createIntBuffer(1);
	    glGenFramebuffersEXT(intBuffer);
	    framebuffer[q] = intBuffer.get();
	    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, framebuffer[q]);
	    glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT, GL_TEXTURE_2D, texture[q].getTexture(), 0);
	    glFramebufferRenderbufferEXT(GL_FRAMEBUFFER_EXT, GL_DEPTH_ATTACHMENT_EXT, GL_RENDERBUFFER_EXT, depth);
	}

    }

    /**
     * luo tarvittavat texturet ja aseta fbo jos tuetaan
     */
    public void initFBO()
    {
	if (Settings.fboSupported == true)
	{
	    createBuffers();

	    int ret = glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT);
	    switch (ret)
	    {
	    case GL_FRAMEBUFFER_COMPLETE_EXT:
		unbind();
		break;
	    case GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT_EXT:
		FileIO.ErrorMessage("FrameBuffer error: GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT_EXT");
		break;
	    case GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT_EXT:
		FileIO.ErrorMessage("FrameBuffer error: GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT_EXT");
		break;
	    case GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS_EXT:
		FileIO.ErrorMessage("FrameBuffer error: GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS_EXT");
		break;
	    case GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER_EXT:
		FileIO.ErrorMessage("FrameBuffer error: GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER_EXT");
		break;
	    case GL_FRAMEBUFFER_INCOMPLETE_FORMATS_EXT:
		FileIO.ErrorMessage("FrameBuffer error: GL_FRAMEBUFFER_INCOMPLETE_FORMATS_EXT");
		break;
	    case GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER_EXT:
		FileIO.ErrorMessage("FrameBuffer error: GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER_EXT");
		break;
	    default:
		FileIO.ErrorMessage("[fbo]: programming error: " + ret);
		break;
	    }
	}

	if (Settings.fboSupported == false)
	{
	    width = height = size;
	    for (int i = 0; i < textures; i++)
	    {
		texture[i] = new Texture();
		texture[i].createTexture(size, size, GL_LINEAR, GL_LINEAR, GL_RGBA);
	    }
	    depthTexture = new Texture();
	    depthTexture.createDepthTexture(width, height, GL_LINEAR, GL_LINEAR);

	}

    }

    /**
     * lataa shader
     */
    public void loadFilter(int index, String vert, String frag)
    {
	filter[index] = new GLSL();
	filter[index].loadPrograms(vert, frag);
    }

    // viewportti texturen kokoiseksi
    public void setViewport()
    {
	glPushAttrib(GL_VIEWPORT_BIT);
	glViewport(0, 0, width, height);
	if (Settings.fboSupported)
	{
	    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	}
    }

    // palauta alkup viewport asetus
    public void restoreViewport()
    {
	glPopAttrib();
    }

    /**
     * bindaa screen texture johon rendaus tapahtuu (jos fbo k�yt�ss�)
     */
    public void bind()
    {
	if (Settings.fboSupported)
	{
	    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, framebuffer[1]);
	}
    }

    /**
     * bindaa depthTexture johon renderoidaan syvyyskartta (fbo)
     */
    public void bindDepth()
    {
	if (Settings.fboSupported)
	{
	    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, depthbuffer);
	    glDrawBuffer(GL_NONE);
	}
    }

    /**
     * poista textureen renderointi
     */
    public static void unbind()
    {
	if (Settings.fboSupported)
	{
	    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
	}
    }

    /**
     * kopioi rendatut roskat screen-textureen
     */
    public void copyScreen()
    {
	if (Settings.fboSupported == false)
	{
	    // kopsaa kamat ruudulta
	    texture[1].bind(0);
	    glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, size, size);
	}
    }

    /**
     * kopioi syvyyskartta depthTextureen
     */
    public void copyDepth()
    {
	if (Settings.fboSupported == false)
	{
	    // kopsaa kamat ruudulta
	    depthTexture.bind(0);
	    glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, size, size);
	}
    }

    /**
     * renderoi nelikulmio
     */
    public static void drawQuad(float px, float py)
    {
	float w = (float) BaseGame.mode.getWidth() - px;
	float h = (float) BaseGame.mode.getHeight() - py;
	float x = px;
	float y = py;

	glBegin(GL_TRIANGLE_FAN);
	glTexCoord2f(0, 0);
	glVertex3f(x, y, 0);
	glTexCoord2f(1, 0);
	glVertex3f(w, y, 0);
	glTexCoord2f(1, 1);
	glVertex3f(w, h, 0);
	glTexCoord2f(0, 1);
	glVertex3f(x, h, 0);
	glEnd();
    }

    /**
     * renderoi texture skeneen muutaman kerran pienent�en sit� joka
     * piirrolla
     */
    public void renderQuads(int count, int steps, float alpha)
    {
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	GLSL.unbind();

	texture[1].bind(0);

	glColor4f(1, 1, 1, alpha);

	float xy = 0;
	for (int i = 0; i < count; i++)
	{
	    drawQuad(xy, xy);
	    xy += steps;
	}

	glPopAttrib();

	glColor4f(1, 1, 1, 1);
    }

    static int TEXTUREUNIT = 0; // selvyyden vuoksi. voi vaihtaa jos tarvii.

    /**
     * renderoi quad jossa valo-alue rendataan alpha 0:lla (l�pin�kyv�) ja
     * varjoalue n�kyv�n�.
     */
    public void renderShadows(int index, int count, int steps, float darkness)
    {
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	filter[index].bind();
	filter[index].setUniform("texture", null, new int[] { TEXTUREUNIT });
	filter[index].setUniform("darkness", new float[] { darkness }, null);

	texture[1].bind(TEXTUREUNIT);

	float xy = 0;
	for (int i = 0; i < count; i++)
	{
	    drawQuad(xy, xy);
	    xy += steps;
	}

	GLSL.unbind();
	glPopAttrib();
    }

    /**
     * blurraus
     */
    public void blur(BlurParameters par)
    {
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	filter[par.blur_Shader].bind();
	filter[par.blur_Shader].setUniform("texture", null, new int[] { TEXTUREUNIT });
	filter[par.blur_Shader].setUniform("ambient", new float[] { par.ambient }, null);
	filter[par.blur_Shader].setUniform("textureSize", new float[] { par.textureSize }, null);
	filter[par.blur_Shader].setUniform("blursize", new float[] { par.blurSize }, null);

	texture[1].bind(TEXTUREUNIT);

	drawQuad(0, 0);

	GLSL.unbind();
	glPopAttrib();
    }

    public void bloom(int index)
    {
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	filter[index].bind();
	filter[index].setUniform("texture", null, new int[] { TEXTUREUNIT });
	texture[1].bind(TEXTUREUNIT);

	drawQuad(0, 0);

	GLSL.unbind();
	glPopAttrib();
    }
}
