/**
 * @file Geometry.java
 *
 * @author mjt, 2007-08
 * mixut@hotmail.com
 *
 */
package jsat;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.ARBMultitexture;
import org.lwjgl.opengl.ARBVertexBufferObject;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;
import org.lwjgl.util.vector.Vector2f;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL12.*;

public class Geometry
{
    // montako texturea objektilla voi olla
    public static final int MAXTEXTURES = 8;

    /**
     * texturet (diffuse, bump, lightmap, ..)
     */
    private Texture texture[] = new Texture[MAXTEXTURES];

    /**
     * vertex buffer
     */
    private FloatBuffer verts = null;

    /**
     * index buffer
     */
    private IntBuffer indices = null;

    /**
     * texture koordinaatit
     */
    private FloatBuffer uvs[] = new FloatBuffer[MAXTEXTURES];

    /**
     * normaalit
     */
    private FloatBuffer normals = null;

    public static boolean projectTexture = false;

    public Geometry()
    {
    }

    public static void calcNormals(Vector3f[] pos, int[][] faces, Vector3f[] normals, boolean flipNormals)
    {
	int q;
	int w;
	int count = 0;
	Vector3f out = new Vector3f();
	Vector3f c = new Vector3f();
	float len;

	for (q = 0; q < pos.length; q++)
	{
	    c.set(0, 0, 0);

	    for (w = 0; w < faces.length; w++)
	    {
		// jos vertex on t�ss� kolmiossa
		if ((faces[w][0] == q) || (faces[w][1] == q) || (faces[w][2] == q))
		{
		    calcNormal(pos[faces[w][0]], pos[faces[w][1]], pos[faces[w][2]], out);

		    len = out.lengthSquared(); // (float)Math.sqrt(out.lengthSquared());

		    if (len == 0)
		    {
			len = -1.0f;
		    }

		    c.x += (out.x / len);
		    c.y += (out.y / len);
		    c.z += (out.z / len);
		    count++;
		}

		if (count > 0)
		{
		    // laske vektorin pituus
		    len = c.lengthSquared(); // (float)Math.sqrt(out.lengthSquared());

		    if (flipNormals == true)
		    {
			len = -len;
		    }

		    if (len == 0)
		    {
			len = -1.0f;
		    }

		    normals[q] = new Vector3f();
		    normals[q].x = c.x / len;
		    normals[q].y = c.y / len;
		    normals[q].z = c.z / len;

		    if (len != -1)
		    {
			normals[q].normalise();
		    }
		}
	    }
	}
    }

    public static void calcNormals(FloatBuffer positions, int[][] faces, Vector3f[] normals, boolean flipNormals)
    {
	int q;
	int w;
	int count = 0;
	Vector3f out = new Vector3f();
	Vector3f c = new Vector3f();
	Vector3f pos1 = new Vector3f();
	Vector3f pos2 = new Vector3f();
	Vector3f pos3 = new Vector3f();
	float len;

	for (q = 0; q < positions.capacity() / 3; q++)
	{
	    c.set(0, 0, 0);

	    for (w = 0; w < faces.length; w++)
	    {
		// jos vertex on t�ss� kolmiossa
		if ((faces[w][0] == q) || (faces[w][1] == q) || (faces[w][2] == q))
		{

		    pos1.set(positions.get(faces[w][0] * 3), positions.get(faces[w][0] * 3 + 1), positions.get(faces[w][0] * 3 + 2));
		    pos2.set(positions.get(faces[w][1] * 3), positions.get(faces[w][1] * 3 + 1), positions.get(faces[w][1] * 3 + 2));
		    pos3.set(positions.get(faces[w][2] * 3), positions.get(faces[w][2] * 3 + 1), positions.get(faces[w][2] * 3 + 2));

		    //calcNormal(pos[faces[w][0]], pos[faces[w][1]], pos[faces[w][2]], out);
		    calcNormal(pos1, pos2, pos3, out);

		    len = out.lengthSquared(); // (float)Math.sqrt(out.lengthSquared());

		    if (len == 0)
		    {
			len = -1.0f;
		    }

		    c.x += (out.x / len);
		    c.y += (out.y / len);
		    c.z += (out.z / len);
		    count++;
		}

		if (count > 0)
		{
		    // laske vektorin pituus
		    len = c.lengthSquared(); // (float)Math.sqrt(out.lengthSquared());

		    if (flipNormals == true)
		    {
			len = -len;
		    }

		    if (len == 0)
		    {
			len = -1.0f;
		    }

		    normals[q] = new Vector3f();
		    normals[q].x = c.x / len;
		    normals[q].y = c.y / len;
		    normals[q].z = c.z / len;

		    if (len != -1)
		    {
			normals[q].normalise();
		    }
		}
	    }
	}
    }

    public static void calcPlane(Vector3f v1, Vector3f v2, Vector3f v3, Vector4f out)
    {
	out.x = (v1.y * (v2.z - v3.z)) + (v2.y * (v3.z - v1.z)) + (v3.y * (v1.z - v2.z));
	out.y = (v1.z * (v2.x - v3.x)) + (v2.z * (v3.x - v1.x)) + (v3.z * (v1.x - v2.x));
	out.z = (v1.x * (v2.y - v3.y)) + (v2.x * (v3.y - v1.y)) + (v3.x * (v1.y - v2.y));
	out.w = -((v1.x * ((v2.y * v3.z) - (v3.y * v2.z))) + (v2.x * ((v3.y * v1.z) - (v1.y * v3.z))) + (v3.x * ((v1.y * v2.z) - (v2.y * v1.z))));
    }

    public static void calcNormal(Vector3f v1, Vector3f v2, Vector3f v3, Vector3f out)
    {
	float RelX1 = v2.x - v1.x;
	float RelY1 = v2.y - v1.y;
	float RelZ1 = v2.z - v1.z;
	float RelX2 = v3.x - v1.x;
	float RelY2 = v3.y - v1.y;
	float RelZ2 = v3.z - v1.z;
	out.x = (RelY1 * RelZ2) - (RelZ1 * RelY2);
	out.y = (RelZ1 * RelX2) - (RelX1 * RelZ2);
	out.z = (RelX1 * RelY2) - (RelY1 * RelX2);
    }

    /**
     * aseta texture
     * 
     * @param tex
     *                asetettava texture
     */
    public void setTexture(int index, Texture tex)
    {
	texture[index] = tex;
	if (uvs[index] == null)
	{
	    uvs[index] = uvs[0];

	    if (Settings.VBO)
	    {
		if (uvBufferID[index] == null)
		    uvBufferID[index] = vboGetID();
		vboSetBufferData(uvBufferID[index].get(0), uvs[index]);
	    }

	}
    }

    public Texture getTexture(int index)
    {
	return texture[index];
    }

    public FloatBuffer getVerts()
    {
	return verts;
    }

    public void setVerts(FloatBuffer buf)
    {
	verts = buf;
    }
    public void setIndices(IntBuffer buf)
    {
	indices = buf;
    }

    public void updateNormalBuffer(Vector3f[] nbuf)
    {
	if (Settings.VBO)
	{
	    vboUpdate(nbuf, normalBufferID);
	} else
	{
	    if (nbuf != null)
	    {
		normals.clear();
		for (int q = 0; q < nbuf.length; q++)
		{
		    normals.put(nbuf[q].x);
		    normals.put(nbuf[q].y);
		    normals.put(nbuf[q].z);
		}
		normals.flip();
	    }
	}
    }

    public void updateVertexBuffer(Vector3f[] vbuf)
    {
	if (Settings.VBO)
	{
	    vboUpdate(vbuf, vertexBufferID);
	} else
	{

	    if (vbuf != null)
	    {
		verts.clear();
		for (int q = 0; q < vbuf.length; q++)
		{
		    verts.put(vbuf[q].x);
		    verts.put(vbuf[q].y);
		    verts.put(vbuf[q].z);
		}
		verts.flip();
	    }
	}
    }

    // aseta uv:t
    public void setTextureCoords(int index, Vector2f[] uvbuf)
    {
	if (uvbuf != null)
	{
	    uvs[index] = BufferUtils.createFloatBuffer(uvbuf.length * 2);
	    for (int q = 0; q < uvbuf.length; q++)
	    {
		uvs[index].put(uvbuf[q].x);
		uvs[index].put(uvbuf[q].y);
	    }
	    uvs[index].flip();

	    if (Settings.VBO)
	    {
		if (uvBufferID[index] == null)
		    uvBufferID[index] = vboGetID();
		vboSetBufferData(uvBufferID[index].get(0), uvs[index]);
	    }

	}

    }

    /**
     * aseta 3d mallin vertex ym bufferit
     * 
     * 
     * @param vbuf
     *                vertex buffer
     * @param fbuf
     *                indexit
     * @param uvbuf
     *                uv buffer
     * @param nbuf
     *                normals
     */
    public void createBuffers(Vector3f[] vbuf, int[][] fbuf, Vector3f[] nbuf, Vector2f[] uvbuf, boolean isStaticMesh)
    {
	int q;
	if (vbuf != null)
	{
	    verts = BufferUtils.createFloatBuffer(vbuf.length * 3);

	    for (q = 0; q < vbuf.length; q++)
	    {
		verts.put(vbuf[q].x);
		verts.put(vbuf[q].y);
		verts.put(vbuf[q].z);
	    }

	    verts.flip();
	}

	if (fbuf != null)
	{
	    indices = BufferUtils.createIntBuffer(fbuf.length * 3);
	    for (q = 0; q < fbuf.length; q++)
	    {
		indices.put(fbuf[q]);
	    }

	    indices.flip();
	}

	if (uvbuf != null)
	{
	    uvs[0] = BufferUtils.createFloatBuffer(uvbuf.length * 2);
	    for (q = 0; q < uvbuf.length; q++)
	    {
		uvs[0].put(uvbuf[q].x);
		uvs[0].put(uvbuf[q].y);
	    }
	    uvs[0].flip();
	}

	if (nbuf != null)
	{
	    normals = BufferUtils.createFloatBuffer(nbuf.length * 3);
	    for (q = 0; q < nbuf.length; q++)
	    {
		normals.put(nbuf[q].x);
		normals.put(nbuf[q].y);
		normals.put(nbuf[q].z);
	    }

	    normals.flip();
	}

	if (Settings.VBO)
	    vboCreate(isStaticMesh);

    }

    /**
     * renderoi datat
     */
    public void render()
    {
	if (verts == null || indices == null)
	{
	    return;
	}

	if (Settings.VBO)
	{
	    vboRender(); // renderoi vbo
	    return;
	}

	// vertex array ---
	glEnableClientState(GL_VERTEX_ARRAY);
	glVertexPointer(3, 0, verts);

	if (normals != null)
	{
	    glEnableClientState(GL_NORMAL_ARRAY);
	    glNormalPointer(0, normals);
	}

	if (BaseGame.renderTextures() && uvs != null)
	{
	    for (int q = 0; q < MAXTEXTURES; q++)
	    {
		if (uvs[q] != null)
		{
		    texture[q].bind(q);

		    ARBMultitexture.glClientActiveTextureARB(ARBMultitexture.GL_TEXTURE0_ARB + q);
		    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		    glTexCoordPointer(2, 0, uvs[q]);
		}
	    }

	    if (Geometry.projectTexture == true && uvs[0] != null)
	    {
		Texture.active(1);
		ARBMultitexture.glClientActiveTextureARB(ARBMultitexture.GL_TEXTURE1_ARB);
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		glTexCoordPointer(2, 0, uvs[0]);
	    }

	}
	glDrawElements(GL_TRIANGLES, indices); // renderoi vertax array

	disableStates();
    }

    // tuhoa objekti
    void destroy()
    {
	if (verts != null)
	    verts.clear();
	if (indices != null)
	    indices.clear();
	if (normals != null)
	    normals.clear();

	verts = null;
	indices = null;
	normals = null;

	for (int q = 0; q < MAXTEXTURES; q++)
	{
	    if (uvs[q] != null)
		uvs[q].clear();
	    uvs[q] = null;
	    texture[q] = null;
	}

	if (Settings.VBO)
	    vboDeleteBuffers();
    }

    /**
     * tilat pois p��lt�
     */
    public void disableStates()
    {
	Texture.active(0);
	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);

	for (int q = 0; q < MAXTEXTURES; q++)
	{
	    if (texture[q] != null)
	    {
		Texture.active(q);
		ARBMultitexture.glClientActiveTextureARB(ARBMultitexture.GL_TEXTURE0_ARB + q);
		glDisableClientState(GL_TEXTURE_COORD_ARRAY);

		Texture.unbind(q);
	    }
	    Texture.active(0);
	}
    }

    // ----------------------------------------------------------------
    // vertex buffer object -koodi
    // http://lwjgl.org/wiki/doku.php/lwjgl/tutorials/opengl/basicvbo
    //
    IntBuffer vertexBufferID = null, indexBufferID = null, normalBufferID = null;

    boolean vboIsStaticMesh = true;

    IntBuffer uvBufferID[] = new IntBuffer[MAXTEXTURES];

    public IntBuffer vboGetID()
    {
	IntBuffer buffer = BufferUtils.createIntBuffer(1);
	ARBVertexBufferObject.glGenBuffersARB(buffer);
	return buffer;
    }

    public void vboCreate(boolean isStaticMesh)
    {
	vboIsStaticMesh = isStaticMesh;

	if (verts != null)
	{
	    vertexBufferID = vboGetID();
	    vboSetBufferData(vertexBufferID.get(0), verts);
	}
	if (indices != null)
	{
	    indexBufferID = vboGetID();
	    vboSetIndexData(indexBufferID.get(0), indices);
	}

	if (normals != null)
	{
	    normalBufferID = vboGetID();
	    vboSetBufferData(normalBufferID.get(0), normals);
	}

	for (int q = 0; q < MAXTEXTURES; q++)
	{
	    if (uvs[q] != null)
	    {
		uvBufferID[q] = vboGetID();
		vboSetBufferData(uvBufferID[q].get(0), uvs[q]);
	    }
	}

    }

    public void vboSetBufferData(int id, FloatBuffer buffer)
    {
	ARBVertexBufferObject.glBindBufferARB(ARBVertexBufferObject.GL_ARRAY_BUFFER_ARB, id);
	if (vboIsStaticMesh)
	    ARBVertexBufferObject.glBufferDataARB(ARBVertexBufferObject.GL_ARRAY_BUFFER_ARB, buffer, ARBVertexBufferObject.GL_STATIC_DRAW_ARB);
	else
	    ARBVertexBufferObject.glBufferDataARB(ARBVertexBufferObject.GL_ARRAY_BUFFER_ARB, buffer, ARBVertexBufferObject.GL_DYNAMIC_DRAW_ARB);
    }

    public void vboSetIndexData(int id, IntBuffer buffer)
    {
	ARBVertexBufferObject.glBindBufferARB(ARBVertexBufferObject.GL_ELEMENT_ARRAY_BUFFER_ARB, id);
	if (vboIsStaticMesh)
	    ARBVertexBufferObject.glBufferDataARB(ARBVertexBufferObject.GL_ELEMENT_ARRAY_BUFFER_ARB, buffer, ARBVertexBufferObject.GL_STATIC_DRAW_ARB);
	else
	    ARBVertexBufferObject.glBufferDataARB(ARBVertexBufferObject.GL_ELEMENT_ARRAY_BUFFER_ARB, buffer, ARBVertexBufferObject.GL_DYNAMIC_DRAW_ARB);

    }

    public void vboRender()
    {
	glEnableClientState(GL_VERTEX_ARRAY);
	ARBVertexBufferObject.glBindBufferARB(ARBVertexBufferObject.GL_ARRAY_BUFFER_ARB, vertexBufferID.get(0));
	glVertexPointer(3, GL_FLOAT, 0, 0);

	if (normals != null)
	{
	    glEnableClientState(GL_NORMAL_ARRAY);
	    ARBVertexBufferObject.glBindBufferARB(ARBVertexBufferObject.GL_ARRAY_BUFFER_ARB, normalBufferID.get(0));
	    glNormalPointer(GL_FLOAT, 0, 0);

	}

	if (BaseGame.renderTextures() && uvs != null)
	{
	    for (int q = 0; q < MAXTEXTURES; q++)
	    {
		if (uvs[q] != null && texture[q]!=null)
		{
		    texture[q].bind(q);

		    ARBMultitexture.glClientActiveTextureARB(ARBMultitexture.GL_TEXTURE0_ARB + q);
		    glEnableClientState(GL_TEXTURE_COORD_ARRAY);

		    ARBVertexBufferObject.glBindBufferARB(ARBVertexBufferObject.GL_ARRAY_BUFFER_ARB, uvBufferID[q].get(0));
		    glTexCoordPointer(2, GL_FLOAT, 0, 0);
		}
	    }
	}
	ARBVertexBufferObject.glBindBufferARB(ARBVertexBufferObject.GL_ELEMENT_ARRAY_BUFFER_ARB, indexBufferID.get(0));
	glDrawRangeElements(GL_TRIANGLES, 0, indices.capacity(), indices.capacity(), GL_UNSIGNED_INT, 0);

	disableStates();
    }

    /**
     * poista objektit muistista
     */
    public void vboDeleteBuffers()
    {
	if (vertexBufferID != null)
	    ARBVertexBufferObject.glDeleteBuffersARB(vertexBufferID);
	if (indexBufferID != null)
	    ARBVertexBufferObject.glDeleteBuffersARB(indexBufferID);
	if (normalBufferID != null)
	    ARBVertexBufferObject.glDeleteBuffersARB(normalBufferID);

	vertexBufferID = null;
	indexBufferID = null;
	normalBufferID = null;

	for (int q = 0; q < MAXTEXTURES; q++)
	{
	    if (uvBufferID[q] != null)
		ARBVertexBufferObject.glDeleteBuffersARB(uvBufferID[q]);
	    uvBufferID[q] = null;
	}

    }

    public void vboUpdate(Vector3f[] buffer, IntBuffer id)
    {
	if (vboIsStaticMesh)
	    return;

	// vbo mappaus ett� voidaan muuttaa dataa
	if (buffer != null)
	{
	    ARBVertexBufferObject.glBindBufferARB(ARBVertexBufferObject.GL_ARRAY_BUFFER_ARB, id.get(0));
	    ByteBuffer buf = ARBVertexBufferObject.glMapBufferARB(ARBVertexBufferObject.GL_ARRAY_BUFFER_ARB, ARBVertexBufferObject.GL_WRITE_ONLY_ARB, null);
	    FloatBuffer fbuf = buf.order(ByteOrder.nativeOrder()).asFloatBuffer();
	    for (int q = 0; q < buffer.length; q++)
	    {
		fbuf.put(buffer[q].x);
		fbuf.put(buffer[q].y);
		fbuf.put(buffer[q].z);
	    }
	    fbuf.rewind();

	    ARBVertexBufferObject.glUnmapBufferARB(ARBVertexBufferObject.GL_ARRAY_BUFFER_ARB);
	}
    }

    public void vboUpdate()
    {
	if (vboIsStaticMesh)
	    return;

	// vbo mappaus ett� voidaan muuttaa dataa
	ARBVertexBufferObject.glBindBufferARB(ARBVertexBufferObject.GL_ARRAY_BUFFER_ARB, vertexBufferID.get(0));
	ByteBuffer buf = ARBVertexBufferObject.glMapBufferARB(ARBVertexBufferObject.GL_ARRAY_BUFFER_ARB, ARBVertexBufferObject.GL_WRITE_ONLY_ARB, null);
	FloatBuffer fbuf = buf.order(ByteOrder.nativeOrder()).asFloatBuffer();
	fbuf.put(verts);
	fbuf.rewind();
	ARBVertexBufferObject.glUnmapBufferARB(ARBVertexBufferObject.GL_ARRAY_BUFFER_ARB);
    }

}
