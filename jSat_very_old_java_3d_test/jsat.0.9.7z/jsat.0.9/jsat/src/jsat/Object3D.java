/**
 * @file Object3D.java
 *
 * @author mjt, 2007-08
 * mixut@hotmail.com
 *
 * lataa staattisen 3d-mallin (wavefront .obj)
 *
 */
package jsat;

import java.io.*;
import java.util.StringTokenizer;
import java.io.IOException;
import java.util.Vector;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;
import static org.lwjgl.opengl.GL11.*;

public class Object3D extends Node
{
    private Object3D origData = null;

    private Vector<Mesh> meshes = new Vector<Mesh>();

    private static Mesh mesh = null;

    private int minFilter = GL_LINEAR, magFilter = GL_LINEAR;

    private boolean flipXZ=true; // k��nnet��nk� 90 asetta?
    public void FlipXZ(boolean flip) { flipXZ=flip; }
    
    // palauta shader jonka nimess� on str
    public GLSL getShader(String str)
    {
	if (meshes.size() == 0)
	{
	    return null;
	}
	for (int q = 0; q < meshes.size(); q++)
	{
	    if (meshes.get(q).shader != null && meshes.get(q).shader.name.contains(str))
	    {
		return meshes.get(q).shader;
	    }
	}

	return null;
    }

    public int getNumMeshes()
    {
	return meshes.size();
    }

    public void addMesh(Mesh mesh)
    {
	meshes.add(mesh);
    }

    public Mesh getMesh(int index)
    {
	return meshes.get(index);
    }

    public void setFilters(int minFilt, int magFilt)
    {
	minFilter = minFilt;
	magFilter = magFilt;
    }

    public Object3D(String name)
    {
	super(name);
	setType(OBJECT);
	origData = this;
    }

    /**
     * lataa skene ja lightmap tiedot. lightmapin voi renderoida blenderissa
     * bakella. lightMapName: tekstitiedosto jossa lightmapin nimi ja uv:t
     */
    public Object3D(String name, String fileName, String lightMapName, float xs, float ys, float zs) throws IOException
    {
	super(name);
	setType(OBJECT);

	load(fileName, xs, ys, zs, true);
	loadLightMapInfo(lightMapName); // lataa lightmapin tiedot tekstitiedostosta (nimi, uv:t)

	origData = this;

	ObjDatas.clear();
    }

    public Object3D(String name, String fileName, String lightMapName, float xs, float ys, float zs, boolean flipXZ) throws IOException
    {
	super(name);
        FlipXZ(flipXZ);
	setType(OBJECT);

	load(fileName, xs, ys, zs, true);
	loadLightMapInfo(lightMapName); // lataa lightmapin tiedot tekstitiedostosta (nimi, uv:t)

	origData = this;

	ObjDatas.clear();
    }

    // lataa uv:t
    private void loadLightMapInfo(String fileName)
    {
	FileIO in = new FileIO();
	String str = in.openAndReadFile(Settings.DATADIR + fileName);

	String strs[] = str.split("\n");

	int count = 0;
	int texIndex = 0;

	// aseta uv:t
	for (int m = 0; m < meshes.size(); m++)
	{
	    // aseta lightmap
	    Texture lmTex = Texture.loadTexture(Settings.TEXTUREDIR + strs[texIndex], minFilter, magFilter);
	    getMesh(m).setTexture(1, lmTex);

	    int num = meshes.get(m).faces.length * 3;
	    Vector2f texCoords[] = new Vector2f[num];

	    for (int q = 0; q < num; q++)
	    {

		// onko strs:ss� luku
		if ((strs[count].charAt(0) >= '0' && strs[count].charAt(0) <= '9') || strs[count].charAt(0) == '-')
		    ;
		else
		// lightmapin nimi

		{
		    texIndex = count;
		    count++;
		}

		texCoords[q] = new Vector2f();
		texCoords[q].x = Float.parseFloat(strs[count++]);
		texCoords[q].y = Float.parseFloat(strs[count++]);

	    }

	    getMesh(m).setTextureCoords(1, texCoords);

	}

    }

    // flipXZ: k��nnet��nk� objektia 90 astetta
    public Object3D(String name, String fileName, boolean flipXZ) throws IOException
    {
	super(name);
        FlipXZ(flipXZ);
	load(fileName, 1, 1, 1, true);
	setType(OBJECT);
	origData = this;
	ObjDatas.clear();
    }
    
    
    public Object3D(String name, String fileName) throws IOException
    {
	super(name);
	load(fileName, 1, 1, 1, true);
	setType(OBJECT);
	origData = this;
	ObjDatas.clear();
    }

    // t�t� k�ytet��n vain lightmapinfo ohjelmassa, kun otetaan alkuper�isest�
    // objektista uv:t talteen (ja makemeshes on aina false)
    public Object3D(boolean makeMeshes, String name, String fileName) throws IOException
    {
	super(name);
	load(fileName, 1, 1, 1, false);

	setType(OBJECT);
	origData = this;
	ObjDatas.clear();
    }

    public Object3D(String name, String fileName, float xs, float ys, float zs) throws IOException
    {
	super(name);
	load(fileName, xs, ys, zs, true);

	setType(OBJECT);
	origData = this;

	ObjDatas.clear();
    }
    public Object3D(String name, String fileName, float xs, float ys, float zs, boolean flipXZ) throws IOException
    {
	super(name);
        FlipXZ(flipXZ);
	load(fileName, xs, ys, zs, true);
	setType(OBJECT);
	origData = this;
	ObjDatas.clear();
    }

    public static Object3D makeClone(String name, Object3D obj)
    {
	Object3D tmp = new Object3D(name);
	tmp.origData = obj;

	tmp.name = name;
	tmp.setPosition(new Vector3f(0, 0, 0));
	tmp.setRotation(new Vector3f(0, 0, 0));

	return tmp;
    }

    /**
     * aseta objekteille testausmoodi. objIndex: meshin index. jos -1,
     * tehd��n modelin kaikille mesheille 
     * mode: mik� testaus tehd��n (BoundingArea.BOX, BoundingArea.CUBE, BoundingArea.SPHERE)
     */
    public void setBoundingMode(int objIndex, int mode)
    {
	if (objIndex == -1)
	{
	    for (int a = 0; a < meshes.size(); a++)
	    {
		meshes.get(a).boundings.mode = mode;
	    }
	} else
	{
	    meshes.get(objIndex).boundings.mode = mode;
	}

    }

    // kopsaa mesheihin vertex-datat, uv:t ym ja korjaa index taulukot
    void makeMesh(Mesh mesh)
    {
	if (mesh.faces.length == 0) // jos pathi 
	{
	    mesh.vertex = new Vector3f[ObjDatas.vertexV.size() / 3];
	    for (int q = 0; q < mesh.vertex.length; q++)
	    {
		mesh.vertex[q] = new Vector3f();
		mesh.vertex[q].set(ObjDatas.vertexV.get(q * 3), ObjDatas.vertexV.get(q * 3 + 1), ObjDatas.vertexV.get(q * 3 + 2));
	    }

	    return;
	}

	// kopioi ladatut datat mesheihin.
	int start = 999999, end = 0; // mist� mihin
	for (int q = 0; q < mesh.faces.length; q++)
	{
	    for (int w = 0; w < 3; w++)
	    {
		if (mesh.faces[q][w] < start)
		{
		    start = mesh.faces[q][w];
		}
		if (mesh.faces[q][w] > end)
		{
		    end = mesh.faces[q][w];
		}
	    }
	}
	mesh.vertex = new Vector3f[end - start + 1];
	for (int q = start, c = 0; q <= end; q++, c++)
	{
	    mesh.vertex[c] = new Vector3f();
	    mesh.vertex[c].set(ObjDatas.vertexV.get(q * 3), ObjDatas.vertexV.get(q * 3 + 1), ObjDatas.vertexV.get(q * 3 + 2));
	}
	for (int q = 0; q < mesh.faces.length; q++)
	{
	    for (int w = 0; w < 3; w++)
	    {
		mesh.faces[q][w] -= start;
	    }
	}

	// Normaalit
	start = 999999; // mist�
	end = 0; // mihin
	for (int q = 0; q < mesh.normalIndex.length; q++)
	{
	    for (int w = 0; w < 3; w++)
	    {
		if (mesh.normalIndex[q][w] < start)
		{
		    start = mesh.normalIndex[q][w];
		}
		if (mesh.normalIndex[q][w] > end)
		{
		    end = mesh.normalIndex[q][w];
		}
	    }
	}
	mesh.vertexNormals = new Vector3f[end - start + 1];
	for (int q = start, c = 0; q <= end; q++, c++)
	{
	    mesh.vertexNormals[c] = new Vector3f();
	    mesh.vertexNormals[c].set(ObjDatas.normalV.get(q * 3), ObjDatas.normalV.get(q * 3 + 1), ObjDatas.normalV.get(q * 3 + 2));
	}
	for (int q = 0; q < mesh.normalIndex.length; q++)
	{
	    for (int w = 0; w < 3; w++)
	    {
		mesh.normalIndex[q][w] -= start;
	    }
	}

	// UV:t
	start = 999999; // mist�
	end = 0; // mihin
	for (int q = 0; q < mesh.uvIndex.length; q++)
	{
	    for (int w = 0; w < 3; w++)
	    {
		if (mesh.uvIndex[q][w] < start)
		{
		    start = mesh.uvIndex[q][w];
		}
		if (mesh.uvIndex[q][w] > end)
		{
		    end = mesh.uvIndex[q][w];
		}
	    }
	}
	mesh.uv = new Vector2f[end - start + 1];
	for (int q = start, c = 0; q <= end; q++, c++)
	{
	    mesh.uv[c] = new Vector2f();
	    mesh.uv[c].set(ObjDatas.texCoordV.get(q * 2), ObjDatas.texCoordV.get(q * 2 + 1));
	}
	for (int q = 0; q < mesh.uvIndex.length; q++)
	{
	    for (int w = 0; w < 3; w++)
	    {
		mesh.uvIndex[q][w] -= start;
	    }
	}

	mesh.boundings.setup(mesh.vertex, mesh.faces, BoundingArea.BOX);

	// luo vertex array
	makeVertexArray(mesh);

    }

    /**
     * lataa model. xs, ys ja zs: skaalausarvot
     */
    public void load(String fileName, float xs, float ys, float zs, boolean makeMeshes) throws IOException
    {
	loadModel(fileName, xs, ys, zs);

	for (int a = 0; a < meshes.size(); a++)
	{
	    Mesh tmp = (Mesh) meshes.get(a);

	    // laske joka polyn tason normaali
	    tmp.faceNormals = new Vector4f[tmp.faces.length];
	    Vector3f v1 = new Vector3f();
	    Vector3f v2 = new Vector3f();
	    Vector3f v3 = new Vector3f();
	    for (int q = 0; q < tmp.faces.length; q++)
	    {
		tmp.faceNormals[q] = new Vector4f();
		int face[] = tmp.faces[q];

		v1.set(ObjDatas.vertexV.get(face[0] * 3), ObjDatas.vertexV.get(face[0] * 3 + 1), ObjDatas.vertexV.get(face[0] * 3 + 2));
		v2.set(ObjDatas.vertexV.get(face[1] * 3), ObjDatas.vertexV.get(face[1] * 3 + 1), ObjDatas.vertexV.get(face[1] * 3 + 2));
		v3.set(ObjDatas.vertexV.get(face[2] * 3), ObjDatas.vertexV.get(face[2] * 3 + 1), ObjDatas.vertexV.get(face[2] * 3 + 2));
		Geometry.calcPlane(v1, v2, v3, tmp.faceNormals[q]);
	    }

	    // jos halutaan varjot
	    if (Settings.useShadowVolumes == true)
	    {
		// varaa tilaa varjoille
		tmp.shadow = new ShadowVolumes(tmp.faces.length);
		tmp.shadow.setPlanes(tmp.faceNormals);
		tmp.shadow.setConnectivity(tmp.faces);
	    }

	    // etsi kamera
	    if (meshes.get(a).name.contains("camera"))
	    {
		BaseGame.camera.setWorldSpacePosition(ObjDatas.vertexV.get(meshes.get(a).faces[0][0] * 3), ObjDatas.vertexV
			.get(meshes.get(a).faces[0][0] * 3 + 1), ObjDatas.vertexV.get(meshes.get(a).faces[0][0] * 3 + 2));
		Log.write("Found: camera", Log.INFO);
	    }

	    if (makeMeshes)
		makeMesh(meshes.get(a)); // jos kopataan mesheihin datat t�ss� vaiheessa
	}

	loadTextures(minFilter, magFilter);

    }

    public void makeVertexArray(Mesh mesh)
    {
	Vector3f vbuf[] = new Vector3f[mesh.faces.length * 3];
	Vector3f nbuf[] = new Vector3f[mesh.normalIndex.length * 3];
	int fbuf[][] = new int[mesh.faces.length][3];
	Vector2f uvbuf[] = new Vector2f[mesh.uvIndex.length * 3];

	for (int q = 0; q < mesh.faces.length; q++)
	{
	    for (int w = 0; w < 3; w++)
	    {
		int ii = q * 3 + w;

		fbuf[q][w] = ii;

		if (mesh.uvIndex != null)
		{
		    if (mesh.uv.length > 0)
		    {
			int ti = mesh.uvIndex[q][w];
			uvbuf[ii] = new Vector2f();
			uvbuf[ii].x = mesh.uv[ti].x;
			uvbuf[ii].y = mesh.uv[ti].y;
		    }

		    if (mesh.normalIndex != null)
		    {
			int ni = mesh.normalIndex[q][w];
			nbuf[ii] = new Vector3f();
			nbuf[ii].x = mesh.vertexNormals[ni].x;
			nbuf[ii].y = mesh.vertexNormals[ni].y;
			nbuf[ii].z = mesh.vertexNormals[ni].z;

		    }

		    int i = mesh.faces[q][w];
		    vbuf[ii] = new Vector3f();
		    vbuf[ii].x = mesh.vertex[i].x;
		    vbuf[ii].y = mesh.vertex[i].y;
		    vbuf[ii].z = mesh.vertex[i].z;
		}
	    }
	}
	mesh.createBuffers(vbuf, fbuf, nbuf, uvbuf, true);

    }

    public void loadTextures(int minFilter, int magFilter) throws IOException
    {
	for (int q = 0; q < meshes.size(); q++)
	{
	    Mesh tmp = (Mesh) meshes.get(q);

	    if (tmp.material.getMaterialInfo().diffuseTex != null && tmp.material.getMaterialInfo().diffuseTex.equals("null") == false)
	    {
		tmp.setTexture(0, Texture.loadTexture(Settings.TEXTUREDIR + tmp.material.getMaterialInfo().diffuseTex, minFilter, magFilter));
	    }

	    if (Settings.GLSLSupported == false)
	    {
		continue;
	    }

	    // tarkista normal mapit / vesi
	    if (tmp.material.getMaterialInfo().bumpTex != null && tmp.material.getMaterialInfo().bumpTex.contains("null") == false)
	    {
		// objektille water shaderi
		if (tmp.material.getMaterialInfo().bumpTex.equals("WaterEffect"))
		{
		    tmp.setTexture(1, Texture.loadTexture(Settings.TEXTUREDIR + "bumpmap.jpg", minFilter, magFilter));

		    Log.write("load shader: water");
		    tmp.shader = new GLSL();
		    tmp.shader.loadPrograms("water.vert", "water.frag");
		    tmp.shader.bind();
		    tmp.shader.setUniform("texture", null, new int[] { 0 });
		    tmp.shader.setUniform("normalMap", null, new int[] { 1 });
		    tmp.shader.setUniform("mult", new float[] { 1.0f }, null);

		} else
		// normal map
		{
		    tmp.setTexture(1, Texture.loadTexture(Settings.TEXTUREDIR + tmp.material.getMaterialInfo().bumpTex, minFilter, magFilter));
		    Log.write("load shader: normalmapping");

		    tmp.shader = new GLSL();
		    tmp.shader.loadPrograms("normalmapping.vert", "normalmapping.frag");
		    tmp.shader.bind();
		    tmp.shader.setUniform("texture", null, new int[] { 0 });
		    tmp.shader.setUniform("normalMap", null, new int[] { 1 });
		    tmp.shader.setUniform("mult", new float[] { 1.0f }, null);

		}
	    }

	    // jos specularTex mapping (toon, ..)
	    if (tmp.material.getMaterialInfo().specularTex != null && tmp.material.getMaterialInfo().specularTex.contains("null") == false)
	    {
		// objektille toon shaderi
		if (tmp.material.getMaterialInfo().specularTex.equals("ToonShading"))
		{
		    Log.write("load shader: toon");
		    tmp.shader = new GLSL();
		    tmp.shader.loadPrograms("toon.vert", "toon.frag");
		    tmp.shader.bind();
		}

	    }

	    GLSL.unbind();

	}
    }

    public void loadModel(String fileName, float xs, float ys, float zs) throws IOException
    {
	fileName = Settings.DATADIR + fileName;

	// avaa tiedosto
	File f = new File(fileName);
	BufferedReader in = new BufferedReader(new FileReader(f));
	mesh = null;

	boolean readFace = false;
	int lineNum = 0;

	while (true)
	{
	    // lue rivi
	    String line = in.readLine();
	    lineNum++;

	    if (line == null)
	    {
		copyData();
		break;
	    }

	    // jos tyhj� rivi niin ei k�sitell�
	    if (line.equals(""))
	    {
		continue;
	    }
	    // jos kommenttirivi, ei k�sitell�
	    if (line.charAt(0) == '#')
	    {
		continue;
	    }

	    // tarkistus ett� f rivit on oikein
	    if (line.charAt(0) == 'f')
	    {
		if (line.contains("/") == false)
		{
		    continue;
		} // hypp�� yli jos v��r� f -rivi
		// Log.write("Error: "+fileName+" line: "+rivinum);

	    }

	    // korvaa / merkit tyhj�ll�
	    line = line.replace('/', ' ');

	    StringTokenizer st = new StringTokenizer(line);
	    String str = st.nextToken();

	    if (str.equals("usemtl"))
	    {
		// viime kerralla face, nyt usemtl eli alkaa uusi objekti
		if (readFace == true)
		{
		    if (mesh != null)
		    {
			copyData();
		    }

		    // luo mesh johon tiedot ladataan
		    mesh = new Mesh();
		    mesh.name = "mesh";
		}

		// materiaalin nimi
		mesh.material.setMaterial(st.nextToken());
		continue;
	    }
	    readFace = false;

	    // luo objekti ja lue nimi
	    if (str.equals("o") || str.equals("g"))
	    {
		if (mesh != null)
		{
		    copyData();
		}

		// luo mesh johon tiedot ladataan
		mesh = new Mesh();
		mesh.name = st.nextToken();
		continue;
	    }

	    // materiaalitiedosto
	    if (str.equals("mtllib"))
	    {
		Material.loadMaterial(st.nextToken());
		continue;
	    }

	    // lataa vertexit
	    if (str.equals("v"))
	    {
		float x = Float.parseFloat(st.nextToken()) * xs;
		float y = Float.parseFloat(st.nextToken()) * ys;
		float z = Float.parseFloat(st.nextToken()) * zs;
		if(flipXZ)
                {
                    ObjDatas.vertexV.add(x);
                    ObjDatas.vertexV.add(z);
                    ObjDatas.vertexV.add(y);
                }
                else
                {
                    ObjDatas.vertexV.add(x);
                    ObjDatas.vertexV.add(y);
                    ObjDatas.vertexV.add(z);
                }
		continue;
	    }

	    // lataa normaalit
	    if (str.equals("vn"))
	    {
		float x = Float.parseFloat(st.nextToken());
		float y = Float.parseFloat(st.nextToken());
		float z = Float.parseFloat(st.nextToken());
		if(flipXZ)
                {
                    ObjDatas.normalV.add(x);
                    ObjDatas.normalV.add(z);
                    ObjDatas.normalV.add(y);
                }
                else
                {
                    ObjDatas.normalV.add(x);
                    ObjDatas.normalV.add(y);
                    ObjDatas.normalV.add(z);
                }
                    
		continue;
	    }

	    // lataa texturekoordinaatit
	    if (str.equals("vt"))
	    {
		float u = Float.parseFloat(st.nextToken());
		float v = Float.parseFloat(st.nextToken());
		if(st.hasMoreTokens()) st.nextToken();

		ObjDatas.texCoordV.add(u);
		ObjDatas.texCoordV.add(-v); // y suunnassa k��nnetty
		continue;
	    }

	    // lataa face indexit
	    if (str.equals("f"))
	    {
		int tok = st.countTokens();

		// indexit vertexeille ja texturekoordinaateille
		for (int oo = 0; oo < 3; oo++)
		{
		    int vi = Integer.parseInt(st.nextToken()); // vertex index

		    if ( /* mesh.getMaterialInfo().getMaterialInfo().name!=null && */tok == 9)
		    {
			int ti = Integer.parseInt(st.nextToken()); // texture
			// index
			ObjDatas.texCoordIndexV.add(ti);
		    }
		    int ni = Integer.parseInt(st.nextToken()); // normal index
		    ObjDatas.normalIndexV.add(ni);

		    ObjDatas.faceIndexV.add(vi);

		}

		readFace = true;
		continue;
	    }
	}

    }

    private void copyData()
    {
	// jos valo ladattu
	if (mesh.name.contains("light"))
	{
	    MaterialInfo mat = mesh.material.getMaterialInfo();

	    // luodaan valo ja lis�t��n objektiin
	    Light lt = new Light(mat.name, 0);

	    lt.setAmbient(new Colorf(mat.ambientColor.r, mat.ambientColor.g, mat.ambientColor.b, 1));
	    lt.setDiffuse(new Colorf(mat.diffuseColor.r, mat.diffuseColor.g, mat.diffuseColor.b, 1));
	    lt.setSpecular(new Colorf(mat.specularColor.r, mat.specularColor.g, mat.specularColor.b, 1));

	    lt.setPosition(ObjDatas.vertexV.get(ObjDatas.faceIndexV.get(0) * 3), ObjDatas.vertexV.get(ObjDatas.faceIndexV.get(0) * 3 + 1), ObjDatas.vertexV
		    .get(ObjDatas.faceIndexV.get(0) * 3 + 2));
	    add(lt); // valo talteen

	    // siivous seuraavaa objektia varten
	    ObjDatas.faceIndexV.clear();
	    ObjDatas.texCoordIndexV.clear();
	    ObjDatas.normalIndexV.clear();
	    mesh = null;

	    return; // valolle ei muuta
	}

	// varaa taulukot
	mesh.faces = new int[ObjDatas.faceIndexV.size() / 3][3];
	mesh.uvIndex = new int[ObjDatas.faceIndexV.size() / 3][3];
	mesh.normalIndex = new int[ObjDatas.normalIndexV.size() / 3][3];

        int tt[]=new int[3];
        if(flipXZ)
        {
            tt[0]=0;
            tt[1]=2;
            tt[2]=1;
        }
        else
        {
            tt[0]=0;
            tt[1]=1;
            tt[2]=2;
        }
	// kopsaa datat scenen taulukoihin
	for (int q = 0; q < mesh.faces.length; q++)
	{
	    for (int w = 0; w < 3; w++)
	    {
		mesh.faces[q][tt[w]] = (Integer) ObjDatas.faceIndexV.get(q * 3 + w) - 1;
		if (ObjDatas.texCoordIndexV.size() > 0)
		{
		    mesh.uvIndex[q][tt[w]] = (Integer) ObjDatas.texCoordIndexV.get(q * 3 + w) - 1;
		}
	    }
	}
	for (int q = 0; q < ObjDatas.normalIndexV.size() / 3; q++)
	{
	    mesh.normalIndex[q][0] = (Integer) ObjDatas.normalIndexV.get(q * 3 + 0) - 1;
	    mesh.normalIndex[q][2] = (Integer) ObjDatas.normalIndexV.get(q * 3 + 1) - 1;
	    mesh.normalIndex[q][1] = (Integer) ObjDatas.normalIndexV.get(q * 3 + 2) - 1;
	}

	// objekti talteen
	meshes.add(mesh);

	// siivous seuraavaa objektia varten
	ObjDatas.faceIndexV.clear();
	ObjDatas.texCoordIndexV.clear();
	ObjDatas.normalIndexV.clear();
	mesh = null;
    }

    @Override
    public void renderShadow()
    {
	origData.renderShadow(getPosition(), getRotation());

    }

    public void renderShadow(Vector3f pos, Vector3f rot)
    {
	int a;
	for (a = 0; a < meshes.size(); a++)
	{
	    Mesh tmp = (Mesh) meshes.get(a);
	    tmp.shadow.buildShadowVolume(tmp.vertex, tmp.faces, pos, rot);
	}
    }

    @Override
    public void renderModel(boolean rendTrans)
    {
	origData.render(name, getWorldSpacePosition(), getPosition(), getRotation(), rendTrans);
    }

    /**
     * renderoi objekti se jos se on n�k�kent�ss�.
     */
    public void render(String name, Vector3f pos, Vector3f opos, Vector3f orot, boolean rendTrans)
    {
	if (BaseGame.selectMode == 1)
	{
	    glDisable(GL_DITHER);
	}

	for (int a = 0; a < meshes.size(); a++)
	{
	    if (BaseGame.selectMode == 1)
	    {
		byte r = (byte) (curObj >> 16);
		byte g = (byte) (curObj >> 8);
		byte b = (byte) curObj;
		b++;
		glColor3ub(r, g, b);
	    } else if (BaseGame.selectMode == 2)
	    {
		glLoadName(curObj);
	    } else if (objCb != null)
	    {
		objCb.objAction(name, curObj, this, opos, orot);
	    }

	    curObj++;

	    Mesh tmp = meshes.get(a);

	    if (((rendTrans == false && tmp.material.getMaterialInfo().dissolve == 1.0f))
		    || (rendTrans == true && tmp.material.getMaterialInfo().dissolve != 1.0f))
	    {
		// tarkista onko meshi ruudulla
		if (Frustum.objInFrustum(pos.x, pos.y, pos.z, tmp.boundings) == true || BaseGame.selectMode > 0)
		{
		    tmp.renderMesh();
		    BaseGame.objectsRendered++;
		}

	    }

	}

	if (BaseGame.selectMode == 1)
	{
	    glEnable(GL_DITHER);
	    glColor3f(1, 1, 1);
	}
    }

    public void useShader(boolean use)
    {
	for (int q = 0; q < meshes.size(); q++)
	{
	    meshes.get(q).useShader(use);
	}
    }
}

// apuluokka. k�ytet��n objektin latauksessa
final class ObjDatas
{
    // k�ytet��n obj-tiedostojen latauksessa
    public static Vector<Float> vertexV = new Vector<Float>();

    public static Vector<Float> normalV = new Vector<Float>();

    public static Vector<Float> texCoordV = new Vector<Float>();

    public static Vector<Integer> faceIndexV = new Vector<Integer>();

    public static Vector<Integer> texCoordIndexV = new Vector<Integer>();

    public static Vector<Integer> normalIndexV = new Vector<Integer>();

    // siivoa sotkut joita k�ytetty latauksessa
    public static void clear()
    {
	vertexV.clear();
	normalV.clear();
	texCoordV.clear();
	faceIndexV.clear();
	texCoordIndexV.clear();
	normalIndexV.clear();
    }
}
