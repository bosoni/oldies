/**
 * @file Quaternion.java
 *
 * java port by mjt, 2006
 * 
 */
package jsat;

import org.lwjgl.util.vector.Vector3f;

public class Quaternion
{
    protected float x;

    protected float y;

    protected float z;

    protected float w;

    public Quaternion()
    {
    }

    public Quaternion(float x, float y, float z, float w)
    {
	this.x = x;
	this.y = y;
	this.z = z;
	this.w = w;
    }

    void set(final Quaternion q)
    {
	x = q.x;
	y = q.y;
	z = q.z;
	w = q.w;
    }

    void quatComputeW()
    {
	float t = 1.0f - (x * x) - (y * y) - (z * z);

	if (t < 0.0f)
	{
	    w = 0.0f;
	} else
	{
	    w = (float) -Math.sqrt(t);
	}
    }

    static Quaternion quatNormalize(final Quaternion q)
    {
	/* compute magnitude of the quaternion */
	float mag = (float) Math.sqrt((q.x * q.x) + (q.y * q.y) + (q.z * q.z) + (q.w * q.w));

	/* check for bogus length, to protect against divide by zero */
	if (mag > 0.0f)
	{
	    /* normalize it */
	    float oneOverMag = 1.0f / mag;

	    q.x *= oneOverMag;
	    q.y *= oneOverMag;
	    q.z *= oneOverMag;
	    q.w *= oneOverMag;
	}
	return q;
    }

    static Quaternion quatMultQuat(final Quaternion qb, final Quaternion qa)
    {
	Quaternion out = new Quaternion();

	out.w = (qb.w * qa.w) - (qb.x * qa.x) - (qb.y * qa.y) - (qb.z * qa.z);
	out.x = ((qb.w * qa.x) + (qb.x * qa.w) + (qb.y * qa.z)) - (qb.z * qa.y);
	out.y = ((qb.w * qa.y) + (qb.y * qa.w) + (qb.z * qa.x)) - (qb.x * qa.z);
	out.z = ((qb.w * qa.z) + (qb.z * qa.w) + (qb.x * qa.y)) - (qb.y * qa.x);

	return out;
    }

    static Quaternion quatMultVec(final Quaternion q, final Vector3f v)
    {
	Quaternion out = new Quaternion();

	out.w = -(q.x * v.x) - (q.y * v.y) - (q.z * v.z);
	out.x = ((q.w * v.x) + (q.y * v.z)) - (q.z * v.y);
	out.y = ((q.w * v.y) + (q.z * v.x)) - (q.x * v.z);
	out.z = ((q.w * v.z) + (q.x * v.y)) - (q.y * v.x);

	return out;
    }

    static Vector3f quatRotatePoint(final Quaternion q, final Vector3f in)
    {
	Vector3f outv = new Vector3f();
	Quaternion inv = new Quaternion();

	inv.x = -q.x;
	inv.y = -q.y;
	inv.z = -q.z;
	inv.w = q.w;

	Quaternion norminv = quatNormalize(inv);
	Quaternion tmp = quatMultVec(q, in);
	Quaternion tmp2 = quatMultQuat(tmp, norminv);

	outv.x = tmp2.x;
	outv.y = tmp2.y;
	outv.z = tmp2.z;

	return outv;
    }
    /*
     *   quat4_t tmp, inv, final;

  inv[X] = -q[X]; 
     inv[Y] = -q[Y];
  inv[Z] = -q[Z]; 
     inv[W] =  q[W];

  Quat_normalize (inv);

  Quat_multVec (q, in, tmp);
  Quat_multQuat (tmp, inv, final);

  out[X] = final[X];
  out[Y] = final[Y];
  out[Z] = final[Z];

     */ 

    static float quatDotProduct(final Quaternion qa, final Quaternion qb)
    {
	return ((qa.x * qb.x) + (qa.y * qb.y) + (qa.z * qb.z) + (qa.w * qb.w));
    }

    static Quaternion quatSlerp(final Quaternion qa, final Quaternion qb, final float t)
    {
	Quaternion out = new Quaternion();

	// check for out-of range parameter and return edge points if so
	if (t <= 0.0)
	{
	    out.set(qa);
	    return out;
	}

	if (t >= 1.0)
	{
	    out.set(qb);
	    return out;
	}

	// compute "cosine of angle between quaternions" using dot product
	float cosOmega = quatDotProduct(qa, qb);

	// if negative dot, use -q1. two quaternions q and -q
	// represent the same rotation, but may produce
	// different slerp. we chose q or -q to rotate using
	// the acute angle.
	float q1w = qb.w;
	float q1x = qb.x;
	float q1y = qb.y;
	float q1z = qb.z;

	if (cosOmega < 0.0f)
	{
	    q1w = -q1w;
	    q1x = -q1x;
	    q1y = -q1y;
	    q1z = -q1z;
	    cosOmega = -cosOmega;
	}

	// we should have two unit quaternions, so dot should be <= 1.0
	// assert( cosOmega < 1.1f );
	if (cosOmega >= 1.1f)
	{
	    Log.write("error: quatSlerp", Log.ERROR);
	}

	// compute interpolation fraction, checking for quaternions
	// almost exactly the same
	float k0;

	// compute interpolation fraction, checking for quaternions
	// almost exactly the same
	float k1;

	if (cosOmega > 0.9999f)
	{
	    // very close - just use linear interpolation,
	    // which will protect againt a divide by zero
	    k0 = 1.0f - t;
	    k1 = t;
	} else
	{
	    // compute the sin of the angle using the
	    // trig identity sin^2(omega) + cos^2(omega) = 1
	    float sinOmega = (float) Math.sqrt(1.0f - (cosOmega * cosOmega));

	    // compute the angle from its sin and cosine
	    float omega = (float) Math.atan2(sinOmega, cosOmega);

	    // compute inverse of denominator, so we only have to divide
	    // once
	    float oneOverSinOmega = 1.0f / sinOmega;

	    // Compute interpolation parameters
	    k0 = (float) Math.sin((1.0f - t) * omega) * oneOverSinOmega;
	    k1 = (float) Math.sin(t * omega) * oneOverSinOmega;
	}

	// interpolate and return new quaternion
	out.w = (k0 * qa.w) + (k1 * q1w);
	out.x = (k0 * qa.x) + (k1 * q1x);
	out.y = (k0 * qa.y) + (k1 * q1y);
	out.z = (k0 * qa.z) + (k1 * q1z);

	return out;
    }
}
