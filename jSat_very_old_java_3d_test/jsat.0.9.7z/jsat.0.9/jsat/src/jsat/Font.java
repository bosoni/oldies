/**
 * @file Font.java
 *
 * @author mjt, 2007
 * mixut@hotmail.com
 *
 */
package jsat;

import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.io.File;
import java.awt.image.Raster;
import static org.lwjgl.opengl.GL11.*;

/**
 * fontin lataus ja renderointi font tiedoston pit�� olla ^2 lev ja kor (..,
 * 128, 256, 512, 1024 jne)
 */
public class Font
{
    private static final String chars = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_'abcdefghijklmnopqrstuvwxyz{|}                                                                      �                 �             �                 �";

    private Texture fontTex = null;

    private float[][] uv = null;

    private int enter = 0;

    private int colCount = 0; // 3=RGB, 4=RGBA

    public Font(String fontFile) throws IOException
    {
	load(fontFile);
    }

    public void load(String fontFile) throws IOException
    {
	fontFile = Settings.FONTDIR + fontFile;

	// lataa font texture
	fontTex = new Texture(fontFile, 0x00); // musta v�ri l�pin�kyv�ksi

	// nyt ladataan se uudelleen ett� p��see etsim��n kirjaimet
	// pixelim�ss�st�
	BufferedImage image = ImageIO.read(new File(fontFile));

	int[] img = null;
	Raster r = image.getRaster();
	img = r.getPixels(0, 0, image.getWidth(), image.getHeight(), img);

	colCount = (image.getColorModel().hasAlpha() == true) ? 4 : 3;

	uv = new float[512][4];

	int charNo = 0;

	// kirjaimen vasen yl�nurkka
	int x = 0;
	int y = 0;

	// kirjaimen oikea alanurkka
	int x2 = 0;
	int y2 = 0;

	int up = getCol(img, 0);
	int down = getCol(img, colCount);

	while (true)
	{
	    if (getCol(img, POS(x, y)) != up)
	    {
		break; // ei en�� rivej�
	    }

	    // ala_y:n haku
	    // xy kohdasta sx oikealle kunnes tulee up-v�ri
	    // siit� (sx-1, sy) kohdasta sy niin kauas alas kunnes tulee
	    // v�ri down
	    // palauta sy
	    y2 = findY(img, x + 1, y, up, down);

	    if (enter == 0)
	    {
		enter = y2;
	    }

	    while (true)
	    {
		// kirjaimen haku:
		// sy=ala_y ja sx oikealle kunnes down v�ri
		// kirjain x,y, sx,sy
		x2 = findX(img, x, y2, down);

		if (x2 == -1)
		{
		    break; // ei kirjaimia en�� t�ll� rivill�
		}

		// kirjain on siis x,y -> x2,y2
		uv[charNo][0] = (float) x / image.getWidth();
		uv[charNo][1] = (float) (y + 1) / image.getHeight();
		uv[charNo][2] = (float) x2 / image.getWidth();
		uv[charNo][3] = (float) y2 / image.getHeight();
		charNo++;

		x = x2 + 1;
	    }

	    y = y2 + 1; // seuraava rivi
	    x = 0;
	}
    }

    private int findX(int[] img, int x, int y, int down)
    {
	int sx;

	for (sx = x;; sx++)
	{
	    if (sx == (fontTex.getWidth()))
	    {
		return -1;
	    }

	    if (getCol(img, POS(sx, y)) == down)
	    {
		return sx;
	    }
	}
    }

    private int findY(int[] img, int x, int y, int up, int down)
    {
	int sx;

	for (sx = x;; sx++)
	{
	    if (getCol(img, POS(sx, y)) == up)
	    {
		break;
	    }
	}

	for (int sy = y;; sy++)
	{
	    if (getCol(img, POS(sx - 1, sy)) == down)
	    {
		return sy;
	    }
	}

    }

    private int getCol(int[] img, int offs)
    {
	int ret = (int) img[offs++] + (img[offs++] << 8) + (img[offs] << 16);

	if (colCount == 4)
	{
	    ret += (img[offs + 1] << 24);
	}

	return ret;
    }

    private int POS(int x, int y)
    {
	return ((y * fontTex.getWidth()) + x) * colCount;
    }

    public void print(String str, int x, int y)
    {
	int q;
	int sx = x;
	int sy = y;

	fontTex.bind(0);

	glPushMatrix();
	glLoadIdentity();

	glPushAttrib(GL_ALL_ATTRIB_BITS);
	Light.disableLights();
	glEnable(GL_BLEND); // enable transparency
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); // overlay
	// cursor onto
	// scene
	glBegin(GL_QUADS);

	for (q = 0; q < str.length(); q++)
	{
	    char ch = str.charAt(q);

	    if (ch == '\n')
	    {
		sx = x;
		sy += enter;
	    } else
	    {
		for (int w = 0; w < chars.length(); w++) // etsi kirjain
		{
		    if (ch == chars.charAt(w))
		    {
			float _w = uv[w][2] - uv[w][0];
			float _h = uv[w][3] - uv[w][1];
			_w *= (float) fontTex.getWidth();
			_h *= (float) fontTex.getHeight();

			glTexCoord2f(uv[w][0], uv[w][3]);
			glVertex3f((float) sx, (float) sy, (float) 0);

			glTexCoord2f(uv[w][2], uv[w][3]);
			glVertex3f((float) sx + ((float) _w), (float) sy, (float) 0);

			glTexCoord2f(uv[w][2], uv[w][1]);
			glVertex3f((float) sx + ((float) _w), (float) sy + ((float) _h), (float) 0);

			glTexCoord2f(uv[w][0], uv[w][1]);
			glVertex3f((float) sx, (float) sy + ((float) _h), (float) 0);

			sx += _w;

			break;
		    }
		}
	    }
	}

	glEnd();
	glPopAttrib();

	glPopMatrix();
    }
}
