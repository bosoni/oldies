/**
 * @file BlurParameters.java
 *
 * @author mjt, 2007-08
 * mixut@hotmail.com
 */
package jsat;

public class BlurParameters
{
    int blur_Shader;

    float ambient;

    float textureSize;

    float blurSize;

    public BlurParameters()
    {
    }

    public BlurParameters(int blur_Shader, float ambient, float textureSize, float blurSize)
    {
	set(blur_Shader, ambient, textureSize, blurSize);
    }

    public void set(int _blur_Shader, float _ambient, float _textureSize, float _blurSize)
    {
	blur_Shader = _blur_Shader;
	ambient = _ambient;
	textureSize = _textureSize;
	blurSize = _blurSize;
    }
}
