/**
 * @file BaseGame.java
 *
 * @author mjt, 2007-08
 * mixut@hotmail.com
 *
 */
package jsat;

import java.util.Scanner;
import org.lwjgl.*;
import org.lwjgl.opengl.*;
import org.lwjgl.util.glu.GLU;
import static org.lwjgl.opengl.GL11.*;

/**
 * BaseGame luokka sis�lt�� metodit n�ytt�tilan asettamiseen, ym
 */
public class BaseGame
{
    public static final String VERSION = "0.9";

    public static int objectsRendered = 0;

    public SkyBox skybox = new SkyBox();

    public static Intersection ray = new Intersection();

    public static byte selectMode = 0; // 0==ei mit��n, 1==v�ri, 2==select buffer

    public static int textureFormat = GL_RGBA;

    public static Camera camera = new Camera("camera");

    public static Node world = new Node("world");

    public static ShadowMapping shadowMap = new ShadowMapping();

    public static Screen screen = new Screen();

    private static boolean renderTextures = true; // jos true, renderoi texturet

    public static void renderTextures(boolean rend)
    {
	renderTextures = rend;
    }

    public static boolean renderTextures()
    {
	return renderTextures;
    }

    /**
     * n�ytt�tilan tiedot
     */
    protected static DisplayMode mode = null;

    /**
     * l�hempi klippaustaso. lukua pienent�m�ll� shadow volumet alkaa bugaa.
     */
    protected static float nearClipping = 1f;

    /**
     * kauemmainen klippaustaso
     */
    protected static float farClipping = -1; // ��ret�n

    /**
     * field of view angle
     */
    protected static float fov = 45.0f;

    public void useShadowMapping(boolean use)
    {
	if (Settings.GLSLSupported == false)
	{
	    Log.write("Shadow mapping disabled.");
	    Settings.useShadowMapping = false;
	    return;
	}

	shadowMap.makeMap("lightmask.png");
	Settings.useShadowMapping = true;
    }

    public void useShadowVolumes(boolean use)
    {
	Settings.useShadowVolumes = use;

    }

    /**
     * Asettaa halutun n�ytt�tilan (asetettu Settings:iss�). ellei onnistu,
     * aiheuttaa poikkeuksen
     */
    public void setDisplayMode() throws LWJGLException
    {
	int i;

        // etsi haluttu n�ytt�tila ja aseta se
	DisplayMode[] modes = Display.getAvailableDisplayModes();

	for (i = 0; i < modes.length; i++)
	{
	    if ((modes[i].getWidth() == Settings.width) && (modes[i].getHeight() == Settings.height) && (modes[i].getBitsPerPixel() >= Settings.bpp))
	    {
		Display.setDisplayMode(modes[i]);

		break;
	    }
	}
        
	// jos n�ytt�tilan asettaminen ei onnistunut, n�yt� lista ja siit� voi
	// valita.
	if (i == modes.length)
	{
	    for (i = 0; i < modes.length; i++)
	    {
		Log.write("Mode " + i + ": " + modes[i].getWidth() + "x" + modes[i].getHeight() + " " + modes[i].getBitsPerPixel() + " bpp");
	    }
	    Log.write("Can't set display mode: " + Settings.width + "x" + Settings.height + " " + Settings.bpp + "bpp!");
	    Log.write("Choose mode:");

	    Scanner in = new Scanner(System.in);
	    int c_md = in.nextInt();
	    Display.setDisplayMode(modes[c_md]);
	    mode = modes[c_md];
	} else
	{
	    mode = modes[i];
	}
	Display.setTitle(Settings.TITLE);
	Display.setFullscreen(Settings.fullScreen);

        PixelFormat pf=new PixelFormat(Settings.alphaBits, Settings.zbufBits, Settings.stencilBits);
	Display.create(pf);

	// sync frame (only works on windows)
	Display.setVSyncEnabled(Settings.vsync);

        Log.write("jSat v" + VERSION + " by mjt");
	Log.write("*GL_VENDOR: " + glGetString(GL_VENDOR));
	Log.write("*GL_RENDERER: " + glGetString(GL_RENDERER));
	Log.write("*GL_VERSION: " + glGetString(GL_VERSION));

	glClearColor(0, 0, 0, 1);
	glClearDepth(1.0f);
	glClear(Settings.CLEARBUFFERS);
	Display.update();

	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);

	Light.enableLights();
	glEnable(GL_DEPTH_TEST);
	glShadeModel(GL_SMOOTH);
	glDepthFunc(GL_LEQUAL);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
	glEnable(GL_COLOR_MATERIAL);

	glViewport(0, 0, mode.getWidth(), mode.getHeight());
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
        GLU.gluPerspective(fov, mode.getWidth() / mode.getHeight(), nearClipping, farClipping);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	if (Settings.stencilBits > 0)
	{
	    Settings.CLEARBUFFERS |= GL_STENCIL_BUFFER_BIT;
	}

	if (GLContext.getCapabilities().GL_ARB_multitexture)
	{
	    Settings.multiTexturingSupported = true;
	    Log.write("GL_ARB_multitexture supported.");
	} else
	{
	    Log.write("GL_ARB_multitexture not supported.");
	}

	if (GLContext.getCapabilities().GL_EXT_texture_compression_s3tc)
	{
	    Log.write("GL_EXT_texture_compression_s3tc supported.");
	    textureFormat = EXTTextureCompressionS3TC.GL_COMPRESSED_RGBA_S3TC_DXT5_EXT;
	    Settings.S3TCSupported = true;
	} else
	{
	    Log.write("GL_EXT_texture_compression_s3tc not supported.");
	}

	// First check if the graphics card support GLSL.
	if (GLContext.getCapabilities().GL_ARB_vertex_shader && GLContext.getCapabilities().GL_ARB_fragment_shader)
	{
	    Settings.GLSLSupported = true;
	    Log.write("GL_ARB_vertex_shader and GL_ARB_fragment_shader supported.");
	} else
	{
	    Log.write("GL_ARB_vertex_shader/GL_ARB_fragment_shader not supported.");
	}

	if (glGetString(GL_VERSION).startsWith("1.0", 0) || glGetString(GL_VERSION).startsWith("1.1", 0) || glGetString(GL_VERSION).startsWith("1.2", 0))
	{
	    Settings.GL10_11_12 = true;
	}

	// DEBUG: testaa toimiiko 1.0, 1.1 ja 1.2 ajureilla ///////
	if (Settings.DEBUG)
	{
	    Settings.GL10_11_12 = true;
	    Settings.DISABLE_FBO = true;
	}
	// ///////////////////////////////////////////////////////

	if(GLContext.getCapabilities().GL_EXT_framebuffer_object)
	{
	    Log.write("GL_EXT_framebuffer_object supported.");
	}
	else
	    Log.write("GL_EXT_framebuffer_object not supported.");
	
	if (Settings.DISABLE_FBO)
	{
	    Settings.fboSupported = false;
	    Log.write("FBO disabled.");
	}

	screen.initFBO();

	if (GLContext.getCapabilities().GL_EXT_texture_3d)
	{
	    Log.write("GL_EXT_texture_3d supported.");
	    Settings.texture3DSupported = true;
	} else
	{
	    Log.write("GL_EXT_texture_3d not supported.");
	}

	if (GLContext.getCapabilities().GL_ARB_texture_cube_map)
	{
	    Log.write("GL_ARB_texture_cube_map supported.");
	    Settings.CUBEMAP = true;
	} else
	    Log.write("GL_ARB_texture_cube_map not supported.");

	if (GLContext.getCapabilities().GL_ARB_vertex_buffer_object)
	{
	    Log.write("GL_ARB_vertex_buffer_object supported.");
	    Settings.VBO = true;
	} else
	    Log.write("GL_ARB_vertex_buffer_object not supported.");
	
	if(Settings.DISABLE_VBO==true)
	{
	    Settings.VBO=false;
	    Log.write("VBO disabled.");
	}
	
	
	if (GLContext.getCapabilities().GL_ARB_texture_mirrored_repeat)
	{
	    Log.write("GL_ARB_texture_mirrored_repeat supported.");
	    Settings.MIRRORED_REPEAT = true;
	} else
	    Log.write("GL_ARB_texture_mirrored_repeat supported.");

    }

    public static void setViewport()
    {
	glMatrixMode(GL_MODELVIEW);
	glViewport(0, 0, mode.getWidth(), mode.getHeight());
    }

    public static void set2DMode()
    {
	glDisable(GL_DEPTH_TEST);
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrtho(0, mode.getWidth(), 0, mode.getHeight(), -1, 1);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
    }

    public static void set3DMode()
    {
	// palauta alkuper�iset matriisit
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();
	glEnable(GL_DEPTH_TEST);
    }

    public static int getScreenWidth()
    {
	return mode.getWidth();
    }

    public static int getScreenHeight()
    {
	return mode.getHeight();
    }

    public static void drawGrid()
    {
	glDisable(GL_COLOR_MATERIAL);
	glDisable(GL_TEXTURE_2D);
	glColor4f(0.7f, 0.7f, 0.7f, 1);
	glBegin(GL_LINES);
	// ristikko y tasoon
	for (int x = 0; x < 11; x++)
	{
	    glVertex3f(-50 + x * 10, 0, -50);
	    glVertex3f(-50 + x * 10, 0, 50);
	}
	for (int z = 0; z < 11; z++)
	{
	    glVertex3f(-50, 0, -50 + z * 10);
	    glVertex3f(50, 0, -50 + z * 10);
	}
	glEnd();
	glColor4f(1, 1, 1, 1);

	glEnable(GL_TEXTURE_2D);
	glEnable(GL_COLOR_MATERIAL);
    }

    public void init()
    {
    }
    public void render(float time)
    {
    }
    public void cleanup()
    {
    }
}
