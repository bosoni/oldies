/**
 * @file Fog.java
 *
 * @author mjt, 2007
 * mixut@hotmail.com
 *
 */
package jsat;

import static org.lwjgl.opengl.GL11.*;

public class Fog
{
    private static final int[] fogMode = { GL_EXP, GL_EXP2, GL_LINEAR };

    private static Colorf fogColor = new Colorf(0.3f, 0.2f, 0.5f);

    /**
     * aseta sumun v�ri
     */
    public static void setColor(Colorf col)
    {
	fogColor = col;
    }

    /**
     * luo sumu
     * 
     * @param mode
     *                0=GL_EXP, 1=GL_EXP2, 3=GL_LINEAR
     * 
     */
    public static void createFog(int mode, float start, float end, float density)
    {
	if ((mode < 0) || (mode >= 3))
	{
	    mode = 2;
	}

	glFogi(GL_FOG_MODE, fogMode[mode]); // Fog Mode

	glFog(GL_FOG_COLOR, fogColor.getBuffer()); // Set Fog Color
	glFogf(GL_FOG_DENSITY, density); // How Dense Will The Fog Be
	glHint(GL_FOG_HINT, GL_DONT_CARE); // Fog Hint Value
	glFogf(GL_FOG_START, start); // Fog Start Depth
	glFogf(GL_FOG_END, end); // Fog End Depth
	glEnable(GL_FOG);
    }

    public static void disableFog()
    {
	glDisable(GL_FOG);
    }
}
