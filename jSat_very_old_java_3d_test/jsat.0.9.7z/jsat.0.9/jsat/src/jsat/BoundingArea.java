/**
 * @file BoundingArea.java
 *
 * @author mjt, 2007-08
 * mixut@hotmail.com
 * 
 */
package jsat;

import java.nio.FloatBuffer;
import java.util.Vector;
import org.lwjgl.util.vector.Vector3f;
import static org.lwjgl.opengl.GL11.*;

public class BoundingArea
{
    public static final int BOX = 0;

    public static final int CUBE = 1;

    public static final int SPHERE = 2;

    Vector3f min = new Vector3f(99999, 99999, 99999);

    Vector3f max = new Vector3f(-99999, -99999, -99999);

    float r = 0;

    float size = 0;

    int mode = 0; // mik� testaus tehd��n: 0=cube, 1=box, 2=sphere

    private float getMax(float a, float b)
    {
	if (a > b)
	{
	    return a;
	}
	return b;
    }

    private float getMin(float a, float b)
    {
	if (a < b)
	{
	    return a;
	}
	return b;
    }

    public void setup(Vector3f[] vert, int faces[][], int _mode)
    {
	mode = _mode;

	// box
	int q;
	for (q = 0; q < faces.length; q++)
	{
	    for (int w = 0; w < 3; w++)
	    {
		int f = faces[q][w];

		min.x = getMin(vert[f].x, min.x);
		min.y = getMin(vert[f].y, min.y);
		min.z = getMin(vert[f].z, min.z);

		max.x = getMax(vert[f].x, max.x);
		max.y = getMax(vert[f].y, max.y);
		max.z = getMax(vert[f].z, max.z);
	    }

	}

	// s�de
	Vector3f out = new Vector3f();
	Vector3f.sub(max, min, out);
	r = (float) Math.sqrt(out.lengthSquared());

	// cube
	size = getMax(size, out.x);
	size = getMax(size, out.y);
	size = getMax(size, out.z);

    }

    public void setup(Vector<Float> vert, int faces[][], int _mode)
    {
	mode = _mode;

	// box
	int q;
	for (q = 0; q < faces.length; q++)
	{
	    for (int w = 0; w < 3; w++)
	    {
		int f = faces[q][w] * 3;

		min.x = getMin(vert.get(f), min.x);
		min.y = getMin(vert.get(f + 1), min.y);
		min.z = getMin(vert.get(f + 2), min.z);

		max.x = getMin(vert.get(f), max.x);
		max.y = getMin(vert.get(f + 1), max.y);
		max.z = getMin(vert.get(f + 2), max.z);
	    }

	}

	// s�de
	Vector3f out = new Vector3f();
	Vector3f.sub(max, min, out);
	r = (float) Math.sqrt(out.lengthSquared());

	// cube
	size = getMax(size, out.x);
	size = getMax(size, out.y);
	size = getMax(size, out.z);

    }
    
    public void setup(FloatBuffer vert, int faces[][], int _mode)
    {
	mode = _mode;

	// box
	int q;
	for (q = 0; q < faces.length; q++)
	{
	    for (int w = 0; w < 3; w++)
	    {
		int f = faces[q][w] * 3;

		min.x = getMin(vert.get(f), min.x);
		min.y = getMin(vert.get(f + 1), min.y);
		min.z = getMin(vert.get(f + 2), min.z);

		max.x = getMin(vert.get(f), max.x);
		max.y = getMin(vert.get(f + 1), max.y);
		max.z = getMin(vert.get(f + 2), max.z);
	    }

	}

	// s�de
	Vector3f out = new Vector3f();
	Vector3f.sub(max, min, out);
	r = (float) Math.sqrt(out.lengthSquared());

	// cube
	size = getMax(size, out.x);
	size = getMax(size, out.y);
	size = getMax(size, out.z);

    }    

    public void setup(Vector3f[] vert, Vector faces)
    {
	mode = BOX;
	for (int q = 0; q < faces.size(); q++)
	{
	    int f = (Integer) faces.get(q);

	    min.x = getMin(vert[f].x, min.x);
	    min.y = getMin(vert[f].y, min.y);
	    min.z = getMin(vert[f].z, min.z);

	    max.x = getMax(vert[f].x, max.x);
	    max.y = getMax(vert[f].y, max.y);
	    max.z = getMax(vert[f].z, max.z);
	}
    }

    public void setup(Vector<Float> vert, Vector<Integer> faces)
    {
	mode = BOX;
	for (int q = 0; q < faces.size(); q++)
	{
	    int f = faces.get(q) * 3;
	    min.x = getMin(vert.get(f), min.x);
	    min.y = getMin(vert.get(f + 1), min.y);
	    min.z = getMin(vert.get(f + 2), min.z);

	    max.x = getMin(vert.get(f), max.x);
	    max.y = getMin(vert.get(f + 1), max.y);
	    max.z = getMin(vert.get(f + 2), max.z);
	}
    }

    public void draw()
    {
	glBegin(GL_LINE_STRIP);
	glVertex3f(min.x, max.y, min.z);
	glVertex3f(max.x, max.y, min.z);
	glVertex3f(max.x, max.y, max.z);
	glVertex3f(min.x, max.y, max.z);
	glVertex3f(min.x, max.y, min.z);
	glEnd();
    }
}
