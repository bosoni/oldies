/**
 * @file Light.java
 *
 * @author mjt, 2007-08
 * mixut@hotmail.com
 *
 * Valon k�sittely -luokka.
 */
package jsat;

import java.util.Vector;
import static org.lwjgl.opengl.GL11.*;

public class Light extends Node
{
    // vektori valoille
    public static Vector<Light> lights = new Vector<Light>();

    private int light = 0;

    private Colorf diffuse = new Colorf(1, 1, 1);

    private Colorf specular = new Colorf(0.5f, 0.5f, 0.5f);

    private Colorf ambient = new Colorf(0.2f, 0.2f, 0.2f);

    private boolean enabled = false;

    public static void disableLights()
    {
	glDisable(GL_LIGHTING);
    }

    public static void enableLights()
    {
	glEnable(GL_LIGHTING);
    }

    /**
     * luo valo
     * 
     * @param name
     *                nimi
     */
    public Light(String name, int lightNo)
    {
	super(name);
	light = lightNo;
	setType(LIGHT);
    }

    public Colorf getAmbient()
    {
	return ambient;
    }

    static boolean useLights = true;

    /**
     * k�ytet��nk� opengl valoja
     */
    public void useLights(boolean uselights)
    {
	useLights = uselights;
    }

    /**
     * aseta ambient v�ri
     * 
     * @param col
     *                v�ri
     */
    public void setAmbient(Colorf col)
    {
	ambient = col;
    }

    public void setSpecular(Colorf col)
    {
	specular = col;
    }

    public void setDiffuse(Colorf col)
    {
	diffuse = col;
    }

    /**
     * aseta valon paikka ettei se liiku kameran mukana
     */
    public void setLight()
    {
	if (enabled == false)
	{
	    return;
	}
	glLight(GL_LIGHT0 + light, GL_POSITION, getWSPositionBuffer());
	glEnable(GL_LIGHT0 + light);
    }

    public void updateLight()
    {
	if (enabled == false)
	{
	    return;
	}
	enable();
    }

    public void setLight(int l)
    {
	light = l;
	setLight();
    }

    public void enable(int l)
    {
	light = l;
	enable();
    }

    /**
     * haluttu valo p��lle. asettaa my�s paikan ja ambient, specular ja
     * diffuse v�rit
     */
    public void enable()
    {
	enabled = true;
	glLight(GL_LIGHT0 + light, GL_AMBIENT, ambient.getBuffer());
	glLight(GL_LIGHT0 + light, GL_DIFFUSE, diffuse.getBuffer());
	glLight(GL_LIGHT0 + light, GL_SPECULAR, specular.getBuffer());
	glLight(GL_LIGHT0 + light, GL_POSITION, getWSPositionBuffer());
	glEnable(GL_LIGHT0 + light);
    }

    /**
     * valo pois p��lt�
     * 
     */
    public void disable()
    {
	enabled = false;
	glDisable(GL_LIGHT0 + light);
    }

    /**
     * Ei tee mit��n
     */
    public void render()
    {
    }

    public static void setLights()
    {
	for (int q = 0; q < lights.size(); q++)
	{
	    lights.get(q).setLight(q);
	}

    }
}
