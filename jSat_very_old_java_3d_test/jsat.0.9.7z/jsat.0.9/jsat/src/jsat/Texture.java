/**
 * @file Texture.java
 *
 * @author mjt, 2007-08
 * mixut@hotmail.com
 *
 * osia lwjgl:n demopelist�, Space Invadersista
 *
 * dds:
 * http://www.chriscohnen.de/cg/tutorials/DDStutorial/dds_tutorial.htm
 */
package jsat;

import java.util.HashMap;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.PixelGrabber;
import java.awt.image.Raster;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import javax.imageio.ImageIO;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.ARBMultitexture;
import org.lwjgl.opengl.EXTTextureCompressionS3TC;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL12.*;
import static org.lwjgl.opengl.GL13.*;

/**
 * luo opengl texturen
 */
public class Texture
{
    private static HashMap<String, Texture> textures = new HashMap<String, Texture>();

    private int textureMode = GL_TEXTURE_2D; // bindi� varten 2D tai 3D

    // texture

    private String name;

    public String getName()
    {
	return name;
    }

    private int width;

    private int height;

    private IntBuffer texture = null;

    private int pixelFormat;

    int layers = 0;

    private static ByteBuffer data = null;

    public Texture()
    {
    }

    public Texture(String fileName)
    {
	load(fileName);
    }

    static int s_transpCol = -1;

    public Texture(String fileName, int transpCol)
    {
	s_transpCol = transpCol;

	load(fileName);

	s_transpCol = -1;
    }

    public void set(IntBuffer tex, int w, int h, int format)
    {
	texture = tex;
	width = w;
	height = h;
	pixelFormat = format;
    }

    public void load(String fileName)
    {
	Texture tex = loadTexture(fileName, GL_LINEAR, GL_LINEAR);
	if (tex == null)
	{
	    return;
	}
	set(tex.texture, tex.width, tex.height, tex.pixelFormat);
	name = tex.name;
    }

    public void setTexture(IntBuffer tex)
    {
	texture = tex;
    }

    public int getTexture()
    {
	return texture.get(0);
    }

    public static void active(int tx)
    {
	if (Settings.multiTexturingSupported)
	{
	    ARBMultitexture.glActiveTextureARB((ARBMultitexture.GL_TEXTURE0_ARB + tx));
	}
    }

    /**
     * aseta texture tx textureyksikk��n
     */
    public void bind(int tx)
    {
	if (texture == null)
	{
	    return;
	}

	if (Settings.multiTexturingSupported)
	{
	    ARBMultitexture.glActiveTextureARB(ARBMultitexture.GL_TEXTURE0_ARB + tx);
	}

	glEnable(textureMode);
	glBindTexture(textureMode, texture.get(0));
    }

    /**
     * texture pois k�yt�st� tx-textureyksik�st�
     */
    public static void unbind(int tx)
    {
	if (Settings.multiTexturingSupported)
	{
	    ARBMultitexture.glActiveTextureARB(ARBMultitexture.GL_TEXTURE0_ARB + tx);
	    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	}
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_TEXTURE_3D);
    }

    public int getWidth()
    {
	return width;
    }

    public int getHeight()
    {
	return height;
    }

    void createDepthTexture(int w, int h, int minFilter, int magFilter)
    {
	width = w;
	height = h;

	texture = BufferUtils.createIntBuffer(1);
	glGenTextures(texture);
	bind(0);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, minFilter);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, magFilter);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, w, h, 0, GL_DEPTH_COMPONENT, GL_FLOAT, (ByteBuffer) null);

    }

    void createTexture(int w, int h, int minFilter, int magFilter)
    {
	createTexture(w, h, minFilter, magFilter, BaseGame.textureFormat);
    }

    void createTexture(int w, int h, int minFilter, int magFilter, int mode)
    {
	width = w;
	height = h;

	texture = BufferUtils.createIntBuffer(1);
	glGenTextures(texture);
	bind(0);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, minFilter);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, magFilter);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	glTexImage2D(GL_TEXTURE_2D, 0, mode, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
    }

    void createTexture(BufferedImage image, int minFilter, int magFilter)
    {
	if (image == null)
	    return;

	width = image.getWidth();
	height = image.getHeight();

	int neww = 2;
	int newh = 2;

	while (true)
	{
	    if (neww >= width)
	    {
		break;
	    }

	    neww *= 2;
	}

	while (true)
	{
	    if (newh >= height)
	    {
		break;
	    }

	    newh *= 2;
	}

	texture = BufferUtils.createIntBuffer(1);
	glGenTextures(texture);

	bind(0);

	if (image.getColorModel().hasAlpha())
	{
	    pixelFormat = GL_RGBA;
	} else
	{
	    pixelFormat = GL_RGB;
	}

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, minFilter);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, magFilter);

	// muuta BufferedImage byte-taulukoksi joka sy�tet��n opengl:lle
	ByteBuffer textureBuffer = convertImage(image, neww, newh);

	if (s_transpCol != -1)
	{
	    pixelFormat = GL_RGBA;
	}
	glTexImage2D(GL_TEXTURE_2D, 0, BaseGame.textureFormat, neww, newh, 0, pixelFormat, GL_UNSIGNED_BYTE, textureBuffer);
    }

    ByteBuffer convertImage(BufferedImage image, int w, int h)
    {
	int colCount = (pixelFormat == GL_RGBA) ? 4 : 3;
	ByteBuffer temptex = null;

	// jos kuvaa t�ytyy skaalata
	if ((h != image.getHeight()) || (w != image.getHeight()))
	{
	    Log.write("resize image..", Log.INFO);

	    Image i = image.getScaledInstance(w, h, Image.SCALE_SMOOTH);

	    int[] imgint = new int[w * h];

	    PixelGrabber pg = new PixelGrabber(i, 0, 0, w, h, imgint, 0, w);

	    try
	    {
		pg.grabPixels();
	    } catch (Exception e)
	    {
		e.printStackTrace();
		FileIO.Message(e.getMessage());
		return null;
	    }

	    int alloc_temp = (s_transpCol != -1 ? (w * h) : 0);
	    temptex = ByteBuffer.allocateDirect(w * h * colCount + alloc_temp);

	    // luo bufferi
	    for (int y = 0; y < h; y++)
	    {
		for (int x = 0; x < w; x++)
		{
		    int pp = (y * w) + x;
		    int pixel = imgint[pp];
		    int alpha = (pixel >> 24) & 0xff;
		    int red = (pixel >> 16) & 0xff;
		    int green = (pixel >> 8) & 0xff;
		    int blue = (pixel) & 0xff;

		    temptex.put((byte) red);
		    temptex.put((byte) green);
		    temptex.put((byte) blue);

		    if (s_transpCol != -1)
		    {
			if ((pixel & 0x00FFFFFF) == s_transpCol)
			{
			    temptex.put((byte) 0);
			} // jos sama v�ri, niin l�pin�kyv�ksi
			else
			{
			    temptex.put((byte) 255);
			}
		    } else if (colCount == 4)
		    {
			temptex.put((byte) alpha);
		    }
		}
	    }
	} else
	{
	    // ei skaalata, otetaan vain pixelit img taulukkoon
	    int[] img = null;
	    Raster r = image.getRaster();
	    img = r.getPixels(0, 0, w, h, img);

	    int width = w;
	    int height = h;

	    // luo bufferi joko alphan kanssa tai ilman
	    temptex = ByteBuffer.allocateDirect(width * height * colCount);

	    for (int y = 0; y < height; y++)
	    {
		for (int x = 0; x < width; x++)
		{
		    if (s_transpCol == -1)
		    {
			// rgb tai rgba
			for (int c = 0; c < colCount; c++)
			{
			    temptex.put((byte) img[(((y * width) + x) * colCount) + c]);
			}
		    } else
		    // s_transpCol!=-1
		    {
			// ensin rgb
			for (int c = 0; c < 3; c++)
			{
			    temptex.put((byte) img[(((y * width) + x) * colCount) + c]);
			}

			// sitten alpha. tarkista onko rgb arvo sama kuin
			// s_transpCol
			if (((img[(((y * width) + x) * colCount) + 2] << 16) & 0xFF) + // r
				((img[(((y * width) + x) * colCount) + 1] << 8) & 0xFF) + // g
				((img[(((y * width) + x) * colCount) + 2]) & 0xFF) == s_transpCol) // b
			{
			    temptex.put((byte) 0);
			} // jos sama v�ri, niin l�pin�kyv�ksi
			else
			{
			    temptex.put((byte) 255);
			}
		    }
		}
	    }
	}

	temptex.flip();

	return temptex;
    }

    public static Texture loadTexture(String textureFile)
    {
	return loadTexture(textureFile, GL_LINEAR, GL_LINEAR);
    }
    
    /**
     * lataa texture muistiin ja palauta se.
     */
    public static Texture loadTexture(String textureFile, int minFilter, int magFilter)
    {
	if (textureFile == null || textureFile.equals(""))
	{
	    return null;
	}
	// tarkista onko texture ladattu jo
	Texture tex = (Texture) textures.get(textureFile);

	if (tex != null)
	{
	    return tex; // jos ladattu, palauta se
	}

	Log.write("load texture " + textureFile, Log.INFO);

	tex = new Texture();
	tex.name = textureFile;

	try
	{
	    // koita ladata ensin pakattu texture. jos ei onnistu, antaa
	    // imageio:n koittaa ladata
	    DDSReader dds = new DDSReader();
	    if (dds.load(textureFile, tex) == false)
	    {
		BufferedImage image = ImageIO.read(new File(textureFile));
		if (image == null)
		{
		    return null;
		}

		// luo opengl texture
		tex.createTexture(image, minFilter, magFilter);
	    }
	    // pist� texture hashmappiin
	    textures.put(textureFile, tex);
	} catch (IOException e)
	{
	    FileIO.Message("Can't load " + textureFile + "\n" + e.getMessage());

	}
	return tex;
    }

    /**
     * lataa tiedostot ja luo bufferi josta luodaan 3d texture. kuvien koot ja pixelformaatit
     * pit�� olla samat. lev&kor 128, 256, 512, 1024 ..
     */
    public void load(String[] fileNames)
    {
	textureMode = GL_TEXTURE_3D;

	data = null;

	BufferedImage img = null;
	layers = fileNames.length;

	for (int q = 0; q < fileNames.length; q++)
	{
	    Log.write("load terrain image: " + fileNames[q], Log.INFO);

	    img = loadBufImage(fileNames[q]);
	    makeBuffer(img);
	}
	data.flip();

	createTexture(img.getWidth(), img.getHeight(), fileNames.length, GL_LINEAR, GL_LINEAR, GL_RGB8);

    }

    private void createTexture(int w, int h, int depth, int minFilter, int magFilter, int mode)
    {
	width = w;
	height = h;
	texture = BufferUtils.createIntBuffer(1);
	glGenTextures(texture);
	bind(0);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MIN_FILTER, minFilter);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MAG_FILTER, magFilter);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_REPEAT);
	glTexImage3D(GL_TEXTURE_3D, 0, mode, w, h, depth, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
    }

    private BufferedImage loadBufImage(String textureFile)
    {
	try
	{
	    return ImageIO.read(new File(textureFile));
	} catch (IOException e)
	{
	    FileIO.Message(e.getMessage());
	}
	return null;
    }

    private void makeBuffer(BufferedImage image)
    {
	width = image.getWidth();
	height = image.getHeight();
	if (image.getColorModel().hasAlpha())
	{
	    pixelFormat = GL_RGBA;
	} else
	{
	    pixelFormat = GL_RGB;
	}

	convertImage(image);
    }

    private void convertImage(BufferedImage image)
    {
	int colCount = (pixelFormat == GL_RGBA) ? 4 : 3;

	// ei skaalata, otetaan vain pixelit img taulukkoon
	int[] img = null;
	Raster r = image.getRaster();
	img = r.getPixels(0, 0, width, height, img);

	// luo ekalla kerralla bufferi joko alphan kanssa tai ilman, layereiden
	// verran
	if (data == null)
	{
	    data = ByteBuffer.allocateDirect(width * height * colCount * layers);
	}

	for (int y = 0; y < height; y++)
	{
	    for (int x = 0; x < width; x++)
	    {
		for (int c = 0; c < colCount; c++)
		{
		    data.put((byte) img[(((y * width) + x) * colCount) + c]);
		}
	    }
	}
    }
}

// dds lataukset ja asetukset
class DDSReader
{
    BinaryFileReader bis;

    DDSURFACEDESC2 ddsheader = new DDSURFACEDESC2();

    static final long DDSD_MIPMAPCOUNT = 0x00020000l;

    static final long DDSCAPS_COMPLEX = 0x00000008l;

    static final long DDSCAPS2_CUBEMAP = 0x00000200l;

    static final long DDSCAPS2_CUBEMAPSIDE[] = { 0x00000400L, 0x00000800L, 0x00001000L, 0x00002000L, 0x00004000L, 0x00008000L };

    /**
     * represents DDS Header
     */
    class DDSURFACEDESC2
    {
	int size;

	/** size of the DDSURFACEDESC structure */
	int flags;

	/** determines what fields are valid */
	int height;

	/** height of surface to be created */
	int width;

	/** width of input surface */
	int linearSize;

	/** formless optimized surface size */
	int depth;

	/** the depth, if volume texture */
	int mipMapCount;

	/** number of mip-map levels */
	int dwAlphaBitDepth;

	/** depth of alpha buffer */
	// DDPIXELFORMAT pixelFormat pixel format ddsheader of the surface
	int size2;

	/** size of structure */
	int flags2;

	/** pixel format flags */
	String fourCC;

	/** (FOURCC ) */
	int rgbBitCount;

	/** how many bits per pixel */
	int rBitMask;

	/** mask for red bit */
	int gBitMask;

	/** mask for green bits */
	int bBitMask;

	/** mask for blue bits */
	int rgbAlphaBitMask;

	/** mask for alpha channel */
	// DDPIXELFORMAT pixelFormat end
	// DDSCAPS2 ddsCaps direct draw surface capabilities
	int caps1;

	int caps2;

	int caps3;

	int caps4; /* dwVolumeDepth */

	// DDSCAPS2 end
	int dwTextureStage; // stage in multitexture cascade

	public void read()
	{
	    size = bis.readInt();
	    flags = bis.readInt();
	    height = bis.readInt();
	    width = bis.readInt();
	    linearSize = bis.readInt();
	    depth = bis.readInt();
	    mipMapCount = bis.readInt();
	    dwAlphaBitDepth = bis.readInt();

	    // skip until DDPixelformat
	    bis.setIndex(bis.getIndex() + 40);

	    // DDPIXELFORMAT 2
	    size2 = bis.readInt();
	    flags2 = bis.readInt();
	    fourCC = bis.readString(4);
	    rgbBitCount = bis.readInt();
	    rBitMask = bis.readInt();
	    gBitMask = bis.readInt();
	    bBitMask = bis.readInt();
	    rgbAlphaBitMask = bis.readInt();
	    // DDCAPS2
	    caps1 = bis.readInt();
	    caps2 = bis.readInt();
	    caps3 = bis.readInt();
	    caps4 = bis.readInt();
	    // DDCAPS2 end
	    dwTextureStage = bis.readInt();
	}
    }

    /**
     * lataa ja luo dds texture tex:iin. jos jokin menee vikaan, palauttaa
     * false
     */
    public boolean load(String filename, Texture tex)
    {
	bis = new BinaryFileReader(filename);
	if ((bis != null) && (bis.isReadOK()))
	{
	    String filetype = bis.readString(4);
	    if (!"DDS ".equals(filetype))
	    {
		return false;
	    }

	    ddsheader.read();
	    if (ddsheader.size != 124 || ddsheader.size2 != 32)
	    {
		Log.write(" * not dds format", Log.ERROR);
		return false;
	    }

	    // vaatii v�h 1.3 compressed textureihin
	    if (Settings.GL10_11_12)
	    {
		FileIO.Message("Uses compressed textures. Min req: OpenGL 1.3!");
		return false;
	    }

	    // seek to texture data, pos=filetype+ddsheader
	    bis.setIndex(ddsheader.size + 4);

	    int format = 0;

	    if ("DXT1".equals(ddsheader.fourCC))
	    {
		format = EXTTextureCompressionS3TC.GL_COMPRESSED_RGB_S3TC_DXT1_EXT;
		Log.write("(dxt1)", Log.INFO);
	    } else if ("DXT3".equals(ddsheader.fourCC))
	    {
		format = EXTTextureCompressionS3TC.GL_COMPRESSED_RGBA_S3TC_DXT3_EXT;
		Log.write("(dxt3)", Log.INFO);
	    } else if ("DXT4".equals(ddsheader.fourCC))
	    {
		Log.write(" * dxt4 not supported", Log.ERROR);
		return false;
	    } else if ("DXT5".equals(ddsheader.fourCC))
	    {
		format = EXTTextureCompressionS3TC.GL_COMPRESSED_RGBA_S3TC_DXT5_EXT;
		Log.write("(dxt5)", Log.INFO);
	    } else
	    {
		Log.write(" * unknown format", Log.ERROR);
		return false;
	    }

	    if (ddsheader.depth == 0)
	    {
		ddsheader.depth = 1;
	    }

	    int blocksize = 16;
	    if (format == EXTTextureCompressionS3TC.GL_COMPRESSED_RGB_S3TC_DXT1_EXT)
	    {
		blocksize = 8;
	    }
	    int size = ((ddsheader.width + 3) / 4) * ((ddsheader.height + 3) / 4) * ((ddsheader.depth + 3) / 4) * blocksize;

	    if (((ddsheader.flags & DDSD_MIPMAPCOUNT) == 0) || ddsheader.mipMapCount == 0)
	    {
		ddsheader.mipMapCount = 1;
	    }

	    load2DTexture(size, format, blocksize, tex);

	} else
	{
	    return false;
	}

	return true;
    }

    /**
     * load 2D surface and mip levels at current BinaryFileReader index
     */
    private void load2DTexture(int size, int format, int blocksize, Texture tex)
    {
	IntBuffer buf = BufferUtils.createIntBuffer(1);
	glGenTextures(buf); // Create Texture In OpenGL
	glBindTexture(GL_TEXTURE_2D, buf.get(0));

	// load level 0
	ByteBuffer pixBuf = BufferUtils.createByteBuffer(size);
	pixBuf.put(bis.contents, bis.getIndex(), size);
	bis.setIndex(bis.getIndex() + size);
	pixBuf.rewind();

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	glCompressedTexImage2D(GL_TEXTURE_2D, 0, format, ddsheader.width, ddsheader.height, 0, pixBuf);
	tex.set(buf, ddsheader.width, ddsheader.height, format);

	// set mipmap Filtering and load all levels
	if (ddsheader.mipMapCount > 1)
	{
	    int width = ddsheader.width;
	    int height = ddsheader.height;
	    for (int i = 1; i < ddsheader.mipMapCount; i++)
	    {
		width >>= 1;
		height >>= 1;
		if (width == 0)
		{
		    width = 1;
		}
		if (height == 0)
		{
		    height = 1;
		}
		size = ((width + 3) / 4) * ((height + 3) / 4) * ((ddsheader.depth + 3) / 4) * blocksize;
		pixBuf.put(bis.contents, bis.getIndex(), size);
		bis.setIndex(bis.getIndex() + size);
		pixBuf.rewind();
		glCompressedTexImage2D(GL_TEXTURE_2D, i, format, width, height, 0, pixBuf);
	    }
	}
    }
}
