/**
 * @file Project.java
 *
 * @author mjt, 2007
 * mixut@hotmail.com
 *
 */
/* tutorials:
 * http://www.paulsprojects.net/tutorials/smt/smt.html
 * http://www.steps3d.narod.ru/tutorials/shadow-maps-tutorial.html
 * http://www.evl.uic.edu/rlk/cs594/final/part3.html
 */
package jsat;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.util.glu.GLU;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL12.*;

public class Project extends ObjectInfo
{
    Texture texture = null; // valo/mik� vain texture

    protected static FloatBuffer lightViewMatrix = BufferUtils.createFloatBuffer(16);

    protected static FloatBuffer lightProjectionMatrix = BufferUtils.createFloatBuffer(16);

    static FloatBuffer row = BufferUtils.createFloatBuffer(4);

    static IntBuffer tmpbuf = BufferUtils.createIntBuffer(16);

    public Project()
    {
	super("project");
	setType(PROJ);
    }

    /**
     * lataa texturen
     */
    public Project(String textureFileName)
    {
	super(textureFileName);
	setType(PROJ);

	load(textureFileName);
    }

    public void load(String textureFileName)
    {
	name = textureFileName;

	texture = new Texture(Settings.TEXTUREDIR + textureFileName);
	texture.bind(0);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    }

    public void calcProjection(boolean renderScene)
    {
	lightViewMatrix.clear();
	lightProjectionMatrix.clear();

	// kuvakulma valosta katsottuna
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	GLU.gluPerspective(120, 1, 1, 100);
	GLU.gluLookAt(getWorldSpacePosition().x, getWorldSpacePosition().y, getWorldSpacePosition().z, // eye
		getView().x, getView().y, getView().z, 0, 1, 0); // up
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	glGetFloat(GL_MODELVIEW_MATRIX, lightViewMatrix);
	glGetFloat(GL_PROJECTION_MATRIX, lightProjectionMatrix);

	if (renderScene) // k�ytet��n shadow mappingissa
	{
	    tmpbuf.clear();
	    BaseGame.screen.bindDepth();
	    BaseGame.screen.setViewport();

	    // rendataan scene valosta p�in katsottuna, ei textureita
	    Frustum.calculateFrustum();
	    BaseGame.renderTextures(false);
	    BaseGame.world.render();
	    BaseGame.renderTextures(true);

	    // nappaa zbuffer talteen ellei fbo k�yt�ss� jolloin rendataan
	    // suoraan depthTextureen
	    BaseGame.screen.copyDepth();

	    BaseGame.screen.restoreViewport();
	    Screen.unbind();
	}

	// kuvakulma takaisin kameraan
	glPopMatrix();
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();

	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glTranslatef(0.5f, 0.5f, 0.5f); // remap from [-1,1]^2 to [0,1]^2
	glScalef(0.5f, 0.5f, 0.5f);

	glMultMatrix(lightProjectionMatrix);
	glMultMatrix(lightViewMatrix);

	glMatrixMode(GL_MODELVIEW);
    }

    /**
     * aseta valon n�kym� texture1 kun objektien texturet on texture0:ssa.
     * 
     */
    public void projectMap(Colorf col)
    {
	if (Settings.multiTexturingSupported == false)
	{
	    return;
	}

	Texture.active(1);
	glColor4f(col.r, col.g, col.b, col.a);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_TEXTURE_GEN_S);
	glEnable(GL_TEXTURE_GEN_T);
	glEnable(GL_TEXTURE_GEN_R);
	glEnable(GL_TEXTURE_GEN_Q);

	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
	glTexGeni(GL_R, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
	glTexGeni(GL_Q, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);

	row.put(new float[] { 1, 0, 0, 0 });
	row.flip();
	glTexGen(GL_S, GL_EYE_PLANE, row);

	row.put(new float[] { 0, 1, 0, 0 });
	row.flip();
	glTexGen(GL_T, GL_EYE_PLANE, row);

	row.put(new float[] { 0, 0, 1, 0 });
	row.flip();
	glTexGen(GL_R, GL_EYE_PLANE, row);

	row.put(new float[] { 0, 0, 0, 1 });
	row.flip();
	glTexGen(GL_Q, GL_EYE_PLANE, row);

	if (texture != null)
	{
	    texture.bind(1);
	}
	calcProjection(false);

	Texture.active(0);
	BaseGame.world.render();
	Texture.unbind(1);

	Texture.active(1);
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	glDisable(GL_TEXTURE_GEN_R);
	glDisable(GL_TEXTURE_GEN_Q);
	glDisable(GL_TEXTURE_2D);

	Texture.active(0);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	glColor4f(1, 1, 1, 1);
    }

    public void render(Colorf col)
    {
	glDepthFunc(GL_EQUAL);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	Geometry.projectTexture = true;
	Frustum.calculateFrustum();
	projectMap(col);
	Geometry.projectTexture = false;

	glDisable(GL_BLEND);
	glDepthFunc(GL_LEQUAL);
    }
}
