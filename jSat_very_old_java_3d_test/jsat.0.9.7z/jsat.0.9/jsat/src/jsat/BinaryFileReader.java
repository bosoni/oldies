/**
 * @file BinaryFileReader.java
 *
 */
// original: http://www.chriscohnen.de/cg/tutorials/DDStutorial/dds_tutorial.htm
package jsat;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Tiny BinaryFileReader for loading binary file into memory buffer.<br>
 * file content can be accessed via different data functions working with a
 * virtual file pointer (index)<br>
 * <b>usage:</b><br>
 * BinaryFileReader bis=BinaryFileReader("test.bin"); <br>
 * if (bis.isReadOK) {<br>
 * while(bis.hasMoreBytes())<br> {<br>
 * byte b=bis.readByte();<br> }<br> }<br>
 */
public class BinaryFileReader
{
    public byte[] contents = null;

    private int index = 0;

    private boolean readOK = false;

    /**
     * @param filename
     */
    public BinaryFileReader(String filename)
    {
	try
	{
	    URL file = new File(filename).toURI().toURL();
	    open(file);
	} catch (MalformedURLException e)
	{
	    FileIO.ErrorMessage("BFR could not open: " + filename);
	}
    }

    /**
     * use to check after cretare bfr if open ok
     * 
     * @return true if file was correctly loaded
     */
    public boolean isReadOK()
    {
	return readOK;
    }

    /**
     * open file and read file content into memory
     * 
     * @param fileurl
     *                the fileurl pointing to the file to be read.
     */
    public void open(URL fileurl)
    {
	try
	{
	    InputStream is = fileurl.openStream();
	    // use buffer for fast reading
	    DataInputStream bis = new DataInputStream(is);
	    contents = new byte[bis.available()];
	    // read file into contents buffer
	    bis.readFully(contents);
	    bis.close();
	    readOK = true;
	} catch (IOException ioe)
	{
	    FileIO.ErrorMessage("could not read: " + fileurl);
	}
    }

    /**
     * read byte at current index
     * 
     * @return byte at current index.
     */
    public int readByte()
    {
	int b1 = (contents[index] & 0xFF);
	index += 1;
	return (b1);
    }

    /**
     * read array of byte at current index
     * 
     * @param bytearray
     *                to fill
     */
    public void readByteArray(byte[] bytearray)
    {
	System.arraycopy(contents, index, bytearray, 0, bytearray.length);
	index += bytearray.length;
    }

    /**
     * read array of char at current index
     * 
     * @param chararray
     */
    public void readCharArray(char[] chararray)
    {
	for (int i = 0; i < chararray.length; i++)
	{
	    chararray[i] = (char) contents[index + i];
	}
	index += chararray.length;
    }

    /**
     * read short (16 bit) at current index
     * 
     * @return short at current index
     */
    public int readShort()
    {
	int s1 = (contents[index] & 0xFF);
	int s2 = (contents[index + 1] & 0xFF) << 8;
	index += 2;
	return (s1 | s2);
    }

    /**
     * read signed short (16 bit) at current index
     * 
     * @return
     */
    public int readSignedShort()
    {
	int s1 = (contents[index] & 0xFF);
	int s2 = (contents[index + 1] & 0xFF) << 8;
	index += 2;
	int val = (s1 | s2);
	if (val > 127 * 256)
	{
	    return (-256 * 256) + val;
	}
	return val;
    }

    /**
     * read 32 bit int at current index
     * 
     * @return int at currrent index
     */
    public int readInt()
    {
	int i1 = (contents[index++] & 0xFF);
	int i2 = (contents[index++] & 0xFF) << 8;
	int i3 = (contents[index++] & 0xFF) << 16;
	int i4 = (contents[index++] & 0xFF) << 24;
	return (i1 | i2 | i3 | i4);
    }

    /**
     * read array of int at current index
     * 
     * @param intarray
     */
    public void readIntArray(int[] intarray)
    {
	for (int i = 0; i < intarray.length; i++)
	{
	    int i1 = ((char) contents[index] & 0xFF);
	    int i2 = ((char) contents[index + 1] & 0xFF) << 8;
	    int i3 = ((char) contents[index + 2] & 0xFF) << 16;
	    int i4 = ((char) contents[index + 3] & 0xFF) << 24;
	    index += 4;
	    intarray[i] = (i1 | i2 | i3 | i4);
	}
    }

    /**
     * read float at current index
     * 
     * @return float at the current index
     */
    public float readFloat()
    {
	return Float.intBitsToFloat(readInt());
    }

    /**
     * read String of given length at current index
     * 
     * @param length
     *                of the string to read.
     * @return the string read
     */
    public String readString(int length)
    {
	// if content contains 0 byte termination
	// return string upto this position
	for (int i = index; i < index + length; i++)
	{
	    if (contents[i] == (byte) 0)
	    {
		// return string upto "0 byte" terminator
		String s = new String(contents, index, i - index);
		index += length;
		return s;
	    }
	}
	// return full length string
	String s = new String(contents, index, length);
	index += length;
	return s;
    }

    /**
     * hasMoreBytes
     * 
     * @return false if index is at end of file
     */
    public boolean hasMoreBytes()
    {
	if (index < contents.length)
	{
	    return true;
	}
	return false;
    }

    /**
     * set index into file data to given offset
     * 
     * @param offset
     *                the new index for the file pointer
     */
    public void setIndex(int offset)
    {
	if (offset < 0 || offset > contents.length)
	{
	    Log.write("invalid offset value. " + offset, Log.INFO);
	}
	index = offset;
    }

    /**
     * @return current index
     */
    public int getIndex()
    {
	return index;
    }

    /**
     * @return size of content
     */
    public int getSize()
    {
	return contents.length;
    }
}
