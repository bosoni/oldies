/**
 * @file Terrain.java
 *
 * @author mjt, 2007
 * mixut@hotmail.com
 *
 * Lataa ja renderoi maaston.
 *
 * aikast surkea.
 *
 * huom. maastolle ei ole laskettu normaaleja.
 */
package jsat;

import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.io.File;
import java.awt.image.Raster;
import org.lwjgl.opengl.ARBMultitexture;
import org.lwjgl.util.vector.Vector3f;
import static org.lwjgl.opengl.GL11.*;
import org.lwjgl.util.vector.Vector2f;

public class Terrain extends ObjectInfo
{
    private Texture[] texture = null;

    private GLSL textureBlend = null;

    private static byte[][] lods = new byte[500][500];

    private int mapWidth = 0, mapHeight = 0;

    private int[] mapImg = null;

    private int[] mapImg_2 = null;

    // montako pixeli� alueeseen kuuluu x ja y suunnassa (eli
    // kokonaispolym��r� on AREA_SIZE*AREA_SIZE)
    private int AREA_SIZE = 16;

    private float MAP_XZ_MUL = 2;

    private float MAP_Y_MUL = 0.4f;

    private float scaleUV = 0.05f;

    private int DIST = 20;

    public void setupTerrain(int areasize, float xz, float y, float uv, int dist)
    {
	AREA_SIZE = areasize;
	MAP_XZ_MUL = xz;
	MAP_Y_MUL = y;
	scaleUV = uv;
	DIST = dist;
    }

    private int polyCount = 0;

    public int getPolyCount()
    {
	return polyCount;
    }

    public Terrain(String name)
    {
	super(name);
    }

    public void loadShader(String vert, String frag)
    {
	if (Settings.GLSLSupported)
	{
	    textureBlend = new GLSL();
	    if (textureBlend.loadPrograms(vert, frag) == false)
	    {
		textureBlend = null;
		return;
	    }
	    textureBlend.bind();
	    textureBlend.setUniform("tex1", null, new int[] { 0 });
	    textureBlend.setUniform("tex2", null, new int[] { 1 });
	    textureBlend.setUniform("tex3", null, new int[] { 2 });
	    textureBlend.setUniform("tex4", null, new int[] { 3 });
	    textureBlend.setUniform("muly", new float[] { 1 / MAP_Y_MUL }, null);

	    textureBlend.setUniform("yfog", new float[] { 0.007f, 0.007f, 0.007f }, null);
	    textureBlend.setUniform("zfog", new float[] { 0.002f, 0.002f, 0.002f }, null);

	    GLSL.unbind(); // textureBlend
	}

    }

    /**
     * lataa fileName korkeuskartta, k�yt� texNamex tekstureita siihen.
     * file2 korkeuskartta m��r�� mit� teksturea milloinkin k�ytet��n.
     */
    public void load(String fileName, String file2, String[] texNames) throws IOException
    {
	load(fileName, texNames);

	// lataa file2 joka m��r�� mit� texturea miss�kin kohtaa k�ytet��n
	BufferedImage image = ImageIO.read(new File(Settings.TEXTUREDIR + file2));

	Raster r = image.getRaster();
	mapImg_2 = r.getPixels(0, 0, image.getWidth(), image.getHeight(), mapImg_2);

    }

    /**
     * lataa fileName korkeuskartta, k�yt� texNamex tekstureita siihen
     */
    public void load(String fileName, String[] texNames) throws IOException
    {

	// lis�� hakemisto nimiin
	for (int q = 0; q < texNames.length; q++)
	{
	    texNames[q] = Settings.TEXTUREDIR + texNames[q];
	}

	if (Settings.texture3DSupported)
	{
	    // lataa maaston texture
	    texture = new Texture[1];
	    texture[0] = new Texture();
	    texture[0].load(texNames); // lataa monta texturea, eli luo 3d
	    // texturen
	} else if (Settings.GLSLSupported)
	{
	    // jos 3d-texturet k�yt�ss�, n�it� ei ladata
	    if (texNames.length == 2 || Settings.GL10_11_12)
	    {
		loadShader("terrain.vert", "terrain_2.frag"); // 2 texturea
		// (ei k�ytet�
		// if-k�sky�
		// glsl
		// koodissa)
	    } else
	    {
		loadShader("terrain.vert", "terrain.frag"); // blendataan 3
		// texturea (if
		// glsl
		// koodissa)
	    }

	    texture = new Texture[texNames.length]; // lataa texturet
	    // erikseen (ei
	    // 3d-texture)
	    for (int q = 0; q < texNames.length; q++)
	    {
		texture[q] = new Texture(texNames[q]);
	    }
	} else
	{
	    texture = new Texture[1];
	    texture[0] = new Texture(texNames[0]); // 1 texture vanhoille
	    // korteille.. :/
	}

	// lataa maasto
	BufferedImage image = ImageIO.read(new File(Settings.TEXTUREDIR + fileName));

	Raster r = image.getRaster();
	mapImg = r.getPixels(0, 0, image.getWidth(), image.getHeight(), mapImg);

	mapWidth = image.getWidth();
	mapHeight = image.getHeight();
    }

    // ota korkeustieto kartasta
    private float mapGetHeight(int x, int y)
    {
	x %= mapWidth;
	y %= mapHeight;
	return (float) mapImg[y * mapWidth + x] - 128;
    }

    private float mapTexInfo(int x, int y)
    {
	x %= mapWidth;
	y %= mapHeight;
	return (float) mapImg_2[y * mapWidth + x] - 128;
    }

    private void setUVR(float u, float v, float r)
    {
	r += 128;
	if (Settings.texture3DSupported)
	{
	    r /= 255.0f; // 0-1.0
	    glTexCoord3f(u, v, r);
	} else if (Settings.multiTexturingSupported)
	{
	    for (int q = 0; q < texture.length; q++)
	    {
		ARBMultitexture.glMultiTexCoord3fARB(ARBMultitexture.GL_TEXTURE0_ARB + q, u, v, r);
	    }
	} else
	// vanhoille korteille
	{
	    glTexCoord2f(u, v);
	}
    }

    private void renderFans(float x, float z, int size, int px, int py, int lx, int ly, int xx, int zz, int max)
    {
	glBegin(GL_TRIANGLE_FAN);

	// keskikohta:
	float height = mapGetHeight(px + size / 2, py + size / 2);
	setUVR(scaleUV * (px + size / 2), scaleUV * (py + size / 2), mapTexInfo(px + size / 2, py + size / 2));
	height *= MAP_Y_MUL;
	glVertex3f(x + (size / 2) * MAP_XZ_MUL, height, z + (size / 2) * MAP_XZ_MUL);
	// ------------

	height = mapGetHeight(px, py);
	setUVR(scaleUV * (px), scaleUV * (py), mapTexInfo(px, py));
	height *= MAP_Y_MUL;
	glVertex3f(x, height, z);

	if (xx == 0)
	{
	    if (lx > 0)
	    {
		if (lods[ly][lx] < lods[ly][lx - 1]) // jos t�ss� v�hemm�n
		// polyja kun
		// edellisessa, pit��
		// tehd� jako...
		{
		    height = mapGetHeight(px, py + size / 2);
		    setUVR(scaleUV * (px), scaleUV * (py + size / 2), mapTexInfo(px, py + size / 2));
		    height *= MAP_Y_MUL;
		    glVertex3f(x, height, z + (size / 2) * MAP_XZ_MUL);
		}
	    }
	}

	height = mapGetHeight(px, py + size);
	setUVR(scaleUV * (px), scaleUV * (py + size), mapTexInfo(px, py + size));
	height *= MAP_Y_MUL;
	glVertex3f(x, height, z + size * MAP_XZ_MUL);

	if (zz == max - 1)
	// if(ly<max)
	{
	    if (lods[ly][lx] < lods[ly + 1][lx]) // jos t�ss� v�hemm�n
	    // polyja kuin
	    // alapuolella..
	    {
		height = mapGetHeight(px + size / 2, py + size);
		setUVR(scaleUV * (px + size / 2), scaleUV * (py + size), mapTexInfo(px + size / 2, py + size));
		height *= MAP_Y_MUL;
		glVertex3f(x + (size / 2) * MAP_XZ_MUL, height, z + size * MAP_XZ_MUL);
	    }
	}

	height = mapGetHeight(px + size, py + size);
	setUVR(scaleUV * (px + size), scaleUV * (py + size), mapTexInfo(px + size, py + size));
	height *= MAP_Y_MUL;
	glVertex3f(x + size * MAP_XZ_MUL, height, z + size * MAP_XZ_MUL);

	if (xx == max - 1)
	// if(lx<max)
	{
	    if (lods[ly][lx] < lods[ly][lx + 1]) // jos t�ss� v�hemm�n
	    // polyja kun
	    // seuraavassa..
	    {
		height = mapGetHeight(px + size, py + size / 2);
		setUVR(scaleUV * (px + size), scaleUV * (py + size / 2), mapTexInfo(px + size, py + size / 2));
		height *= MAP_Y_MUL;
		glVertex3f(x + size * MAP_XZ_MUL, height, z + (size / 2) * MAP_XZ_MUL);
	    }
	}

	height = mapGetHeight(px + size, py);
	setUVR(scaleUV * (px + size), scaleUV * (py), mapTexInfo(px + size, py));
	height *= MAP_Y_MUL;
	glVertex3f(x + size * MAP_XZ_MUL, height, z);

	if (zz == 0)
	{
	    if (ly > 0)
	    {
		if (lods[ly][lx] < lods[ly - 1][lx]) // jos t�ss� v�hemm�n
		// polyja ku yl�puolella
		{
		    height = mapGetHeight(px + size / 2, py);
		    setUVR(scaleUV * (px + size / 2), scaleUV * (py), mapTexInfo(px + size / 2, py));
		    height *= MAP_Y_MUL;
		    glVertex3f(x + (size / 2) * MAP_XZ_MUL, height, z);
		}
	    }
	}

	height = mapGetHeight(px, py);
	setUVR(scaleUV * (px), scaleUV * (py), mapTexInfo(px, py));
	height *= MAP_Y_MUL;
	glVertex3f(x, height, z);

	glEnd();

	polyCount += 4;

    }

    private void mapRenderArea(int px, int py)
    {
	byte lod = lods[py][px];

	float x = px * AREA_SIZE * MAP_XZ_MUL;
	float z = py * AREA_SIZE * MAP_XZ_MUL;
	int lx = px, ly = py;
	px *= AREA_SIZE;
	py *= AREA_SIZE;

	int a, b;
	int c = lod;
	int s = AREA_SIZE / c;

	for (a = 0; a < c; a++)
	{
	    for (b = 0; b < c; b++)
	    {

		if (Settings.DEBUG)
		{
		    // --DEBUG n�kee eri v�reill� eri lod alueet
		    glColor4f((byte) (lods[ly][lx] * 16), (byte) (lods[ly][lx] * 8), (byte) (lods[ly][lx] * 4), 1);
		}// ----

		// wtf.. hs
		renderFans(x + (b * s * MAP_XZ_MUL), z + (a * s * MAP_XZ_MUL), s, px + (b * s), py + (a * s), lx, ly, b, a, c);
	    }
	}
    }

    private void setLOD(int x, int y, float dist)
    {
	if (dist < DIST)
	{
	    lods[y][x] = 16;
	} else if (dist < DIST * 3)
	{
	    lods[y][x] = 8;
	} else if (dist < DIST * 5)
	{
	    lods[y][x] = 4;
	} else if (dist < DIST * 7)
	{
	    lods[y][x] = 2;
	} else
	{
	    lods[y][x] = 1;
	}
    }

    public void render()
    {
	if (mapImg_2 == null)
	{
	    mapImg_2 = mapImg;
	}
	if (textureBlend != null)
	{
	    textureBlend.bind();
	}

	polyCount = 0;

	// texture/texturet k�ytt��n
	for (int q = 0; q < texture.length; q++)
	{
	    texture[q].bind(q);
	}
	Texture.active(0);

	// alueiden lukum��r�
	int areanum = mapWidth / AREA_SIZE;

	float tmp_half = (AREA_SIZE / 2) * MAP_XZ_MUL;

	// alueiden keskikohdat
	float areacentx = tmp_half;
	float areacentz = tmp_half;

	Frustum.calculateFrustum();

	float size = tmp_half;
	;
	if (size < 255 * MAP_Y_MUL)
	{
	    size = 255 * MAP_Y_MUL;
	}

	int x, y;
	// ensin t�ytet��n lods taulukko.
	for (y = 0; y < areanum; y++)
	{
	    for (x = 0; x < areanum; x++)
	    {
		// tsekataan jos alue ei ole ruudulla
		if (Frustum.cubeInFrustum(areacentx, 0, areacentz, size) == 0)
		{
		    lods[y][x] = -1;
		} else
		{
		    // on ruudulla, laske matka
		    Vector3f tmpv = new Vector3f(areacentx, 0, areacentz);
		    Vector3f v = new Vector3f();
		    Vector3f.sub(BaseGame.camera.getWorldSpacePosition(), tmpv, v);
		    float dist = v.length();

		    setLOD(x, y, dist);

		}

		areacentx += AREA_SIZE * MAP_XZ_MUL;
	    }
	    areacentz += AREA_SIZE * MAP_XZ_MUL;
	    areacentx = tmp_half;
	}

	for (y = 0; y < areanum; y++)
	{
	    for (x = 0; x < areanum; x++)
	    {
		if (lods[y][x] == -1) // alue ei ole ruudulla
		{
		    continue;
		}

		mapRenderArea(x, y);
	    }
	}

	for (int q = 0; q < texture.length; q++)
	{
	    Texture.unbind(q);
	}

	Texture.active(0);
	GLSL.unbind();

    }

    /**
     * aseta kameran y maaston p��lle dist korkeuteen
     */
    public void cameraOnGround(float dist)
    {
	BaseGame.camera.getWorldSpacePosition().y = dist + getY(BaseGame.camera.getWorldSpacePosition());
    }

    /**
     * palauta pos kohdasta korkeus
     */
    public float getY(Vector3f pos)
    {
	int x = (int) (pos.x / MAP_XZ_MUL);
	int z = (int) (pos.z / MAP_XZ_MUL);

	if (x < 0)
	{
	    x = -x;
	}
	if (z < 0)
	{
	    z = -z;
	}

	float height;
	float v1, v2, v3;
	float xf, zf;

	v1 = mapGetHeight(x, z);
	v2 = mapGetHeight(x + 1, z);
	v3 = mapGetHeight(x, z + 1);

	xf = (pos.x - x * MAP_XZ_MUL) / MAP_XZ_MUL;
	zf = (pos.z - z * MAP_XZ_MUL) / MAP_XZ_MUL;

	height = v1 + xf * (v2 - v1) + zf * (v3 - v1);
	return height * MAP_Y_MUL;
    }

    public Vector2f getSize()
    {
	return new Vector2f(mapWidth * MAP_XZ_MUL, mapHeight * MAP_XZ_MUL);
    }
}
