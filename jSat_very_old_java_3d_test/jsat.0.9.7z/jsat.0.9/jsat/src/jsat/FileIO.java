/**
 * @file FileIO.java
 * @author mjt, 2007
 * mixut@hotmail.com
 *
 * tiedostonk�sittely luokka.
 *
 */
package jsat;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.PrintWriter;
import javax.swing.*;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public class FileIO
{
    File file;

    /**
     * avaa tiedosto
     * 
     * @param fileName
     * @return
     */
    public boolean openFile(String fileName)
    {
	file = new File(fileName);
	if (file == null)
	{
	    return false;
	}
	return true;
    }

    /**
     * luo uusi tiedosto. jos jo olemassa, kysyy ett� kirjoitetaanko p��lle
     * 
     * @param fileName
     * @return
     */
    public boolean createFile(String fileName)
    {
	file = new File(fileName);

	// jos tiedosto olemassa
	if (file.exists())
	{
	    int response = JOptionPane.showConfirmDialog(null, "Korvataanko tiedosto?", "Samanniminen tiedosto l�ytyi", JOptionPane.OK_CANCEL_OPTION,
		    JOptionPane.QUESTION_MESSAGE);
	    if (response == JOptionPane.CANCEL_OPTION)
	    {
		return false;
	    }

	    // poista vanha
	    file.delete();
	}

	return true;
    }

    /**
     * lue koko tiedosto Stringiin joka palautetaan
     * 
     * @return true jos onnistui, muuten false
     */
    public String readFile()
    {
	StringBuffer fileBuffer;
	String fileString = null;
	String line;

	try
	{
	    FileReader in = new FileReader(file);
	    if (in == null)
	    {
		return null;
	    }
	    BufferedReader dis = new BufferedReader(in);
	    fileBuffer = new StringBuffer();

	    while ((line = dis.readLine()) != null)
	    {
		fileBuffer.append(line + "\n");
	    }

	    in.close();
	    fileString = fileBuffer.toString();

	} catch (IOException e)
	{
	    ErrorMessage("readFile(): " + e.getMessage());
	    return null;
	}
	return fileString;
    }

    /**
     * kirjoita dataString tiedostoon
     * 
     * @param dataString
     *                kirjoitettava teksti
     * @return true,jos onnistui. muuten false
     */
    public boolean writeFile(String dataString)
    {
	try
	{
	    PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(file)));
	    out.print(dataString);
	    out.flush();
	    out.close();
	} catch (IOException e)
	{
	    Message(e.getMessage());
	    return false;
	}
	return true;
    }

    public String openAndReadFile(String fileName)
    {
	String fileString = "";

	try
	{
	    // tarkista onko tiedosto olemassa
	    file = new File(fileName);
	    if (file.exists())
	    {
		return readFile();

	    } else
	    // etsi paketista
	    {
		InputStream in = this.getClass().getResourceAsStream(fileName);
		if (in == null)
		{
		    return null;
		}
		int c;
		while ((c = in.read()) != -1)
		{
		    if (c == '\r')
		    {
			continue;
		    }
		    fileString += (char) c;
		}
	    }

	} catch (IOException e)
	{
	    ErrorMessage("openAndReadFile(" + file + "): " + e.getMessage());
	    return null;
	}
	return fileString;
    }

    public static void ErrorMessage(String msg)
    {
	if (msg == null || msg.equals(""))
	{
	    Log.write("ErrorMessage(null);");
	    Log.closeFile();
	    System.exit(0);
	}
	Log.write("Error: " + msg);
	javax.swing.JOptionPane.showMessageDialog(null, msg, "Error", JOptionPane.ERROR_MESSAGE);
	Log.closeFile();
	System.exit(0);
    }

    public static void Message(String msg)
    {
	if (msg == null)
	{
	    return;
	}
	if (msg.equals(""))
	{
	    return;
	}
	Log.write(msg);
	javax.swing.JOptionPane.showMessageDialog(null, msg, "Info", JOptionPane.INFORMATION_MESSAGE);
    }
}
