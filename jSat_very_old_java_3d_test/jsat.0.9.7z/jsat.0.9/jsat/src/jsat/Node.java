/**
 * @file Node.java
 *
 * @author mjt, 2007-08
 * mixut@hotmail.com
 *
 * Node world; voit lis�t� worldiin objekteja, valoja, kaikkea mitk� on
 * periytetty ObjectInfo luokasta.
 *
 * render() metodi sitten kutsuu oikean luokan renderi�.
 *
 *
 * spline:
 * http://www.robthebloke.org/opengl_programming.html
 *
 */
package jsat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Vector;
import org.lwjgl.util.glu.GLU;
import org.lwjgl.util.vector.Vector3f;
import static org.lwjgl.opengl.GL11.*;

public class Node extends ObjectInfo
{
    /**
     * Vektori objekteille, md5 animaatioille
     */
    protected Vector<Node> nodes = new Vector<Node>();

    public Node(String name)
    {
	super(name);
    }

    /**
     * Etsii objektin ObjectInfo nimen perusteella ja palautaa sen Noden
     */
    public Node searchByName(String str)
    {
	// etsi str niminen obu
	for (int q = 0; q < nodes.size(); q++)
	{
	    if (nodes.get(q).name.equals(str) == true)
	    {
		// Log.write(str+" found");
		return nodes.get(q);
	    }

	    Node nd = nodes.get(q).searchByName(str);
	    if (nd != null)
	    {
		return nd;
	    }
	}

	// Log.write(str+" not found!");
	return null;
    }

    /**
     * Lis�� objekti vektoriin
     */
    public void add(Node node)
    {
	if (node == null)
	{
	    Log.write("add(node) node==null", Log.INFO);
	    return;
	}

	// billboardit eri vektoriin
	if (node.getType() == ObjectInfo.BILLBOARD)
	{
	    BillBoard.billboards.add((BillBoard) node);
	} else
	{
	    nodes.add(node);
	}

	// Log.write(node.name + " added to "+name, Log.INFO);

	// valot my�s valovektoriin
	if (node.getType() == ObjectInfo.LIGHT)
	{
	    node.setWorldSpacePosition(getPosition());
	    Light.lights.add((Light) node);
	} else if (node.getType() == ObjectInfo.CAMERA)
	{
	    node.setWorldSpacePosition(getPosition());
	}

    }

    /**
     * poista name niminen objekti.
     */
    public boolean remove(String name)
    {
	for (int q = 0; q < nodes.size(); q++)
	{
	    if (nodes.get(q).name.equals(name) == true)
	    {
		// jos valo, poista se my�s valovektorista
		if (nodes.get(q).getType() == ObjectInfo.LIGHT)
		{
		    for (int w = 0; w < Light.lights.size(); w++)
		    {
			if (Light.lights.get(w).name.equals(name)
				&& // sama nimi ja paikka, luultavasti sama
				// valo
				Light.lights.get(w).getPosition().x == nodes.get(q).getPosition().x
				&& Light.lights.get(w).getPosition().y == nodes.get(q).getPosition().y
				&& Light.lights.get(w).getPosition().z == nodes.get(q).getPosition().z)
			{
			    Light.lights.remove(w); // poista
			    break;
			}
		    }
		}
		// poista se
		nodes.remove(q);
		Log.write(name + " removed.", Log.INFO);

		return true;
	    }
	    if (nodes.get(q).remove(name) == true)
	    {
		return true;
	    }
	}

	// Log.write("remove: "+name+" not found");
	return false;
    }

    /**
     * Palauttaa halutun Noden vektorista
     */
    public Node getNode(int num)
    {
	return nodes.get(num);
    }

    public int getNumNodes()
    {
	return nodes.size();
    }

    static int curObj = 0; // objektin id

    static List<Float> zlist = new ArrayList<Float>();

    static List<Float> zt = new ArrayList<Float>();

    /**
     * renderoi billboardit kauimmaisesta l�himp��n
     */
    public void renderBillboards()
    {
	glMatrixMode(GL_MODELVIEW);
	Frustum.calculateFrustum();

	zlist.clear();
	zt.clear();

	// sorttaa
	for (int q = 0; q < BillBoard.billboards.size(); q++)
	{
	    float x = BillBoard.billboards.get(q).getWorldSpacePosition().x - BaseGame.camera.getWorldSpacePosition().x;
	    float y = BillBoard.billboards.get(q).getWorldSpacePosition().y - BaseGame.camera.getWorldSpacePosition().y;
	    float z = BillBoard.billboards.get(q).getWorldSpacePosition().z - BaseGame.camera.getWorldSpacePosition().z;

	    float len = ((x * x) + (y * y) + (z * z));
	    zlist.add(q, len);
	    zt.add(q, len);
	}
	Collections.sort(zlist);
	for (int q = BillBoard.billboards.size() - 1; q >= 0; q--)
	{
	    float len = zlist.get(q);
	    int ind = zt.indexOf(len);
	    BillBoard.billboards.get(ind).render();
	}
    }

    public void renderBillboardsXZ()
    {
	glMatrixMode(GL_MODELVIEW);
	Frustum.calculateFrustum();

	zlist.clear();
	zt.clear();

	// sorttaa
	for (int q = 0; q < BillBoard.billboards.size(); q++)
	{
	    float x = BillBoard.billboards.get(q).getWorldSpacePosition().x - BaseGame.camera.getWorldSpacePosition().x;
	    float z = BillBoard.billboards.get(q).getWorldSpacePosition().z - BaseGame.camera.getWorldSpacePosition().z;

	    float len = ((x * x) + (z * z));
	    zlist.add(q, len);
	    zt.add(q, len);
	}
	Collections.sort(zlist);
	for (int q = BillBoard.billboards.size() - 1; q >= 0; q--)
	{
	    float len = zlist.get(q);
	    int ind = zt.indexOf(len);
	    BillBoard.billboards.get(ind).render();
	}
    }

    /**
     * renderoi nodes vektorista kamat. ei billboardeja
     * 
     * world nodeen lis�tt�ess� kaikki kamat emnee nodes vektoriin. t�m�
     * renderoi ne. jos halutaan renderoida objekti, tarkistetaan onko nodes
     * vektorissa mit��n (objektilla nodes on tyhj�), luodaan tempnode,
     * lis�t��n objekti siihen ja renderoidaan.
     */
    @Override
    public void render()
    {
	Light.setLights(); // aseta valot

	// halutaan renderoida objekti
	if (nodes.size() == 0)
	{
	    Node tempnode = new Node("tmpnode");
	    tempnode.add(this);
	    tempnode.render();
	    return;
	}

	curObj = 0;
	Texture.active(0);
	Frustum.calculateFrustum();

	// jos ei haluta stencilvarjoja
	if (Settings.useShadowVolumes == false)
	{
	    // rendaa t�ysin n�kyv�t
	    render(false);
	    // sitten l�pin�kyv�t
	    render(true);
	} else
	// renderoidaan my�s varjot.
	{
	    renderShadowVolumes();
	}
    }

    public void renderShadowVolumes()
    {
	if (Light.lights.size() == 0)
	{
	    return;
	}

	// ensin ambient pass. tummana kuin varjo.
	glEnable(GL_CULL_FACE);
	glShadeModel(GL_FLAT);
	Light.disableLights();
	Colorf ambient = (Light.lights.get(0).getAmbient());
	glColor3f(ambient.r, ambient.g, ambient.b);
	render(false);
	render(true);

	glEnable(GL_BLEND);
	glBlendFunc(GL_ONE, GL_ONE); // scr+dst, to add all the lighting
	glDepthMask(false); // zbufferiin ei kirjoteta

	glShadeModel(GL_SMOOTH);
	glEnable(GL_STENCIL_TEST);

	glBindTexture(GL_TEXTURE_2D, 0);
	glDisable(GL_TEXTURE_2D);
	BaseGame.renderTextures(false);
	for (int q = 0; q < Light.lights.size(); q++)
	{
	    glDisable(GL_LIGHTING);
	    ShadowVolumes.setupPass1(Light.lights.get(q).getWorldSpacePosition());
	    renderShadows();

	    ShadowVolumes.setupPass2();
	    renderShadows();

	    ShadowVolumes.setupFinal();

	    Light.enableLights();
	    Light.lights.get(q).setLight(q); // aseta valo

	    glColor3f(0.5f, 0.5f, 0.5f);
	    render(false);
	    render(true);

	}
	glColor3f(1, 1, 1);

	glDisable(GL_STENCIL_TEST);
	glDepthFunc(GL_LEQUAL);

	glCullFace(GL_BACK);
	glEnable(GL_BLEND);
	glBlendFunc(GL_DST_COLOR, GL_ZERO); // modulate: scr*dst

	glEnable(GL_TEXTURE_2D);
	BaseGame.renderTextures(true);

	render(false);
	render(true);

	glDepthMask(true); // z-bufferiin voi kirjoittaa
	glDisable(GL_BLEND);
    }

    /**
     * t��ll� ei mit��n, Object3D ja MD5Model tiedostoissa t�m� metodi vain
     * valo tulee k�ym��n t��ll�
     */
    public void renderModel(boolean rendTrans)
    {
	// Log.write(":"+name);
    }

    /**
     * 
     * @param rendTrans
     *                jos false, renderoi t�ysin n�kyv�t objektit. true niin
     *                l�pin�kyv�t. rekursiivinen kutsu, renderoi kaikki
     *                child-nodet
     */
    private void render(boolean rendTrans)
    {
	for (int q = 0; q < nodes.size(); q++)
	{
	    glPushMatrix();

	    // aseta objekti oikeaan paikkaan ja asentoon
	    nodes.get(q).translate();

	    if (nodes.get(q).looking == null)
	    {
		nodes.get(q).rotate();
	    } else
	    {
		GLU.gluLookAt(0, 0, 0, -nodes.get(q).looking.x, nodes.get(q).looking.y, nodes.get(q).looking.z, getUp().x, getUp().y, getUp().z);
	    }

	    // rendaa obu
	    nodes.get(q).renderModel(rendTrans);

	    // jos pit�� viel� k��nt�mist� (yleens� rotateObject on 0,0,0
	    // mutta esim planeetta esimerkiss� ei)
	    nodes.get(q).rotateObject();

	    // rendaa child-obut jos on
	    nodes.get(q).render(rendTrans);

	    glPopMatrix();
	}
    }

    static float[] mv_matrix = new float[16];

    /**
     * ota talteen objektien, valojen ja kameran paikka. Pit�� kutsua ennen
     * kameran asettamista.
     * 
     * worldSpacePosition, joka on lopullinen paikka, lasketaan parentin ja
     * childien pos/rot perusteella
     */
    public void calcPositions()
    {
	for (int q = 0; q < nodes.size(); q++)
	{
	    glPushMatrix();

	    // jos valo tai kamera, paikka pit�� ottaa talteen
	    if (nodes.get(q).getType() == ObjectInfo.LIGHT || nodes.get(q).getType() == ObjectInfo.CAMERA)
	    {
		nodes.get(q).translate();
	    } else
	    {
		// p�ivit� paikka
		nodes.get(q).translate();
		nodes.get(q).rotate();
		nodes.get(q).rotateObject();
	    }

	    fbuffer.clear();
	    glGetFloat(GL_MODELVIEW_MATRIX, fbuffer);
	    fbuffer.get(mv_matrix);
	    nodes.get(q).setWorldSpacePosition(new Vector3f(mv_matrix[12], mv_matrix[13], mv_matrix[14]));

	    // laske child objektien asento parentista
	    Vector3f.add(childRot, nodes.get(q).getRotation(), nodes.get(q).childRot);

	    // child nodet
	    nodes.get(q).calcPositions();

	    glPopMatrix();
	}

    }

    private void renderShadows()
    {
	for (int q = 0; q < nodes.size(); q++)
	{
	    if (nodes.get(q).castShadow() == true)
	    {
		nodes.get(q).renderShadow();
	    }

	    // child obut
	    nodes.get(q).renderShadows();
	}
    }

    public void renderShadow()
    {
	// Log.write("shadow::"+name);
    }

    // reitti -koodi: ---------------------------------
    private Object3D path = null;

    /**
     * luo pisteist� kaari
     * 
     * (closed param ei k�yt�ss�)
     */
    public void makeCurve(int lod, boolean closed)
    {
	if (path == null)
	{
	    return;
	}

	Mesh mesh = path.getMesh(0);
	for (int c = 0; c < lod; c++)
	{
	    Vector<Vector3f> tmpv = new Vector<Vector3f>();
	    tmpv.add(mesh.vertex[0]); // eka vertex talteen

	    for (int q = 0; q < mesh.vertex.length - 1; q++)
	    {
		Vector3f p0 = mesh.vertex[q];
		Vector3f p1 = mesh.vertex[q + 1];

		Vector3f Q = new Vector3f();
		Vector3f R = new Vector3f();

		// average the 2 original points to create 2 new points. For
		// each
		// CV, another 2 verts are created.
		Q.x = 0.75f * p0.x + 0.25f * p1.x;
		Q.y = 0.75f * p0.y + 0.25f * p1.y;
		Q.z = 0.75f * p0.z + 0.25f * p1.z;

		R.x = 0.25f * p0.x + 0.75f * p1.x;
		R.y = 0.25f * p0.y + 0.75f * p1.y;
		R.z = 0.25f * p0.z + 0.75f * p1.z;

		tmpv.add(Q);
		tmpv.add(R);
	    }

	    tmpv.add(mesh.vertex[mesh.vertex.length - 1]); // vika vertex
	    // talteen

	    // if(closed) tmpv.add(path.vertex[ 0 ]);

	    // korvataan alkuper�inen reitti uudella kaarella
	    Vector3f[] newp = new Vector3f[tmpv.size()];
	    for (int q = 0; q < tmpv.size(); q++)
	    {
		newp[q] = tmpv.get(q);
	    }
	    mesh.vertex = newp;

	}

	Log.write("newPath, size: " + mesh.vertex.length, Log.INFO);
    }

    /**
     * aseta obulle/kameralle reitti
     */
    public void setPath(Object3D _path)
    {
	Log.write("setPath, size: " + _path.getMesh(0).vertex.length, Log.INFO);
	path = _path;
    }

    float pathTime = 0;

    public void setTime(float time)
    {
        pathTime = (float) time % path.getMesh(0).vertex.length;
        updatePath(0); 
    }

    public float getTime()
    {
	return pathTime;
    }

    // p�ivit� paikka reitill�
    public void updatePath(float time)
    {
	if (path == null)
	{
	    return;
	}
	Mesh mesh = path.getMesh(0);
	int len = mesh.vertex.length;
        
	pathTime += time;
	if ((int) pathTime > len - 1)
	{
	    pathTime = 0;
	}

        
	int curPos = (int) pathTime;
	int next = curPos + 1;
	next %= len;

	float d = pathTime - curPos;

	// laske objektin/kameran paikka
	Vector3f out = new Vector3f();
	Vector3f.sub(mesh.vertex[next], mesh.vertex[curPos], out);
	out.scale(d);
	Vector3f.add(mesh.vertex[curPos], out, out);
	setWorldSpacePosition(out); // kameralle
	setPosition(out); // objekteille

	// laske kohta johon katsotaan
	Vector3f out2 = new Vector3f();
	Vector3f.sub(mesh.vertex[(next + 1) % len], mesh.vertex[next], out2);
	out2.scale(d);
	Vector3f.add(mesh.vertex[next], out2, out2);
	lookAt(out2);

    }

    // ---------------------------------------
    Callback objCb = null;

    public void setCallback(Callback cb)
    {
	objCb = cb;
    }
}
