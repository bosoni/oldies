/**
 * @file Callback.java
 *
 * @author mjt, 2007-08
 * mixut@hotmail.com
 * 
 */
package jsat;

import org.lwjgl.util.vector.Vector3f;

public interface Callback
{
    public void objAction(String name, int id, Node obj, Vector3f pos, Vector3f rot);
}
