/**
 * @file Log.java
 *
 * @author mjt, 2007-08
 * mixut@hotmail.com
 *
 */
package jsat;

import java.io.*;

public class Log
{
    public static final int INFO = 1;

    public static final int ERROR = 2;

    private static FileWriter fileWriter = null;

    public static boolean writeLog = true; // kirjoita ruudulle (ja tiedostoon)

    public static boolean toFile = true; // kirjoitetaan tiedostoon

    public static boolean printNotes = false; // printataanko load ym infot

    public static void createLog(String file)
    {
	if (toFile == false)
	{
	    return;
	} // ei olla kirjoittamassa

	try
	{
	    File f = new File(file);

	    if (f.exists())
	    {
		f.delete();
	    }

	    fileWriter = new FileWriter(f);
	} catch (IOException e)
	{
	    System.out.println(e);
	}
    }

    public static void closeFile()
    {
	try
	{
	    fileWriter.close();
	} catch (IOException e)
	{
	    System.out.println(e);
	}
    }

    public static void write(String str, int type)
    {
	if (type == INFO && printNotes)
	{
	    write(str);
	} else if (type == ERROR)
	{
	    FileIO.ErrorMessage(str);
	}
    }

    public static void write(String str)
    {
	if (writeLog == false)
	{
	    return;
	}

	try
	{
	    System.out.println(str);

	    if (fileWriter != null && toFile == true)
	    {
		fileWriter.write(str + System.getProperty("line.separator"));
		fileWriter.flush();
	    }
	} catch (IOException e)
	{
	    System.out.println(e);
	}
    }
}
