/**
 * @file BillBoard.java
 *
 * @author mjt, 2007
 * mixut@hotmail.com
 *
 */
package jsat;

import org.lwjgl.util.vector.Vector3f;
import java.nio.FloatBuffer;
import java.util.Vector;

import org.lwjgl.BufferUtils;
import java.io.IOException;
import static org.lwjgl.opengl.GL11.*;

/**
 * piirt�� billboardin, siis 2d-kuvan 3d maailmaan (aina kameraan p�in)
 */
public class BillBoard extends Node
{
    private static FloatBuffer modelView = BufferUtils.createFloatBuffer(16);

    private Texture texture = null;

    private float scaleX = 1;

    private float scaleY = 1;

    // vektori billboardeille
    public static Vector<BillBoard> billboards = new Vector<BillBoard>();

    public BillBoard(String name, String fileName, Vector3f pos, int minFilter, int magFilter) throws IOException
    {
	super(name);
	super.setPosition(pos);

	fileName = Settings.TEXTUREDIR + fileName;
	texture = Texture.loadTexture(fileName, minFilter, magFilter);

	setType(BILLBOARD);
    }

    public void scale(float sx, float sy)
    {
	scaleX = sx;
	scaleY = sy;
    }

    public static int billboardsRendered = 0;

    public static boolean rendOrig = true;

    // renderoi billboard
    public void render()
    {
	float size = scaleY;
	if (scaleX > scaleY)
	{
	    size = scaleX;
	}

	if (Frustum.cubeInFrustum(getWorldSpacePosition().x, getWorldSpacePosition().y, getWorldSpacePosition().z, size) == 0)
	{
	    return;
	}

	if (rendOrig)
	{
	    render_orig(getPosition(), scaleX, scaleY);
	} else
	{
	    render_2(getPosition(), scaleX, scaleY);
	}

	billboardsRendered++;
    }

    public void render_orig(Vector3f pos, float sx, float sy)
    {
	if (texture == null)
	{
	    return;
	}
	texture.bind(0);

	glPushAttrib(GL_COLOR_BUFFER_BIT | GL_ENABLE_BIT | GL_POLYGON_BIT);
	Light.disableLights();
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glGetFloat(GL_MODELVIEW_MATRIX, modelView);

	Vector3f right = new Vector3f(modelView.get(0), modelView.get(4), modelView.get(8));
	right.normalise();
	right.scale(sx);

	Vector3f up = new Vector3f(modelView.get(1), modelView.get(5), modelView.get(9));
	up.normalise();
	up.scale(sy);

	glBegin(GL_TRIANGLE_FAN);

	glTexCoord2f(0, 1);
	glVertex3f(pos.x + (right.x - up.x), pos.y + (right.y - up.y), pos.z + (right.z - up.z));

	glTexCoord2f(0, 0);
	glVertex3f(pos.x + (right.x + up.x), pos.y + (right.y + up.y), pos.z + (right.z + up.z));

	glTexCoord2f(1, 0);
	glVertex3f(pos.x + (up.x - right.x), pos.y + (up.y - right.y), pos.z + (up.z - right.z));

	glTexCoord2f(1, 1);
	glVertex3f(pos.x + (-right.x - up.x), pos.y + (-right.y - up.y), pos.z + (-right.z - up.z));

	glEnd();
	glPopAttrib();
    }

    public void render_2(Vector3f pos, float sx, float sy)
    {
	texture.bind(0);

	glPushMatrix();
	glPushAttrib(GL_COLOR_BUFFER_BIT | GL_ENABLE_BIT | GL_POLYGON_BIT);
	glDisable(GL_LIGHTING);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glTranslatef(pos.x, pos.y, pos.z);
	glRotatef(BaseGame.camera.getRotation().y, 0, 1.0f, 0);

	sx *= 0.5f;
	sy *= 0.5f;

	glBegin(GL_TRIANGLE_FAN);
	glTexCoord2f(0, 1);
	glVertex3f(-sx, -sy, 0);
	glTexCoord2f(1, 1);
	glVertex3f(sx, -sy, 0);
	glTexCoord2f(1, 0);
	glVertex3f(sx, sy, 0);
	glTexCoord2f(0, 0);
	glVertex3f(-sx, sy, 0);
	glEnd();

	glPopAttrib();
	glPopMatrix();
    }
}
