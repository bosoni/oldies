/**
 * @file MD5Model.java
 *
 * java port by mjt, 2007-08
 *
 * based on
 * "md5mesh model loader + animation Copyright (c) 2005 David HENRY"
 * found at http://tfc.duke.free.fr/coding/md5-specs-en.html
 *
 * "THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE."
 *
 */

// t�m� porttaus bugaa pahasti!
// pit�isi kirjoittaa uudestaan!!

package jsat;

import java.io.*;
import java.util.StringTokenizer;
import java.io.IOException;
import java.nio.FloatBuffer;
import java.util.HashMap;
import java.util.Vector;

import org.lwjgl.BufferUtils;
import org.lwjgl.util.vector.Vector3f;
import static org.lwjgl.opengl.GL11.*;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector4f;

public class MD5Model extends Node
{
    // kaikki ladatut md5-mallit ettei ladata samaa objektia moneen kertaan
    private static HashMap<String, MD5Model> objs = new HashMap<String, MD5Model>();

    private MD5Model origData = null;

    private Vector3f scale=new Vector3f(1,1,1);
    public void scale(float x, float y, float z)
    {
        scale.set(x, y, z);
    }
    // meshit
    private Vector<MD5Mesh> meshes = new Vector<MD5Mesh>();

    // meshien uudet asennot
    private Vector<Geometry> geoms = new Vector<Geometry>();

    private int numMD5Meshes = 0;

    // anim
    private MD5Anim anim = null;

    Vector<Joint> baseSkel = new Vector<Joint>();

    private float updtime = 0;

    private int curFrm = 0;

    // joka calcTime:s frame lasketaan uusi asento
    public static int calcTime = 20;

    private static Quaternion quat = new Quaternion();

    private int numJoints = 0;

    int numJoints()
    {
	return numJoints;
    }

    private boolean drawSkeleton = false;
    public void drawSkeleton(boolean draw)
    {
	drawSkeleton = draw;
    }

    private MD5Model(String _name)
    {
	super(_name);
	setType(ObjectInfo.ANIM);
    }
    public MD5Model()
    {
	super("md5");
	setType(ObjectInfo.ANIM);
    }

    /**
     * palauttaa obj:n kloonin. muuten sama kuin obj mutta paikka ja asento
     * voi olla eri. huom. asentokin menee samalla tavalla kuin obj:ssa.
     * 
     * jos haluaa saman objektin useaan kertaan eri animoinnilla, pit��
     * k�ytt�� loadia. se ei silti lataa vertexdataa moneen kertaan, se on
     * muistissa vain kerran.
     */
    public static MD5Model makeClone(MD5Model obj, String name)
    {
	MD5Model tmp = new MD5Model(name);
	tmp.origData = obj;

	tmp.setPosition(new Vector3f(0, 0, 0));
	tmp.setRotation(new Vector3f(0, 0, 0));

	return tmp;
    }

    public MD5Model(String name, String fileName, String animFile) throws IOException
    {
	super(name);
	load(name, fileName, animFile);
    }

    public void load(String name, String fileName, String animFile) throws IOException
    {
	this.name = name;
	setType(ObjectInfo.ANIM);

	// tarkista onko md5 tiedosto ladattu jo. jos on, ota se hashmapista
	if (objs.containsKey(fileName))
	{
	    MD5Model tmp = objs.get(fileName);

	    origData = this;
	    meshes = tmp.meshes;

	    numMD5Meshes = tmp.numMD5Meshes;
	    baseSkel = tmp.baseSkel;
	    numJoints = tmp.numJoints;
	} else
	{
	    loadModel(fileName);
	}

	if (animFile != null)
	{
	    anim = new MD5Anim(animFile);
	    anim.loadAnimation(animFile);

	    if (anim.checkAnimValidity(this) == true)
	    {
		Log.write(fileName + " ok", Log.INFO);
	    } else
	    {
		Log.write(fileName + " failed", Log.ERROR);
	    }

            if (origData.anim != null)
	    {
		origData.anim.update(updtime);
	    }
	}

	makeBuffers(name);

	loadTextures(GL_LINEAR, GL_LINEAR);
    }

    private void makeBuffers(String name)
    {
	// luo bufferit
	for (int a = 0; a < meshes.size(); a++)
	{
	    MD5Mesh tmp = meshes.get(a);
	    Geometry geom = new Geometry();

	    FloatBuffer vbuf = BufferUtils.createFloatBuffer(tmp.verts.length * 3);
	    geom.setVerts(vbuf);

	    // laske meshille asento
	    prepare(tmp, geom, null);

	    tmp.calcNormals(geom.getVerts());

	    // geom luodaan bufferit
	    geom.createBuffers(null, tmp.faces, tmp.normals, tmp.uvt, false);

	    // ja talteen
	    geoms.add(geom);

	    tmp.boundings.setup(geom.getVerts(), tmp.faces, BoundingArea.SPHERE);

	    // jos halutaan varjot
	    if (Settings.useShadowVolumes == true)
	    {
		// varaa tilaa varjoille
		tmp.shadow = new ShadowVolumes(tmp.faces.length);
		tmp.shadow.setPlanes(tmp.planeEquation);
		tmp.shadow.setConnectivity(tmp.faces);
	    }

	}

    }

    /**
     * lataa texturet
     */
    public void loadTextures(int minFilter, int magFilter) throws IOException
    {
	for (int q = 0; q < meshes.size(); q++)
	{
	    MD5Mesh tmp = (MD5Mesh) meshes.get(q);
	    Texture tex = Texture.loadTexture(Settings.TEXTUREDIR + tmp.textureName, minFilter, magFilter);

	    Geometry g = geoms.get(q);
	    g.setTexture(0, tex);
	}
    }

    /**
     * p�ivit� animaatio
     */
    public void update(float ptime)
    {
	updtime += ptime;

	// aika p�ivitt��?
	if (curFrm == calcTime)
	{
	    if (origData.anim != null)
	    {
		origData.anim.update(updtime);
	    }
	    updtime = 0;
	}
    }

    /*
     * p�ivit� ja renderoi model
     */
    public void renderModel(boolean rendTrans)
    {
	origData.renderModel(getWorldSpacePosition());
    }

    public void updateNormals()
    {
	for (int a = 0; a < meshes.size(); a++)
	{
	    MD5Mesh tmp = meshes.get(a);
	    Geometry geom = geoms.get(a);
	    Geometry.calcNormals(geom.getVerts(), tmp.faces, tmp.normals, false);

	    geom.updateNormalBuffer(tmp.normals);
	}
    }

    public void renderModel(Vector3f pos)
    {
	for (int a = 0; a < meshes.size(); a++)
	{
	    MD5Mesh tmp = meshes.get(a);
	    Geometry geom = geoms.get(a);

	    if (Frustum.objInFrustum(pos.x, pos.y, pos.z, tmp.boundings) == true)
	    {
		if (curFrm == calcTime)
		{
		    // tekee vertexArray taulukon
		    if (anim != null)
		    {
			updateNormals();
			prepare(tmp, geom, anim.skeleton);
		    }
		}
		geom.render();
                //tmp.rend(geom.getVerts());
                
                
		BaseGame.objectsRendered++;
	    }

	}

	if (drawSkeleton == true)
	{
	    drawSkeleton(anim.skeleton, numJoints);
	}

	if (curFrm == calcTime)
	{
	    curFrm = 0;
	}
	curFrm++;

    }

    public void renderShadow()
    {
	origData.renderShadows(getWorldSpacePosition(), childRot);
    }

    private void renderShadows(Vector3f pos, Vector3f rot)
    {
	int a;
	for (a = 0; a < meshes.size(); a++)
	{
	    MD5Mesh tmp = (MD5Mesh) meshes.get(a);
	    Geometry geom = geoms.get(a);
	    tmp.shadow.buildShadowVolume(geom.getVerts(), tmp.faces, pos, rot);
	}
    }

    /**
     * renderoi luuranko
     */
    private void drawSkeleton(Joint[] joints, int num_joints)
    {
	int i;

	glDisable(GL_DEPTH_TEST);

	// draw each joint
	glPointSize(10.0f);
	glColor3f(1.0f, 0.0f, 0.0f);
	glBegin(GL_POINTS);

	for (i = 0; i < num_joints; ++i)
	{
	    glVertex3f(joints[i].pos.x*scale.x, joints[i].pos.y*scale.y, joints[i].pos.z*scale.z);
	}

	glEnd();
	glPointSize(1.0f);

	// draw each bone
	glColor3f(0.0f, 1.0f, 1.0f);
	glBegin(GL_LINES);

	for (i = 0; i < num_joints; ++i)
	{
	    if (joints[i].parent != -1)
	    {
		glVertex3f(joints[joints[i].parent].pos.x*scale.x, joints[joints[i].parent].pos.y*scale.y, joints[joints[i].parent].pos.z*scale.z);
		glVertex3f(joints[i].pos.x*scale.x, joints[i].pos.y*scale.y, joints[i].pos.z*scale.z);
	    }
	}

	glEnd();

	glEnable(GL_DEPTH_TEST);

	glColor4f(1, 1, 1, 1);
    }

    /**
     * luo uusi asento, lasketaan joka vertexin paikka
     */
    public void prepare(MD5Mesh mesh, Geometry geom,  Joint[] skeleton)
    {
	FloatBuffer buf = geom.getVerts();
	buf.clear();

	for (int q = 0; q < mesh.numVerts; q++)
	{
	    Vector3f vert = new Vector3f(0, 0, 0);

	    for (int w = 0; w < mesh.verts[q].weightCount; w++)
	    {
		int ind = mesh.verts[q].weightIndex + w;

		Vector3f pos = new Vector3f(mesh.weights[ind].pos[0], mesh.weights[ind].pos[1], mesh.weights[ind].pos[2]);

		int i = mesh.verts[q].weightIndex;
		int ii = mesh.weights[i].jointIndex;
		Joint tmpjoint = null;

		if (skeleton == null)
		{
		    tmpjoint = baseSkel.get(ii);
		} else
		{
		    tmpjoint = skeleton[ii];
		}

		quat.set(tmpjoint.orient);

		Vector3f out = Quaternion.quatRotatePoint(quat, pos);

		vert.x += ((tmpjoint.pos.x + out.x) * mesh.weights[i].weightValue);
		vert.y += ((tmpjoint.pos.y + out.y) * mesh.weights[i].weightValue);
		vert.z += ((tmpjoint.pos.z + out.z) * mesh.weights[i].weightValue);
	    }

	    buf.put(vert.x * scale.x);
	    buf.put(vert.y * scale.y);
	    buf.put(vert.z * scale.z);
	}
	buf.flip();

	if (Settings.VBO)
	    geom.vboUpdate();
    }

    // lataa md5 tiedoston
    private void loadModel(String fileName) throws IOException
    {
	origData = this;
	MD5Mesh tmpMD5Mesh = null;

	// avaa tiedosto
	File f = new File(Settings.DATADIR + fileName);
	BufferedReader in = new BufferedReader(new FileReader(f));

	while (true)
	{
	    // lue rivi
	    String rivi = in.readLine();

	    if (rivi == null)
	    {
		break;
	    }

	    // jos tyhj� rivi niin ei k�sitell�
	    if (rivi.equals(""))
	    {
		continue;
	    }

	    StringTokenizer st = new StringTokenizer(rivi);
            if(st.hasMoreElements()==false) continue;
	    String str = st.nextToken();

	    if (str.equals("numJoints"))
	    {
		numJoints = Integer.parseInt(st.nextToken());

		continue;
	    }

	    if (str.equals("numMeshes"))
	    {
		numMD5Meshes = Integer.parseInt(st.nextToken());

		continue;
	    }

	    // "[boneName]" [parentIndex] ( [xPos] [yPos] [zPos] ) (
	    // [xOrient] [yOrient] [zOrient] )
	    if (str.equals("joints"))
	    {
		for (int q = 0; q < numJoints; q++)
		{
		    rivi = in.readLine();
		    st = new StringTokenizer(rivi);

		    Joint tmp = new Joint();
		    tmp.name = st.nextToken(); // name
		    tmp.parent = Integer.parseInt(st.nextToken()); // parent
		    st.nextToken();

		    tmp.pos.x = Float.parseFloat(st.nextToken()); // position
		    tmp.pos.y = Float.parseFloat(st.nextToken()); //
		    tmp.pos.z = Float.parseFloat(st.nextToken()); //

		    st.nextToken();
		    st.nextToken();

		    tmp.orient.x = Float.parseFloat(st.nextToken()); // orientation
		    tmp.orient.y = Float.parseFloat(st.nextToken()); //
		    tmp.orient.z = Float.parseFloat(st.nextToken()); //

		    st.nextToken();

		    // laske w
		    tmp.orient.quatComputeW();

		    baseSkel.add(tmp);
		}

		continue;
	    }

	    if (str.equals("mesh"))
	    {
		if (tmpMD5Mesh != null) // jos muistissa jo vanha mesh
		{
		    meshes.add(tmpMD5Mesh); // vektoriin talteen
		}

		tmpMD5Mesh = new MD5Mesh(); // luo uusi mesh

		continue;
	    }

	    if (str.equals("shader"))
	    {
		// ota texturen nimi talteen ilman "" merkkej�
		String tmpstr = st.nextToken();
		tmpMD5Mesh.textureName = tmpstr.substring(1, tmpstr.length() - 1);

		continue;
	    }

	    if (str.equals("numverts"))
	    {
		tmpMD5Mesh.numVerts = Integer.parseInt(st.nextToken());
		tmpMD5Mesh.uvt = new Vector2f[tmpMD5Mesh.numVerts]; // uv
		tmpMD5Mesh.verts = new MD5Vertex[tmpMD5Mesh.numVerts];
		tmpMD5Mesh.normals = new Vector3f[tmpMD5Mesh.numVerts]; // xyz

		continue;
	    }

	    if (str.equals("numtris"))
	    {
		tmpMD5Mesh.numFaces = Integer.parseInt(st.nextToken());
		tmpMD5Mesh.faces = new int[tmpMD5Mesh.numFaces][3];

		continue;
	    }

	    if (str.equals("numweights"))
	    {
		tmpMD5Mesh.numWeights = Integer.parseInt(st.nextToken());
		tmpMD5Mesh.weights = new MD5Weight[tmpMD5Mesh.numWeights];

		continue;
	    }

	    // numverts <integer>
	    // vert [vertIndex] ( [texU] [texV] ) [weightIndex] [weightElem]
	    if (str.equals("vert"))
	    {
		int no = Integer.parseInt(st.nextToken());

		tmpMD5Mesh.uvt[no] = new Vector2f();

		st.nextToken();

		tmpMD5Mesh.uvt[no].x = Float.parseFloat(st.nextToken());
		tmpMD5Mesh.uvt[no].y = Float.parseFloat(st.nextToken());

		st.nextToken();

		tmpMD5Mesh.verts[no] = new MD5Vertex();
		tmpMD5Mesh.verts[no].weightIndex = Integer.parseInt(st.nextToken());
		tmpMD5Mesh.verts[no].weightCount = Integer.parseInt(st.nextToken());

		continue;
	    }

	    // numtris <integer>
	    // tri [triIndex] [vertIndex1] [vertIndex2] [vertIndex3]
	    if (str.equals("tri"))
	    {
		int no = Integer.parseInt(st.nextToken());
		tmpMD5Mesh.faces[no][0] = Integer.parseInt(st.nextToken());
		tmpMD5Mesh.faces[no][1] = Integer.parseInt(st.nextToken());
		tmpMD5Mesh.faces[no][2] = Integer.parseInt(st.nextToken());

		continue;
	    }

	    // numweights <integer>
	    // weight [weightIndex] [jointIndex] [weightValue] ( [xPos]
	    // [yPos] [zPos] )
	    if (str.equals("weight"))
	    {
		int no = Integer.parseInt(st.nextToken());

		tmpMD5Mesh.weights[no] = new MD5Weight();
		tmpMD5Mesh.weights[no].jointIndex = Integer.parseInt(st.nextToken());
		tmpMD5Mesh.weights[no].weightValue = Float.parseFloat(st.nextToken());

		st.nextToken();

		// xyz
		tmpMD5Mesh.weights[no].pos[0] = Float.parseFloat(st.nextToken());
		tmpMD5Mesh.weights[no].pos[1] = Float.parseFloat(st.nextToken());
		tmpMD5Mesh.weights[no].pos[2] = Float.parseFloat(st.nextToken());

		continue;
	    }
	}

	in.close();

	if (tmpMD5Mesh != null)
	{
	    meshes.add(tmpMD5Mesh);

	    objs.put(fileName, this); // talteen hashmappiin josta voi
	    // my�hemmin hakea
	}

    }
}

// apuluokat
final class Joint
{
    String name = "";

    int parent = 0;

    Vector3f pos = new Vector3f(0, 0, 0);

    Quaternion orient = new Quaternion(0, 0, 0, 0);

    public Joint()
    {
    }
}

final class MD5Vertex // numVerts
{
    int weightIndex; // start

    int weightCount;
}

final class MD5Weight // numWeights
{
    int jointIndex;

    float weightValue;

    float[] pos = new float[3]; // [3], xyz
}

final class MD5Mesh
{
    String textureName = ""; // texturen nimi

    int numVerts = 0;

    int numFaces = 0;

    int numWeights = 0;

    Vector4f[] planeEquation = null;

    Vector3f[] normals = null; // [numWeights]

    Vector2f[] uvt = null; // [numVerts]

    int[][] faces = null; // [numFaces][3]

    MD5Vertex[] verts = null;

    MD5Weight[] weights = null;

    BoundingArea boundings = new BoundingArea();

    ShadowVolumes shadow = null; // objektin varjo

    public MD5Mesh()
    {
    }

    public void calcNormals(FloatBuffer positions)
    {
	if (positions == null)
	    return;

	Geometry.calcNormals(positions, faces, normals, false);
	Vector3f pos1 = new Vector3f();
	Vector3f pos2 = new Vector3f();
	Vector3f pos3 = new Vector3f();

	// laske joka polyn tason normaali
	planeEquation = new Vector4f[faces.length];
	for (int w = 0; w < faces.length; w++)
	{
	    planeEquation[w] = new Vector4f();

	    pos1.set(positions.get(faces[w][0] * 3), positions.get(faces[w][0] * 3 + 1), positions.get(faces[w][0] * 3 + 2));
	    pos2.set(positions.get(faces[w][1] * 3), positions.get(faces[w][1] * 3 + 1), positions.get(faces[w][1] * 3 + 2));
	    pos3.set(positions.get(faces[w][2] * 3), positions.get(faces[w][2] * 3 + 1), positions.get(faces[w][2] * 3 + 2));

	    Geometry.calcPlane(pos1, pos2, pos3, planeEquation[w]);
	}
    }
    
    public void rend(FloatBuffer positions)
    {
	Vector3f pos1 = new Vector3f();
	Vector3f pos2 = new Vector3f();
	Vector3f pos3 = new Vector3f();

        glBegin(GL_TRIANGLES);
        for (int w = 0; w < faces.length; w++)
	{
	    pos1.set(positions.get(faces[w][0] * 3), positions.get(faces[w][0] * 3 + 1), positions.get(faces[w][0] * 3 + 2));
	    pos2.set(positions.get(faces[w][1] * 3), positions.get(faces[w][1] * 3 + 1), positions.get(faces[w][1] * 3 + 2));
	    pos3.set(positions.get(faces[w][2] * 3), positions.get(faces[w][2] * 3 + 1), positions.get(faces[w][2] * 3 + 2));
     
            glVertex3f(pos1.x, pos1.y, pos1.z);
            glVertex3f(pos2.x, pos2.y, pos2.z);
            glVertex3f(pos3.x, pos3.y, pos3.z);
            
        }
        glEnd();
        
    }
    
}
