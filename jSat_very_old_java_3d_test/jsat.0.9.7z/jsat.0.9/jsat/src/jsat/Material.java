/**
 * @file Material.java
 *
 * @author mjt, 2007-08
 * mixut@hotmail.com
 *
 */
/*
 * Ns = Phong specularTex component. Ranges from 0 to 200.
 * Kd = Diffuse color weighted by the diffuseTex coefficient.
 * Ka = Ambient color weighted by the ambientTex coefficient.
 * Ks = Specular color weighted by the specularTex coefficient.
 * d = Dissolve factor (pseudo-transparency). This is set to the internal face transparency value.
 * illum 2 = Diffuse and specularTex shading model.
 * map_Kd = Diffuse color texture map.
 * map_Ks = Specular color texture map.
 * map_Ka = Ambient color texture map.
 * map_Bump = Bump texture map.
 * map_d = Opacity texture map.
 */
package jsat;

import java.io.*;
import java.util.StringTokenizer;
import java.util.Vector;
import java.io.File;
import java.io.IOException;
import org.lwjgl.opengl.GL11;
import static org.lwjgl.opengl.GL11.*;

public class Material
{
    // kaikki materiaalit
    private static Vector<MaterialInfo> materialInfoV = new Vector<MaterialInfo>();

    // objektin k�yt�ss� oleva materiaali
    private MaterialInfo materialInfo = new MaterialInfo();

    public MaterialInfo getMaterialInfo()
    {
	return materialInfo;
    }

    public String getDiffuseTexName()
    {
	return materialInfo.diffuseTex;
    }

    public static void loadMaterial(String fileName) throws IOException
    {
	Log.write("load material " + fileName, Log.INFO);

	// avaa tiedosto
	File f = new File(Settings.DATADIR + fileName);
	BufferedReader in = new BufferedReader(new FileReader(f));
	MaterialInfo tmpmat = null;

	while (true)
	{
	    // lue rivi
	    String rivi = in.readLine();

	    if (rivi == null)
	    {
		materialInfoV.add(tmpmat);
		break;
	    }

	    // jos tyhj� rivi niin ei k�sitell�
	    if (rivi.equals(""))
	    {
		continue;
	    }
	    // jos kommenttirivi, ei k�sitell�
	    if (rivi.charAt(0) == '#')
	    {
		continue;
	    }

	    StringTokenizer st = new StringTokenizer(rivi);
	    String str = st.nextToken();

	    // uusi materiaali, materiaalin nimi
	    if (str.equals("newmtl"))
	    {
		if (tmpmat != null)
		{
		    materialInfoV.add(tmpmat);
		}

		tmpmat = new MaterialInfo();
		tmpmat.name = st.nextToken();
		continue;
	    }

	    // Diffuse color texture map
	    if (str.equals("map_Kd"))
	    {
		tmpmat.diffuseTex = st.nextToken();
		continue;
	    }
	    // Specular color texture map
	    if (str.equals("map_Ks"))
	    {
		tmpmat.specularTex = st.nextToken();
		continue;
	    }
	    // Ambient color texture map
	    if (str.equals("map_Ka"))
	    {
		tmpmat.ambientTex = st.nextToken();
		continue;
	    }
	    // Bump color texture map
	    if (str.equals("map_Bump"))
	    {
		tmpmat.bumpTex = st.nextToken();
		continue;
	    }
	    // Opacity color texture map
	    if (str.equals("map_d"))
	    {
		tmpmat.opacityTex = st.nextToken();
		continue;
	    }

	    // Phong specularTex component
	    if (str.equals("Ns"))
	    {
		tmpmat.phongSpec = Float.parseFloat(st.nextToken());
		continue;
	    }
	    // Ambient color
	    if (str.equals("Ka"))
	    {
		tmpmat.ambientColor.r = Float.parseFloat(st.nextToken());
		tmpmat.ambientColor.g = Float.parseFloat(st.nextToken());
		tmpmat.ambientColor.b = Float.parseFloat(st.nextToken());
		continue;
	    }

	    // Diffuse color
	    if (str.equals("Kd"))
	    {
		tmpmat.diffuseColor.r = Float.parseFloat(st.nextToken());
		tmpmat.diffuseColor.g = Float.parseFloat(st.nextToken());
		tmpmat.diffuseColor.b = Float.parseFloat(st.nextToken());
		continue;
	    }
	    // Specular color
	    if (str.equals("Ks"))
	    {
		tmpmat.specularColor.r = Float.parseFloat(st.nextToken());
		tmpmat.specularColor.g = Float.parseFloat(st.nextToken());
		tmpmat.specularColor.b = Float.parseFloat(st.nextToken());
		continue;
	    }

	    // Dissolve factor
	    if (str.equals("d"))
	    {
		tmpmat.dissolve = Float.parseFloat(st.nextToken());

		tmpmat.diffuseColor.a = tmpmat.dissolve;
		tmpmat.ambientColor.a = tmpmat.dissolve;
		tmpmat.specularColor.a = tmpmat.dissolve;
		continue;
	    }

	}

    }

    /**
     * aseta name-niminen materiaali
     */
    public void setMaterial(String name)
    {
	if (name == null || name.equals("(null)"))
	{
	    return;
	}

	for (int q = 0; q < materialInfoV.size(); q++)
	{
	    MaterialInfo tmp = (MaterialInfo) materialInfoV.get(q);
	    if (tmp == null)
	    {
		continue;
	    } // varmistetaan viel�..

	    if (((MaterialInfo) materialInfoV.get(q)).name.equals(name))
	    {
		materialInfo = (MaterialInfo) materialInfoV.get(q);
		break;
	    }
	}
    }

    public void useMaterial()
    {
	glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT, materialInfo.ambientColor.getBuffer());
	glMaterial(GL11.GL_FRONT, GL11.GL_DIFFUSE, materialInfo.diffuseColor.getBuffer());
	glMaterial(GL11.GL_FRONT, GL11.GL_SPECULAR, materialInfo.specularColor.getBuffer());
	glMaterialf(GL11.GL_FRONT, GL11.GL_SHININESS, materialInfo.phongSpec);
	glMaterial(GL11.GL_FRONT, GL11.GL_EMISSION, materialInfo.emissionColor.getBuffer());
    }
}

class MaterialInfo
{
    // materiaalin nimi
    public String name = null;

    // texturemap nimet
    public String diffuseTex = null;

    public String specularTex = null;

    public String ambientTex = null;

    public String bumpTex = null;

    public String opacityTex = null;

    // v�riarvot
    public float phongSpec = 5; // Ns: 0-200

    public Colorf diffuseColor = new Colorf(0.1f, 0.1f, 0.1f, 1); // diffuse

    // color

    public Colorf ambientColor = new Colorf(0.1f, 0.1f, 0.1f, 1); // ambient

    // color

    public Colorf specularColor = new Colorf(0.5f, 0.5f, 0.5f, 1); // specular

    // color

    public Colorf emissionColor = new Colorf(0.1f, 0.1f, 0.1f, 1);

    public float dissolve = 1; // transparency

    public void setMaterialInfo(Colorf diffuse, Colorf specular, Colorf ambient, Colorf emission)
    {
	if (diffuse != null)
	{
	    diffuseColor = diffuse;
	}
	if (specular != null)
	{
	    specularColor = specular;
	}
	if (ambient != null)
	{
	    ambientColor = ambient;
	}
	if (emission != null)
	{
	    emissionColor = emission;
	}
    }
}
