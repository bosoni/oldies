/**
 * @file Camera.java
 *
 * @author mjt, 2007-08
 * mixut@hotmail.com
 *
 */
package jsat;

import org.lwjgl.util.glu.GLU;
import org.lwjgl.util.vector.Vector3f;
import static org.lwjgl.opengl.GL11.*;

/**
 * kameran k�sittely�
 */
public class Camera extends Node
{
    /**
     * luo kamera
     * 
     * @param name
     *                kameran nimi
     */
    public Camera(String name)
    {
	super(name);
	setType(CAMERA);
    }

    /**
     * p�ivit� kamera
     */
    public void updateXZ()
    {
	glLoadIdentity();

	glRotatef(-getRotation().x, 1.0f, 0, 0);
	glRotatef(-getRotation().y, 0, 1.0f, 0);
	glRotatef(-getRotation().z, 0, 0, 1.0f);

	glTranslatef(-getWorldSpacePosition().x, -getWorldSpacePosition().y, -getWorldSpacePosition().z);
    }

    /**
     * p�ivit� kamera
     */
    public void update()
    {
	glLoadIdentity();

	Vector3f vp = new Vector3f(); // view point
	Vector3f.add(getWorldSpacePosition(), getView(), vp);
	GLU.gluLookAt(getWorldSpacePosition().x, getWorldSpacePosition().y, getWorldSpacePosition().z, vp.x, vp.y, vp.z, getUp().x, getUp().y, getUp().z);
    }

    /**
     * k��nn� kuvakulma pos:iin
     */
    public void lookAt(Vector3f pos)
    {
	glLoadIdentity();
	GLU.gluLookAt(getWorldSpacePosition().x, getWorldSpacePosition().y, getWorldSpacePosition().z, pos.x, pos.y, pos.z, getUp().x, getUp().y, getUp().z);
    }

    /**
     * k��nn� kuvakulma xyz:aan
     */
    public void lookAt(float x, float y, float z)
    {
	glLoadIdentity();
	GLU.gluLookAt(getWorldSpacePosition().x, getWorldSpacePosition().y, getWorldSpacePosition().z, x, y, z, getUp().x, getUp().y, getUp().z);
    }
}
