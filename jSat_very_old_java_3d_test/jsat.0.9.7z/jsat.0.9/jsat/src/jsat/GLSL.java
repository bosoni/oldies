/**
 * @file GLSL.java
 *
 * @author mjt, 2007
 * mixut@hotmail.com
 *
 * pohjana k�ytin Chman 21 GLSL Testi�.
 * http://coding.shakebox.org/Demos/
 */
package jsat;

import java.nio.*;
import java.util.HashMap;
import org.lwjgl.*;
import org.lwjgl.opengl.*;

public class GLSL
{
    public String name = ""; // shaderin nimi (tiedostonimi)

    private static HashMap<String, Integer> programs = new HashMap<String, Integer>();

    private static int curProgramID = -1; // mik� ohjelma on kortilla (-1

    // ei mik��n)

    /** Our vertex shader storage. * */
    private ByteBuffer vertexShader;

    /** Our fragment shader storage. * */
    private ByteBuffer fragmentShader;

    /** Our program ID. * */
    private int programID;

    /**
     * Print some log infos on shader processing.
     */
    public void printLogInfo(int obj)
    {
	IntBuffer iVal = BufferUtils.createIntBuffer(1);
	ARBShaderObjects.glGetObjectParameterARB(obj, ARBShaderObjects.GL_OBJECT_INFO_LOG_LENGTH_ARB, iVal);

	int length = iVal.get();
	if (length > 1)
	{
	    // We have some info we need to output.
	    ByteBuffer infoLog = BufferUtils.createByteBuffer(length);

	    iVal.flip();
	    ARBShaderObjects.glGetInfoLogARB(obj, iVal, infoLog);

	    byte[] infoBytes = new byte[length];
	    infoLog.get(infoBytes);
	    String out = new String(infoBytes);

	    Log.write("Info log:\n" + out, Log.INFO);
	}
	Util.checkGLError();
    }

    private ByteBuffer loadProgram(String fileName)
    {
	if (fileName == null || fileName.equals(""))
	{
	    return null;
	}
	name = new String(fileName);
	fileName = Settings.SHADERDIR + fileName;

	FileIO pf = new FileIO();
	String code = pf.openAndReadFile(fileName);
	if (code == null)
	{
	    Log.write("shader " + fileName + " not found.", Log.ERROR);
	    return null;
	}

	if (code.getBytes() != null)
	{
	    ByteBuffer buf = BufferUtils.createByteBuffer(code.getBytes().length); // code.length());

	    buf.put(code.getBytes());
	    buf.flip();
	    return buf;
	} else
	{
	    return null;
	}
    }

    public boolean loadPrograms(String vert, String frag)
    {
	if (Settings.GLSLSupported == false)
	{
	    return false;
	}

	if (vert == null)
	{
	    vert = "";
	}

	// jos ohjelat on jo ladattu ja k��nnetty, aseta vain ohjelman ID
	if (programs.containsKey(vert + frag))
	{
	    programID = (Integer) programs.get(vert + frag);
	    return true;
	}

	vertexShader = loadProgram(vert);
	fragmentShader = loadProgram(frag);

	// jos ei l�ytynyt shadereit
	if (vertexShader == null && fragmentShader == null)
	{
	    return false;
	}

	// Create the shaders objects.
	int vertexShaderID = ARBShaderObjects.glCreateShaderObjectARB(ARBVertexShader.GL_VERTEX_SHADER_ARB);
	int fragmentShaderID = ARBShaderObjects.glCreateShaderObjectARB(ARBFragmentShader.GL_FRAGMENT_SHADER_ARB);

	// Load source code strings into shaders.
	if (vertexShader != null)
	{
	    ARBShaderObjects.glShaderSourceARB(vertexShaderID, vertexShader);
	}
	if (fragmentShader != null)
	{
	    ARBShaderObjects.glShaderSourceARB(fragmentShaderID, fragmentShader);
	}

	// Compile the shaders.
	if (vertexShader != null)
	{
	    ARBShaderObjects.glCompileShaderARB(vertexShaderID);
	    printLogInfo(vertexShaderID);
	}
	if (fragmentShader != null)
	{
	    ARBShaderObjects.glCompileShaderARB(fragmentShaderID);
	    printLogInfo(fragmentShaderID);
	}

	// Create a program object and attach the two compiled shaders.
	programID = ARBShaderObjects.glCreateProgramObjectARB();
	if (vertexShader != null)
	{
	    ARBShaderObjects.glAttachObjectARB(programID, vertexShaderID);
	}
	if (fragmentShader != null)
	{
	    ARBShaderObjects.glAttachObjectARB(programID, fragmentShaderID);
	}
	ARBShaderObjects.glLinkProgramARB(programID);
	printLogInfo(programID);

	programs.put(vert + frag, programID);

	return true;
    }

    // tarkistaa tuetaanko glsl:��. pit�� kutsua ekana
    public void bind()
    {
	if (Settings.GLSLSupported == false)
	{
	    return;
	}
	if (programID == -1 || curProgramID == programID)
	{
	    return;
	}

	// Bind the shader.
	ARBShaderObjects.glUseProgramObjectARB(programID);
	curProgramID = programID;
    }

    public static void unbind()
    {
	if (Settings.GLSLSupported == false)
	{
	    return;
	}

	curProgramID = -1;
	ARBShaderObjects.glUseProgramObjectARB(0);
    }

    private static ByteBuffer byteBuffer(String str)
    {
	int length = str.length() + 1;

	ByteBuffer buff = BufferUtils.createByteBuffer(length);
	buff.put(str.getBytes());

	buff.put((byte) 0);

	buff.flip();
	return buff;
    }

    /**
     * Get an uniform variable location.
     */
    public static int getUniLoc(int program, String name)
    {
	return ARBShaderObjects.glGetUniformLocationARB(program, byteBuffer(name));
    }

    public static int getAttrLoc(int program, String name)
    {
	return ARBVertexShader.glGetAttribLocationARB(program, byteBuffer(name));
    }

    public void setUniform(String paramName, float[] params, int[] iparams)
    {
	if (Settings.GLSLSupported == false)
	{
	    return;
	}

	// Set up initial uniform values
	if (params != null)
	{
	    switch (params.length)
	    {
	    case 1:
		ARBShaderObjects.glUniform1fARB(getUniLoc(programID, paramName), params[0]);
		break;
	    case 2:
		ARBShaderObjects.glUniform2fARB(getUniLoc(programID, paramName), params[0], params[1]);
		break;
	    case 3:
		ARBShaderObjects.glUniform3fARB(getUniLoc(programID, paramName), params[0], params[1], params[2]);
		break;
	    case 4:
		ARBShaderObjects.glUniform4fARB(getUniLoc(programID, paramName), params[0], params[1], params[2], params[3]);
		break;
	    }
	} else
	{
	    switch (iparams.length)
	    {
	    case 1:
		ARBShaderObjects.glUniform1iARB(getUniLoc(programID, paramName), iparams[0]);
		break;
	    case 2:
		ARBShaderObjects.glUniform2iARB(getUniLoc(programID, paramName), iparams[0], iparams[1]);
		break;
	    case 3:
		ARBShaderObjects.glUniform3iARB(getUniLoc(programID, paramName), iparams[0], iparams[1], iparams[2]);
		break;
	    case 4:
		ARBShaderObjects.glUniform4iARB(getUniLoc(programID, paramName), iparams[0], iparams[1], iparams[2], iparams[3]);
		break;
	    }
	}

    }

    public void setAttribute(String paramName, float[] params)
    {
	if (Settings.GLSLSupported == false)
	{
	    return;
	}

	if (params != null)
	{
	    switch (params.length)
	    {
	    case 1:
		ARBVertexShader.glVertexAttrib1fARB(getAttrLoc(programID, paramName), params[0]);
		break;
	    case 2:
		ARBVertexShader.glVertexAttrib2fARB(getAttrLoc(programID, paramName), params[0], params[1]);
		break;
	    case 3:
		ARBVertexShader.glVertexAttrib3fARB(getAttrLoc(programID, paramName), params[0], params[1], params[2]);
		break;
	    case 4:
		ARBVertexShader.glVertexAttrib4fARB(getAttrLoc(programID, paramName), params[0], params[1], params[2], params[3]);
		break;
	    }
	}
    }
}
