/**
 * @file SkyBox.java
 * 
 * @author mjt, 2007-08
 * mixut@hotmail.com
 * 
 */
package jsat;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL12.*;

import java.io.IOException;

public class SkyBox
{
    Object3D skybox;

    // lataa skybox
    public void load(String skyName, String ext) throws IOException
    {
        // lataa skybox
	skybox = new Object3D("skybox", "skybox.obj", 10f, 10f, 10f, false);

	final String[] side = { "right", "left", "top", "bottom", "front", "back" };

	for (int q = 0; q < 6; q++)
	{
	    String fileName = skyName + side[q] + "." + ext;
	    Texture skytex = new Texture(Settings.TEXTUREDIR + fileName);

	    // aseta ladattu texture oikeaan sivuun
	    for (int w = 0; w < 6; w++)
	    {

		if (skybox.getMesh(w).getTexture(0).getName().contains(side[q]))
		{
		    skybox.getMesh(w).setTexture(0, skytex);
		    break;
		}
	    }

	    // k�ytet��n clamp to edge jolloin negatiivisia uv arvoi ei voi olla. kuitenkin lataus
	    // k��nt�� v-arvon negatiiviseksi, se pit�� nyt k��nt��..
	    for (int w = 0; w < skybox.getMesh(q).uv.length; w++)
	    {
		skybox.getMesh(q).uv[w].y *= -1; // k��nn� positiiviseksi
		skybox.getMesh(q).uv[w].y = 1 - skybox.getMesh(q).uv[w].y; // k��nn� yl�salaisin
	    }
	    skybox.getMesh(q).setTextureCoords(0, skybox.getMesh(q).uv);

	    skytex.bind(0);
	    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	}

    }

    public void render(Camera cam)
    {
	glLoadIdentity();
	glRotatef(-cam.getRotation().x, 1.0f, 0, 0);
	glRotatef(-cam.getRotation().y, 0, 1.0f, 0);
	glRotatef(-cam.getRotation().z, 0, 0, 1.0f);

	Light.disableLights();
	glDisable(GL_CULL_FACE);
	glDisable(GL_DEPTH_TEST);

	skybox.render();

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);
	Light.enableLights();

	glLoadIdentity();
    }
}
