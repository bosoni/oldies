/**
 * @file ObjectInfo.java
 *
 * @author mjt, 2007-08
 * mixut@hotmail.com
 *
 */
/*
 *
 * Vector3f position;   paikka parentista
 * Vector3f worldSpacePosition;  paikka 3d-avaruudessa, laskettu parentista
 *
 * jos objektilla ei ole parenttia (tai objekti ei ole klooni), position==worldSpacePosition.
 *
 * render() metodeissa k�ytet��n getPosition() paikan saamiseksi, koska silloin lis�t��n paikka
 * aina parentin paikkaan.
 * muissa metodeissa joissa tarvitaan objektin oikeata paikkaa 3d-avaruduessa, k�ytet��n getWorldSpacePosition.
 *
 *
 *
 */
package jsat;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.util.glu.GLU;
import org.lwjgl.util.vector.Vector3f;
import static org.lwjgl.opengl.GL11.*;
import org.lwjgl.util.vector.Matrix4f;

public abstract class ObjectInfo
{
    final static int OBJECT = 1;

    final static int ANIM = 2;

    final static int LIGHT = 3;

    final static int CAMERA = 4;

    final static int BILLBOARD = 5;

    final static int IMAGE = 6;

    final static int PROJ = 7;

    /**
     * objektin nimi
     */
    protected String name = "";

    public ObjectInfo(String _name)
    {
	name = _name;
    }

    public Matrix4f matrix = null;

    protected static FloatBuffer fbuffer = BufferUtils.createFloatBuffer(16);

    /**
     * palauttaa objektin tyypin
     */
    private int objType = 0;

    public int getType()
    {
	return objType;
    }

    /**
     * aseta tyyppi
     */
    public void setType(int type)
    {
	objType = type;
    }

    /**
     * valmiiksi laskettu p/180
     */
    private final float PIOVER180 = 0.0174532925f;

    /**
     * Jos 3d objekti, t�m� m��r�� tekeek� varjon
     */
    private boolean castShadow = true;

    public boolean castShadow()
    {
	return castShadow;
    }

    /**
     * paikkabufferi
     */
    static private FloatBuffer posBuffer = BufferUtils.createFloatBuffer(4);

    /**
     * objektin paikka
     */
    private Vector3f position = new Vector3f(0, 0, 0);

    private Vector3f worldSpacePosition = position;

    /**
     * suuntavektori
     */
    private Vector3f front = new Vector3f(0, 0, -1);

    private Vector3f up = new Vector3f(0, 1, 0);

    private Vector3f right = new Vector3f(1, 0, 0);

    // asento
    private Vector3f rotation = new Vector3f(0, 0, 0);

    /**
     * jos true, objekti on n�kyviss�
     */
    protected boolean visible = true;

    public void translate()
    {
	glTranslatef(position.x, position.y, position.z);
    }

    public void rotate()
    {
	if (matrix == null)
	{
	    glRotatef(rotation.x, 1, 0, 0);
	    glRotatef(rotation.y, 0, 1, 0);
	    glRotatef(rotation.z, 0, 0, 1);
	} else
	{
	    fbuffer.clear();

	    fbuffer.put(matrix.m00);
	    fbuffer.put(matrix.m10);
	    fbuffer.put(matrix.m20);
	    fbuffer.put(matrix.m30);
	    fbuffer.put(matrix.m01);
	    fbuffer.put(matrix.m11);
	    fbuffer.put(matrix.m21);
	    fbuffer.put(matrix.m31);
	    fbuffer.put(matrix.m02);
	    fbuffer.put(matrix.m12);
	    fbuffer.put(matrix.m22);
	    fbuffer.put(matrix.m32);
	    fbuffer.put(matrix.m03);
	    fbuffer.put(matrix.m13);
	    fbuffer.put(matrix.m23);
	    fbuffer.put(matrix.m33);

	    fbuffer.flip();
	    glMultMatrix(fbuffer);
	}
    }

    /**
     * palauttaa worldspace paikan bufferin
     * 
     * @return paikka FloatBufferina
     */
    public FloatBuffer getWSPositionBuffer()
    {
	posBuffer.clear();

	float[] buf = { worldSpacePosition.x, worldSpacePosition.y, worldSpacePosition.z, 1 };

	posBuffer.put(buf).flip();

	return posBuffer;
    }

    public void render()
    {
    }

    /**
     * k��nn� y-akselin ymp�ri
     */
    public void turnXZ(float f)
    {
	rotation.y -= f;
    }

    /**
     * k��nn� x-akselin ymp�ri
     */
    public void upDownXZ(float f)
    {
	rotation.x -= f;
    }

    /**
     * k��nn� z-akselin ymp�ri
     */
    public void rollXZ(float f)
    {
	rotation.z -= f;
    }

    public void moveXZ(float forward, float strafe)
    {
	if (forward != 0)
	{
	    moveXZ(forward);
	}
	if (strafe != 0)
	{
	    strafeXZ(strafe);
	}
    }

    /**
     * liikuta objektia xz tasossa
     * 
     * @param f
     *                paljonko liikutaan eteen/taaksep�in
     */
    public void moveXZ(float f)
    {
	position.x -= ((float) Math.sin(rotation.y * PIOVER180) * f);
	position.z -= ((float) Math.cos(rotation.y * PIOVER180) * f);
    }

    /**
     * liikuta xz-tasossa
     * 
     * @param f
     *                paljonko liikutaan sivuttais suunnassa
     */
    public void strafeXZ(float f)
    {
	position.x += ((float) Math.cos(-rotation.y * PIOVER180) * f);
	position.z += ((float) Math.sin(-rotation.y * PIOVER180) * f);
    }

    /**
     * Metodit t�ysin vapaaseen liikkumiseen
     * 
     */
    /**
     * eteenp�in/taaksep�in f/-f
     */
    public void moveForward(float f)
    {
	Vector3f tmp = new Vector3f(front);
	tmp.scale(-f);

	Vector3f.add(tmp, position, position);
    }

    public void rotateX(float f)
    {
	rotation.x -= f;
	front.scale((float) Math.cos(f * PIOVER180));
	up.scale((float) Math.sin(f * PIOVER180));

	Vector3f.add(front, up, front);
	front.normalise();

	Vector3f.cross(front, right, up);
	up.negate();
    }

    public void rotateY(float f)
    {
	rotation.y -= f;
	front.scale((float) Math.cos(f * PIOVER180));
	right.scale((float) Math.sin(f * PIOVER180));

	Vector3f.sub(front, right, front);
	front.normalise();

	Vector3f.cross(front, up, right);
    }

    public void rotateZ(float f)
    {
	rotation.z -= f;
	right.scale((float) Math.cos(f * PIOVER180));
	up.scale((float) Math.sin(f * PIOVER180));

	Vector3f.add(right, up, right);
	right.normalise();

	Vector3f.cross(front, right, up);
	up.negate();
    }

    public void strafeRight(float f)
    {
	Vector3f tmp = new Vector3f(right);
	tmp.scale(f);
	Vector3f.add(tmp, position, position);
    }

    public void moveUp(float f)
    {
	Vector3f tmp = new Vector3f(up);
	tmp.scale(f);
	Vector3f.add(tmp, position, position);
    }

    public void addPosition(float x, float y, float z)
    {
	position.x += x;
	position.y += y;
	position.z += z;
    }

    public void setPosition(Vector3f pos)
    {
	position = pos;
	worldSpacePosition = position;
    }

    public void setRotation(Vector3f rot)
    {
	rotation = rot;
    }

    public void setPosition(float x, float y, float z)
    {
	position.x = x;
	position.y = y;
	position.z = z;
    }

    public Vector3f getPosition()
    {
	return position;
    }

    public void addRotation(float x, float y, float z)
    {
	rotation.x += x;
	rotation.y += y;
	rotation.z += z;
    }

    public void setRotation(float x, float y, float z)
    {
	rotation.x = x;
	rotation.y = y;
	rotation.z = z;
    }

    public Vector3f getRotation()
    {
	return rotation;
    }

    public Vector3f getWorldSpacePosition()
    {
	return worldSpacePosition;
    }

    void setWorldSpacePosition(float x, float y, float z)
    {
	worldSpacePosition.x = x;
	worldSpacePosition.y = y;
	worldSpacePosition.z = z;
    }

    void setWorldSpacePosition(Vector3f rp)
    {
	worldSpacePosition = rp;
    }

    public Vector3f getView()
    {
	return front;
    }

    public Vector3f getUp()
    {
	return up;
    }

    public Vector3f childRot = new Vector3f(0, 0, 0);

    public Vector3f rotateObject = new Vector3f(0, 0, 0);

    public void rotateObject()
    {
	glRotatef(rotateObject.x, 1, 0, 0);
	glRotatef(rotateObject.y, 0, 1, 0);
	glRotatef(rotateObject.z, 0, 0, 1);
    }

    Vector3f looking = null;

    /**
     * k��nt�� objektin katsomaan target:iin
     */
    public void lookAt(Vector3f target)
    {
	looking = target;
    }

    // ----------------------selection code-----------------
    public static void getMatrixAsArray(FloatBuffer fb, float[][] fa)
    {
	fa[0][0] = fb.get();
	fa[0][1] = fb.get();
	fa[0][2] = fb.get();
	fa[0][3] = fb.get();
	fa[1][0] = fb.get();
	fa[1][1] = fb.get();
	fa[1][2] = fb.get();
	fa[1][3] = fb.get();
	fa[2][0] = fb.get();
	fa[2][1] = fb.get();
	fa[2][2] = fb.get();
	fa[2][3] = fb.get();
	fa[3][0] = fb.get();
	fa[3][1] = fb.get();
	fa[3][2] = fb.get();
	fa[3][3] = fb.get();
    }

    public static int buffer[] = new int[512];
    public static IntBuffer viewpbuf = ByteBuffer.allocateDirect(64).order(ByteOrder.nativeOrder()).asIntBuffer();
    public static IntBuffer selbuf = ByteBuffer.allocateDirect(2048).order(ByteOrder.nativeOrder()).asIntBuffer();
    public static ByteBuffer pixel = ByteBuffer.allocateDirect(4).order(ByteOrder.nativeOrder());
    public static int selectedObj = -1;

    /**
     * asettaa selectedObj sen objektin joka on xy ruutu koordinaateissa.
     * 
     * t�m� tapa renderoi objektit ensin eri v�reill�, tarkistaa sitten
     * v�rin ja ottaa selectedObj:n.
     * 
     * testasin ett� toimi oikein 16 ja 32bit moodeissa, luin ett� arvot
     * voivat muuttua riippuen pixelipakkauksesta?
     */
    public static void getSelection(float x, float y)
    {
	selectedObj = -1;
	BaseGame.selectMode = 1;

	viewpbuf.clear();
	viewpbuf.order();

	glGetInteger(GL_VIEWPORT, viewpbuf);

	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();

	// This Creates A Matrix That Will Zoom Up To A Small Portion Of The
	// Screen, Where The Mouse Is.
	GLU.gluPickMatrix(x, y, 1.0f, 1.0f, viewpbuf);
	GLU.gluPerspective(BaseGame.fov, BaseGame.mode.getWidth() / BaseGame.mode.getHeight(), BaseGame.nearClipping, BaseGame.farClipping);

	glMatrixMode(GL_MODELVIEW);

	// renderoi skene ilman textureita. joka objekti eri v�rill�
	Light.disableLights();
	glDisable(GL_TEXTURE_2D);
	BaseGame.renderTextures(false);
	// Frustum.calculateFrustum();
	BaseGame.world.render();
	BaseGame.renderTextures(true);
	glEnable(GL_TEXTURE_2D);
	Light.enableLights();

	glMatrixMode(GL_PROJECTION);
	glPopMatrix();

	glMatrixMode(GL_MODELVIEW);
	glFlush();

	// tarkista mink�v�rinen objekti valittu (se on objektin id)
	glReadPixels(1, 1, 1, 1, GL_RGB, GL_UNSIGNED_BYTE, pixel);

	int obj = (pixel.get(0) << 16) + (pixel.get(1) << 8) + pixel.get(2);
	if (obj > 0)
	{
	    selectedObj = obj - 1;
	}

	glClear(Settings.CLEARBUFFERS);
	BaseGame.selectMode = 0;

	if (Settings.DEBUG)
	{
	    Log.write(">> " + pixel.get(0) + " " + pixel.get(1) + " " + pixel.get(2) + " " + pixel.get(3) + " " + " ::: " + obj);
	}
    }

    /**
     * asettaa selectedObj sen objektin joka on xy ruutu koordinaateissa.
     * 
     * t�m� tapa renderoi objektit select-bufferiin ja opengl palauttaa
     * kaikkien leikkausten z-arvot.
     * 
     * muuten ok (luulisin) mutta atin uusilla ajureilla meni _todella_
     * hitaaksi!
     */
    public static void getSelection_2(float x, float y)
    {
	BaseGame.selectMode = 2;

	viewpbuf.clear();
	viewpbuf.order();

	glGetInteger(GL_VIEWPORT, viewpbuf);

	selbuf.clear();
	glSelectBuffer(selbuf); // Tell OpenGL To Use Our Array For Selection

	// Puts OpenGL In Selection Mode. Nothing Will Be Drawn. Object ID's and
	// Extents Are Stored In The Buffer.
	glRenderMode(GL_SELECT);

	glInitNames();
	glPushName(-1);

	glMatrixMode(GL_PROJECTION); // Selects The Projection Matrix
	glPushMatrix(); // Push The Projection Matrix
	glLoadIdentity(); // Resets The Matrix

	// This Creates A Matrix That Will Zoom Up To A Small Portion Of The
	// Screen, Where The Mouse Is.
	GLU.gluPickMatrix(x, y, 1.0f, 1.0f, viewpbuf);

	GLU.gluPerspective(BaseGame.fov, BaseGame.mode.getWidth() / BaseGame.mode.getHeight(), BaseGame.nearClipping, BaseGame.farClipping);

	glMatrixMode(GL_MODELVIEW); // Select The Modelview Matrix

	glDisable(GL_TEXTURE_2D);
	BaseGame.renderTextures(false);
	// Frustum.calculateFrustum();
	BaseGame.world.render();
	BaseGame.renderTextures(true);
	glEnable(GL_TEXTURE_2D);
	// 6.1.08 atin uusilla ajureilla t�m� tuli sairaan hitaaksi. vaihto
	// v�ritsekkauskoodiin

	glMatrixMode(GL_PROJECTION); // Select The Projection Matrix
	glPopMatrix(); // Pop The Projection Matrix

	glMatrixMode(GL_MODELVIEW); // Select The Modelview Matrix
	glFlush();

	int hits = glRenderMode(GL_RENDER); // Switch To Render Mode, Find
	// Out How Many Objects Were
	// Drawn Where The Mouse Was
	selbuf.get(buffer);

	if (hits > 0) // If There Were More Than 0 Hits
	{
	    selectedObj = (int) buffer[3]; // Make Our Selection The First
	    // Object
	    int depth = (int) buffer[1]; // Store How Far Away It Is
	    for (int i = 1; i < hits; i++) // Loop Through All The Detected
	    // Hits
	    {
		// If This Object Is Closer To Us Than The One We Have Selected
		if (buffer[i * 4 + 1] < (int) depth)
		{
		    selectedObj = (int) buffer[i * 4 + 3]; // Select The
		    // Closer Object
		    depth = (int) buffer[i * 4 + 1]; // Store How Far Away It
		    // Is
		}
	    }
	} else
	{
	    selectedObj = -1;
	}

	BaseGame.selectMode = 0;

    }
}
