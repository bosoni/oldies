/**
 * @file Make3DObject.java
 *
 * @author mjt, 2007-08
 * mixut@hotmail.com
 *
 */
// tekee 3d objekteja kun annetaan 2d vertexej� lathelle tai extrudelle.
// luo jokaisen vertexin v�liin kolmion. s��st�isi muistia jos loisi
// faceindex taulukot paremmin.
/*
 rad = angle * PI / 18b0
 angle = rad* 180 / PI
 */
package jsat;

import java.util.Vector;
import org.lwjgl.util.vector.Vector3f;

/**
 * luo 3d-malleja extruden ja lathen avulla
 */
public class Make3DObject
{
    /*
     * py�r�yt� vert taulukossa olevat arvot y-akselin ymp�ri ja segments
     * m��r�� kuinka "py�re�" objektista tulee (3 on minimi, vain 3 kulmaa)
     * pisteet pit�� olla xy tasossa, z=0.
     */
    public static Object3D lathe(Vector3f[] vert, int segments)
    {
	int numPoints = vert.length;
	if (segments < 3)
	{
	    Log.write("lathe: segment==" + segments + " (3 minimi)", Log.ERROR);
	    return null;
	}

	Vector3f[][] vrt = new Vector3f[numPoints][segments];

	int q = 0, w = 0;

	// rad = angle * PI / 180
	// angle = rad* 180 / PI
	float step = ((float) (360 / (float) segments));
	float ang = 0;

	// laske pisteiden paikat
	for (q = 0; q < numPoints; q++)
	{
	    // kulmat l�pi, lasketaan vertexeille x ja z (y otetaan
	    // taulukosta)
	    for (w = 0; w < segments; w++)
	    {
		float angrad = ang * (float) Math.PI / 180;
		ang += step;

		float x = (float) Math.sin(angrad) * vert[q].x;
		float z = (float) Math.cos(angrad) * vert[q].x;
		float y = vert[q].y;

		vrt[q][w] = new Vector3f();
		vrt[q][w].x = x;
		vrt[q][w].y = y;
		vrt[q][w].z = z;
	    }
	}

	// luo pisteiden v�lille polygonit
	Vector<Vector3f> v = new Vector<Vector3f>();
	for (q = 0; q < numPoints - 1; q++)
	{
	    // kulmat l�pi, lasketaan vertexeille x ja z (y otetaan
	    // taulukosta)
	    for (w = 0; w < segments; w++)
	    {
		int i = (w + 1) % segments;
		v.add(vrt[q][w]);
		v.add(vrt[q][i]);
		v.add(vrt[q + 1][i]);

		v.add(vrt[q][w]);
		v.add(vrt[q + 1][i]);
		v.add(vrt[q + 1][w]);
	    }
	}

	Object3D obj = new Object3D("latheobj");
	Mesh mesh = new Mesh();
	// face indexit --
	int faceIndex = 0;
	mesh.faces = new int[v.size() / 3][3];
	for (q = 0; q < v.size(); q += 3)
	{
	    mesh.faces[faceIndex][0] = q;
	    mesh.faces[faceIndex][2] = q + 1;
	    mesh.faces[faceIndex][1] = q + 2;
	    faceIndex++;
	}

	mesh.vertex = new Vector3f[v.size()];
	for (q = 0; q < v.size(); q++)
	{
	    mesh.vertex[q] = v.get(q);
	}

	mesh.vertexNormals = new Vector3f[v.size()];
	Geometry.calcNormals(mesh.vertex, mesh.faces, mesh.vertexNormals, false);

	mesh.boundings.setup(mesh.vertex, mesh.faces, BoundingArea.SPHERE);
	mesh.createBuffers(mesh.vertex, mesh.faces, mesh.vertexNormals, null, true);

	obj.addMesh(mesh);

	return obj;
    }

    /**
     * luo 3d objekti pisteist� (vain convex polyt) annetaan xy tasossa
     * vertexit jotka "nostetaan" len matkan.
     */
    public static Object3D extrude(Vector3f[] vert, float len, boolean caps)
    {
	Object3D obj = new Object3D("extobj");

	int numVerts = vert.length;
	if (numVerts < 3)
	{
	    Log.write("extrude: liian v�h�n vertexej�", Log.ERROR);
	    return null;
	}

	Vector<Vector3f> v = new Vector<Vector3f>();
	Mesh mesh = new Mesh();
	int faceIndex = 0;

	// tee vert taulukosta kolmioita (pit�� olla convex polygon)
	if (caps)
	{
	    int a = 1, b;
	    for (int q = 0; q < numVerts - 2; q++)
	    {
		// vertex 0 tulee jokaiseen kolmioon
		v.add(new Vector3f(vert[0]));

		// pist� 2 vertexi�
		for (b = a + 1; b >= a; b--)
		{
		    v.add(new Vector3f(vert[b]));
		}

		// sulje my�s toinen p��
		v.add(new Vector3f(vert[0]));
		v.get(v.size() - 1).z = len;
		for (b = a; b < a + 2; b++)
		{
		    v.add(new Vector3f(vert[b]));
		    v.get(v.size() - 1).z = len;
		}

		a++;
	    }
	}

	// tee reunat
	for (int q = 0; q < numVerts; q++)
	{
	    int w = (q + 1) % numVerts;

	    // eka kolmio
	    v.add(new Vector3f(vert[q]));
	    v.add(new Vector3f(vert[w]));
	    v.add(new Vector3f(vert[w]));
	    v.get(v.size() - 1).z = len;

	    // toinen kolmio
	    v.add(new Vector3f(vert[q]));
	    v.add(new Vector3f(vert[w]));
	    v.get(v.size() - 1).z = len;
	    v.add(new Vector3f(vert[q]));
	    v.get(v.size() - 1).z = len;
	}

	// face indexit --
	mesh.faces = new int[v.size() / 3][3];
	for (int q = 0; q < v.size(); q += 3)
	{
	    mesh.faces[faceIndex][0] = q;
	    mesh.faces[faceIndex][2] = q + 1;
	    mesh.faces[faceIndex][1] = q + 2;
	    faceIndex++;
	}

	mesh.vertex = new Vector3f[v.size()];
	for (int q = 0; q < v.size(); q++)
	{
	    mesh.vertex[q] = v.get(q);
	}

	mesh.vertexNormals = new Vector3f[v.size()];
	Geometry.calcNormals(mesh.vertex, mesh.faces, mesh.vertexNormals, false);

	mesh.boundings.setup(mesh.vertex, mesh.faces, BoundingArea.SPHERE);
	mesh.createBuffers(mesh.vertex, mesh.faces, mesh.vertexNormals, null, true);
	obj.addMesh(mesh);

	return obj;
    }

    /**
     * palauttaa laatikko objektin
     */
    public static Object3D box(Vector3f size)
    {
	float sx = size.x * 0.5f;
	float sy = size.y * 0.5f;
	float sz = size.z * 0.5f;

	if (sy != 0)
	{
	    float t = sy;
	    sy = sz;
	    sz = t;
	}

	Vector3f[] vert = new Vector3f[4];
	vert[3] = new Vector3f(-sx, -sy, -sz);
	vert[2] = new Vector3f(sx, -sy, -sz);
	vert[1] = new Vector3f(sx, sy, -sz);
	vert[0] = new Vector3f(-sx, sy, -sz);
	return Make3DObject.extrude(vert, sz, true);
    }

    /**
     * palauttaa pallo objektin size anna xy skaalaus u, v : tarkkuus
     */
    public static Object3D sphere(Vector3f size, int u, int v)
    {
	// laske puoliympyr�n muoto vr taulukkoon
	float step = ((float) (180 / (float) v + 2));
	float ang = 0;
	Vector3f[] vr = new Vector3f[v];
	for (int q = 0; q < v; q++)
	{
	    float angrad = ang * (float) Math.PI / 180;
	    ang += step;

	    float x = (float) Math.sin(angrad) * size.x;
	    float y = (float) Math.cos(angrad) * size.y;

	    vr[q] = new Vector3f(x, y, 0);
	}

	return lathe(vr, u);

    }
}
