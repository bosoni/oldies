/**
 * @file Colorf.java
 *
 * @author mjt, 2007
 * mixut@hotmail.com
 *
 */
package jsat;

import java.nio.FloatBuffer;
import org.lwjgl.BufferUtils;

public class Colorf
{
    static protected FloatBuffer colorBuffer = BufferUtils.createFloatBuffer(4);

    public float r = 1;

    public float g = 1;

    public float b = 1;

    public float a = 1;

    public Colorf(Colorf col)
    {
	setColor(col.r, col.g, col.b, col.a);
    }

    public Colorf(float _r, float _g, float _b, float _a)
    {
	setColor(_r, _g, _b, _a);
    }

    public Colorf(float _r, float _g, float _b)
    {
	setColor(_r, _g, _b);
    }

    public void setColor(float _r, float _g, float _b, float _a)
    {
	r = _r;
	g = _g;
	b = _b;
	a = _a;
    }

    public void setColor(float _r, float _g, float _b)
    {
	r = _r;
	g = _g;
	b = _b;
    }

    public FloatBuffer getBuffer()
    {
	float[] buf = { r, g, b, a };
	colorBuffer.put(buf).flip();

	return colorBuffer;
    }

    public float[] getArray()
    {
	float[] ret = { r, g, b, a };

	return ret;
    }
}
