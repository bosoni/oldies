/**
 * @file Mesh.java
 *
 * @author mjt, 2007-08
 * mixut@hotmail.com
 * 
 */
package jsat;

import java.nio.FloatBuffer;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;

/**
 * meshin datat
 */
public class Mesh extends Geometry
{
    public String name = null; // objektin nimi

    public Material material = new Material(); // materiaali

    public Vector3f vertex[];

    public Vector4f faceNormals[];

    public Vector3f vertexNormals[];

    public Vector2f[] uv; // texturekoordinaatit

    public int[][] faces = null; // face indexit

    public int[][] uvIndex = null; // uv index

    public int[][] normalIndex = null; // normaalien indexit

    public BoundingArea boundings = new BoundingArea();

    public ShadowVolumes shadow = null; // objektin varjo

    public GLSL shader = null;

    private boolean useShader = true;

    public void setEmission(Colorf col)
    {
	material.getMaterialInfo().emissionColor = col;
    }

    public void setDiffuse(Colorf col)
    {
	material.getMaterialInfo().diffuseColor = col;
    }

    public void setSpecular(Colorf col)
    {
	material.getMaterialInfo().specularColor = col;
    }

    public void useShader(boolean use)
    {
	useShader = use;
    }

    public void renderMesh()
    {
	if (BaseGame.renderTextures())
	{
	    
	    if (useShader && shader != null)
	    {
		shader.bind(); // shaderi k�ytt��n
	    } else
	    {
		material.useMaterial(); // tai materiaali
	    }
	}

	render();

	if (useShader && shader != null)
	{
	    GLSL.unbind();
	}
    }
}
