/**
 * @file MD5Anim.java
 *
 * java port by mjt, 2007-08
 *
 * based on
 * "md5mesh model loader + animation Copyright (c) 2005 David HENRY"
 * found at http://tfc.duke.free.fr/coding/md5-specs-en.html
 *
 * "THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE."
 *
 */
package jsat;

import java.io.*;
import java.util.StringTokenizer;
import java.io.IOException;
import org.lwjgl.util.vector.Vector3f;

public class MD5Anim
{
    public String name;

    private MD5Animation anim = new MD5Animation();

    private BaseFrameJoint[] baseFrame = null;

    static private int frameIndex = 0;

    AnimInfo animInfo = null;

    Joint[] skeleton = null;

    public MD5Anim(String _name)
    {
	name = _name;
    }

    public void update(final float dt)
    {
	if (anim == null)
	{
	    return;
	}

	// calculate current and next frames
	animate(anim, animInfo, dt);

	int kokluvut = (int) animInfo.currFrame;
	float interp = animInfo.currFrame - kokluvut;

	// interpolate skeletons between two frames
	interpolateSkeletons(anim.skelFrames[(int) animInfo.currFrame], anim.skelFrames[(int) animInfo.nextFrame], anim.numJoints, interp);
    }

    public void interpolateSkeletons(final Joint[] skelA, final Joint[] skelB, final int num_joints, final float interp)
    {
	int i;

	for (i = 0; i < num_joints; i++)
	{
	    // copy parent index *
	    skeleton[i].parent = skelA[i].parent;

	    // linear interpolation for position *
	    skeleton[i].pos.x = skelA[i].pos.x + (interp * (skelB[i].pos.x - skelA[i].pos.x));
	    skeleton[i].pos.y = skelA[i].pos.y + (interp * (skelB[i].pos.y - skelA[i].pos.y));
	    skeleton[i].pos.z = skelA[i].pos.z + (interp * (skelB[i].pos.z - skelA[i].pos.z));

	    // spherical linear interpolation for orientation *
	    skeleton[i].orient = Quaternion.quatSlerp(skelA[i].orient, skelB[i].orient, interp);
	}
    }

    public void animate(final MD5Animation anim, final AnimInfo animInfo, final float dt)
    {
	int maxFrames = anim.numFrames - 1;

	animInfo.currFrame += dt;
	animInfo.nextFrame = animInfo.currFrame + 1;
	{
	    if (animInfo.currFrame > maxFrames)
	    {
		animInfo.currFrame = 0;
	    }

	    if (animInfo.nextFrame > maxFrames)
	    {
		animInfo.nextFrame = 0;
	    }
	}
    }

    public void loadAnimation(String fileName) throws IOException
    {
	JointInfo[] jointInfos = null;
	int numAnimatedComponents = 0;
	float[] animFrameData = null;

	// avaa tiedosto
	File f = new File(Settings.DATADIR + fileName);
	BufferedReader in = new BufferedReader(new FileReader(f));

	int q;
	int w;

	while (true)
	{
	    // lue rivi
	    String rivi = in.readLine();

	    if (rivi == null)
	    {
		break;
	    }

	    // jos tyhj� rivi niin ei k�sitell�
	    if (rivi.equals(""))
	    {
		continue;
	    }

	    StringTokenizer st = new StringTokenizer(rivi);
	    String str = st.nextToken();

	    if (str.equals("numFrames"))
	    {
		anim.numFrames = Integer.parseInt(st.nextToken());

		// anim.bboxes = new BoundingBox[anim.numFrames]; // modelissa
		// on BoundingArea

		continue;
	    }

	    if (str.equals("numJoints"))
	    {
		anim.numJoints = Integer.parseInt(st.nextToken());

		anim.skelFrames = new Joint[anim.numFrames][anim.numJoints];

		jointInfos = new JointInfo[anim.numJoints];

		baseFrame = new BaseFrameJoint[anim.numJoints];

		continue;
	    }

	    if (str.equals("frameRate"))
	    {
		anim.frameRate = Integer.parseInt(st.nextToken());

		continue;
	    }

	    if (str.equals("numAnimatedComponents"))
	    {
		numAnimatedComponents = Integer.parseInt(st.nextToken());
		animFrameData = new float[numAnimatedComponents];

		continue;
	    }

	    if (str.equals("hierarchy"))
	    {
		for (q = 0; q < anim.numJoints; q++)
		{
		    rivi = in.readLine();
		    st = new StringTokenizer(rivi);

		    jointInfos[q] = new JointInfo();

		    jointInfos[q].name = st.nextToken();
		    jointInfos[q].parent = Integer.parseInt(st.nextToken());
		    jointInfos[q].flags = Integer.parseInt(st.nextToken());
		    jointInfos[q].startIndex = Integer.parseInt(st.nextToken());
		}

		continue;
	    }

	    if (str.equals("baseframe"))
	    {
		for (q = 0; q < anim.numJoints; q++)
		{
		    rivi = in.readLine();
		    st = new StringTokenizer(rivi);
		    st.nextToken();

		    baseFrame[q] = new BaseFrameJoint();

		    baseFrame[q].pos[0] = Float.parseFloat(st.nextToken());
		    baseFrame[q].pos[1] = Float.parseFloat(st.nextToken());
		    baseFrame[q].pos[2] = Float.parseFloat(st.nextToken());

		    st.nextToken();
		    st.nextToken();

		    baseFrame[q].orient.x = Float.parseFloat(st.nextToken());
		    baseFrame[q].orient.y = Float.parseFloat(st.nextToken());
		    baseFrame[q].orient.z = Float.parseFloat(st.nextToken());

		    baseFrame[q].orient.quatComputeW();
		}

		continue;
	    }

	    if (str.equals("frame"))
	    {
		frameIndex = Integer.parseInt(st.nextToken());

		for (q = 0; q < numAnimatedComponents;)
		{
		    rivi = in.readLine();
		    st = new StringTokenizer(rivi);

                    while(st.hasMoreTokens())
		    {
                        String ll=st.nextToken();
                        if(ll.equals("}")) { q=numAnimatedComponents; break; }
			animFrameData[q] = Float.parseFloat(ll);
                        q++;
		    }
		}

		for (q = 0; q < anim.numJoints; q++)
		{
		    anim.skelFrames[frameIndex][q] = new Joint();
		}

		// build frame skeleton from the collected data
		buildFrameSkeleton(jointInfos, baseFrame, animFrameData, anim.skelFrames[frameIndex], anim.numJoints);

		continue;
	    }

	    if (str.equals("bounds"))
	    {
		for (q = 0; q < anim.numFrames; q++)
		{
		    rivi = in.readLine();
		    st = new StringTokenizer(rivi);

		    st.nextToken();

		    // hypi bounding box infon yli
		    st.nextToken();
		    st.nextToken();
		    st.nextToken();
		    st.nextToken();
		    st.nextToken();
		    st.nextToken();
		    st.nextToken();
		    st.nextToken();

		    /*
		     * anim.bboxes[q] = new BoundingBox();
		     * anim.bboxes[q].min[0] =
		     * Float.parseFloat(st.nextToken());
		     * anim.bboxes[q].min[1] =
		     * Float.parseFloat(st.nextToken());
		     * anim.bboxes[q].min[2] =
		     * Float.parseFloat(st.nextToken()); st.nextToken();
		     * st.nextToken(); anim.bboxes[q].max[0] =
		     * Float.parseFloat(st.nextToken());
		     * anim.bboxes[q].max[1] =
		     * Float.parseFloat(st.nextToken());
		     * anim.bboxes[q].max[2] =
		     * Float.parseFloat(st.nextToken());
		     */
		}

		continue;
	    }
	}

	in.close();

	// allocate memory for animated skeleton
	skeleton = new Joint[anim.numJoints];

	for (q = 0; q < anim.numJoints; q++)
	{
	    skeleton[q] = new Joint();
	}

	animInfo = new AnimInfo();
	animInfo.currFrame = 0;
	animInfo.nextFrame = 1;
    }

    public void buildFrameSkeleton(final JointInfo[] jointInfos, final BaseFrameJoint[] baseFrame, final float[] animFrameData, Joint[] skelFrame,
	    final int num_joints)
    {
	int i;
	int j;

	for (i = 0; i < num_joints; ++i)
	{
	    Vector3f animatedPos = new Vector3f();
	    Quaternion animatedOrient = new Quaternion();

	    j = 0;

	    animatedPos.x = baseFrame[i].pos[0];
	    animatedPos.y = baseFrame[i].pos[1];
	    animatedPos.z = baseFrame[i].pos[2];

	    animatedOrient.set(baseFrame[i].orient);

	    if ((jointInfos[i].flags & 1) > 0) // Tx *
	    {
		animatedPos.x = animFrameData[jointInfos[i].startIndex + j];
		j++;
	    }

	    if ((jointInfos[i].flags & 2) > 0) // Ty *
	    {
		animatedPos.y = animFrameData[jointInfos[i].startIndex + j];
		j++;
	    }

	    if ((jointInfos[i].flags & 4) > 0) // Tz *
	    {
		animatedPos.z = animFrameData[jointInfos[i].startIndex + j];
		j++;
	    }

	    if ((jointInfos[i].flags & 8) > 0) // Qx *
	    {
		animatedOrient.x = animFrameData[jointInfos[i].startIndex + j];
		j++;
	    }

	    if ((jointInfos[i].flags & 16) > 0) // Qy *
	    {
		animatedOrient.y = animFrameData[jointInfos[i].startIndex + j];
		j++;
	    }

	    if ((jointInfos[i].flags & 32) > 0) // Qz *
	    {
		animatedOrient.z = animFrameData[jointInfos[i].startIndex + j];
		j++;
	    }

	    // compute orient quaternion's w value *
	    animatedOrient.quatComputeW();

	    /*
	     * NOTE: we assume that this joint's parent has already been
	     * calculated, i.e. joint's ID should never be smaller than its
	     * parent ID.
	     */
	    int parent = jointInfos[i].parent;
	    skelFrame[i].parent = parent;
	    skelFrame[i].name = jointInfos[i].name;

	    // jos ei oo parenttia, kopsaa datat vaa
	    if (skelFrame[i].parent < 0)
	    {
		skelFrame[i].pos = animatedPos;
		skelFrame[i].orient = animatedOrient;
	    } else
	    {
		// add positions
		Vector3f rpos = Quaternion.quatRotatePoint(skelFrame[parent].orient, animatedPos);
		skelFrame[i].pos.x = rpos.x + skelFrame[parent].pos.x;
		skelFrame[i].pos.y = rpos.y + skelFrame[parent].pos.y;
		skelFrame[i].pos.z = rpos.z + skelFrame[parent].pos.z;

		// concatenate rotations *
		skelFrame[i].orient = Quaternion.quatMultQuat(animatedOrient, skelFrame[parent].orient);
		skelFrame[i].orient = Quaternion.quatNormalize(skelFrame[i].orient);
	    }
	}
    }

    public boolean checkAnimValidity(final MD5Model mdl)
    {
	int i;

	// md5mesh and md5anim must have the same number of joints *
	if (mdl.numJoints() != anim.numJoints)
	{
	    return false;
	}

	// we just check with frame[0] *
	for (i = 0; i < mdl.numJoints(); i++)
	{
	    // joints must have the same parent index *
	    if (mdl.baseSkel.get(i).parent != anim.skelFrames[0][i].parent)
	    {
		return false;
	    }

	    // joints must have the same name *
	    if (mdl.baseSkel.get(i).name.equals(anim.skelFrames[0][i].name) == false)
	    {
		return false;
	    }
	}

	return true;
    }
}

// minimi ja maximi arvot vertexeille
final class BoundingBox
{
    float[] min = new float[3]; // xyz

    float[] max = new float[3];
}

// base frame joint
final class BaseFrameJoint
{
    float[] pos = new float[3];

    Quaternion orient = new Quaternion();
}

// joint info
final class JointInfo
{
    String name;

    int parent;

    int flags;

    int startIndex;
}

// animation data
final class MD5Animation
{
    int numFrames;

    int numJoints;

    int frameRate;

    Joint[][] skelFrames = null;
    // BoundingBox[] bboxes = null;
}

// animation info
final class AnimInfo
{
    float currFrame;

    float nextFrame;
}
