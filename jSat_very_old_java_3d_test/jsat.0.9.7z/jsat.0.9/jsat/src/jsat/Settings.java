/*/**
 * @file Settings.java
 *
 * @author mjt, 2007-08
 * mixut@hotmail.com
 *
 */
package jsat;

import static org.lwjgl.opengl.GL11.*;

public class Settings
{
    public static String TITLE = "";

    public static int width = 640, height = 480, bpp = 16;

    public static boolean fullScreen = false, vsync = false;

    public static int alphaBits = 8, zbufBits = 24, stencilBits = 8;

    public static int CLEARBUFFERS = GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT;

    public static String TEXTUREDIR = "data/texture/";

    public static String DATADIR = "data/data/";

    public static String FONTDIR = "data/font/";

    public static String SHADERDIR = "data/shader/";

    public static boolean texture3DSupported = false; // tuetaanko 3d-textureita

    public static boolean S3TCSupported = false;

    public static boolean GLSLSupported = false;

    public static boolean multiTexturingSupported = false; // jos true, multitexturointia tuetaan (vain
    // hyvin vanhat ajurit/kortit ei tue jolloin voi tulla ongelmia)

    public static boolean fboSupported = false; // true jos kortti tukee framebuffer objektia

    public static boolean useShadowMapping = false;
    public static boolean CUBEMAP = false;

    public static boolean VBO = false; // vertex buffer object

    public static boolean MIRRORED_REPEAT = false;
    
    //######################################
    public static boolean DEBUG = false; // ehk� n�ytt�� ylim��r�st infoo ruudulla
    public static boolean DISABLE_FBO = false; // jos true, ei k�ytet� fbo:ta vaikka kortti tukisikin
    public static boolean DISABLE_VBO = false; // jos true, ei k�ytet� vertex buffer objectia (vaan vertex arrayta)
    public static boolean GL10_11_12 = false; // jos opengl 1.0, 1.1 tai 1.2  niin true. asetetaan BaseGame:ssa

    /**
     * stencil varjostus
     */
    static boolean useShadowVolumes = false;
}
