/**
 * @file Frustum.java
 *
 * @author mjt, 2007
 * mixut@hotmail.com
 *
 * tutoriaali:
 * http://www.crownandcutlass.com/features/technicaldetails/frustum.html
 */
package jsat;

import static org.lwjgl.opengl.GL11.*;

public final class Frustum
{
    private static float[][] frustum = new float[6][4];

    private final static int RIGHT = 0, LEFT = 1, BOTTOM = 2, TOP = 3, BACK = 4, FRONT = 5;

    private static float[] proj = new float[16];

    private static float[] modl = new float[16];

    private static float[] clip = new float[16];

    private static void normalizePlane(float[][] frustum, int side)
    {
	float magnitude = (float) Math.sqrt((frustum[side][0] * frustum[side][0]) + (frustum[side][1] * frustum[side][1])
		+ (frustum[side][2] * frustum[side][2]));

	frustum[side][0] /= magnitude;
	frustum[side][1] /= magnitude;
	frustum[side][2] /= magnitude;
	frustum[side][3] /= magnitude;
    }

    public static void calculateFrustum()
    {
	Buffers.matrixModelView.clear();
	Buffers.matrixProjection.clear();

	// ota projection ja modelview matriisit
	glGetFloat(GL_PROJECTION_MATRIX, Buffers.matrixProjection);
	glGetFloat(GL_MODELVIEW_MATRIX, Buffers.matrixModelView);
	Buffers.matrixModelView.get(modl);
	Buffers.matrixProjection.get(proj);

	clip[0] = (modl[0] * proj[0]) + (modl[1] * proj[4]) + (modl[2] * proj[8]) + (modl[3] * proj[12]);
	clip[1] = (modl[0] * proj[1]) + (modl[1] * proj[5]) + (modl[2] * proj[9]) + (modl[3] * proj[13]);
	clip[2] = (modl[0] * proj[2]) + (modl[1] * proj[6]) + (modl[2] * proj[10]) + (modl[3] * proj[14]);
	clip[3] = (modl[0] * proj[3]) + (modl[1] * proj[7]) + (modl[2] * proj[11]) + (modl[3] * proj[15]);

	clip[4] = (modl[4] * proj[0]) + (modl[5] * proj[4]) + (modl[6] * proj[8]) + (modl[7] * proj[12]);
	clip[5] = (modl[4] * proj[1]) + (modl[5] * proj[5]) + (modl[6] * proj[9]) + (modl[7] * proj[13]);
	clip[6] = (modl[4] * proj[2]) + (modl[5] * proj[6]) + (modl[6] * proj[10]) + (modl[7] * proj[14]);
	clip[7] = (modl[4] * proj[3]) + (modl[5] * proj[7]) + (modl[6] * proj[11]) + (modl[7] * proj[15]);

	clip[8] = (modl[8] * proj[0]) + (modl[9] * proj[4]) + (modl[10] * proj[8]) + (modl[11] * proj[12]);
	clip[9] = (modl[8] * proj[1]) + (modl[9] * proj[5]) + (modl[10] * proj[9]) + (modl[11] * proj[13]);
	clip[10] = (modl[8] * proj[2]) + (modl[9] * proj[6]) + (modl[10] * proj[10]) + (modl[11] * proj[14]);
	clip[11] = (modl[8] * proj[3]) + (modl[9] * proj[7]) + (modl[10] * proj[11]) + (modl[11] * proj[15]);

	clip[12] = (modl[12] * proj[0]) + (modl[13] * proj[4]) + (modl[14] * proj[8]) + (modl[15] * proj[12]);
	clip[13] = (modl[12] * proj[1]) + (modl[13] * proj[5]) + (modl[14] * proj[9]) + (modl[15] * proj[13]);
	clip[14] = (modl[12] * proj[2]) + (modl[13] * proj[6]) + (modl[14] * proj[10]) + (modl[15] * proj[14]);
	clip[15] = (modl[12] * proj[3]) + (modl[13] * proj[7]) + (modl[14] * proj[11]) + (modl[15] * proj[15]);

	// laske frustumin tasot ja normalisoi ne
	frustum[RIGHT][0] = clip[3] - clip[0];
	frustum[RIGHT][1] = clip[7] - clip[4];
	frustum[RIGHT][2] = clip[11] - clip[8];
	frustum[RIGHT][3] = clip[15] - clip[12];
	normalizePlane(frustum, RIGHT);

	frustum[LEFT][0] = clip[3] + clip[0];
	frustum[LEFT][1] = clip[7] + clip[4];
	frustum[LEFT][2] = clip[11] + clip[8];
	frustum[LEFT][3] = clip[15] + clip[12];
	normalizePlane(frustum, LEFT);

	frustum[BOTTOM][0] = clip[3] + clip[1];
	frustum[BOTTOM][1] = clip[7] + clip[5];
	frustum[BOTTOM][2] = clip[11] + clip[9];
	frustum[BOTTOM][3] = clip[15] + clip[13];
	normalizePlane(frustum, BOTTOM);

	frustum[TOP][0] = clip[3] - clip[1];
	frustum[TOP][1] = clip[7] - clip[5];
	frustum[TOP][2] = clip[11] - clip[9];
	frustum[TOP][3] = clip[15] - clip[13];
	normalizePlane(frustum, TOP);

	frustum[BACK][0] = clip[3] - clip[2];
	frustum[BACK][1] = clip[7] - clip[6];
	frustum[BACK][2] = clip[11] - clip[10];
	frustum[BACK][3] = clip[15] - clip[14];
	normalizePlane(frustum, BACK);

	frustum[FRONT][0] = clip[3] + clip[2];
	frustum[FRONT][1] = clip[7] + clip[6];
	frustum[FRONT][2] = clip[11] + clip[10];
	frustum[FRONT][3] = clip[15] + clip[14];
	normalizePlane(frustum, FRONT);
    }

    // tasojen normaalit osoittaa sis��np�in joten jos testattava vertex on
    // kaikkien tasojen "edess�", se on ruudulla ja rendataan
    public static boolean pointInFrustum(float x, float y, float z)
    {
	// tasoyht�l�: A*x + B*y + C*z + D = 0
	// ABC on normaalin X, Y ja Z
	// D on tason et�isyys origosta
	// =0 vertex on tasolla
	// <0 tason takana
	// >0 tason edess�
	for (int a = 0; a < 6; a++)
	{
	    // jos vertex jonkun tason takana, niin palauta false (ei
	    // rendata)
	    if (((frustum[0][0] * x) + (frustum[0][1] * y) + (frustum[0][2] * z) + frustum[0][3]) <= 0)
	    {
		return false;
	    }
	}

	// ruudulla
	return true;
    }

    /**
     * palauttaa et�isyyden kameraan jos pallo frustumissa, muuten 0.
     */
    public static float sphereInFrustum(float x, float y, float z, float radius)
    {
	float d = 0;
	for (int p = 0; p < 6; p++)
	{
	    // jos pallo ei ole ruudulla
	    d = frustum[p][0] * x + frustum[p][1] * y + frustum[p][2] * z + frustum[p][3];
	    if (d <= -radius)
	    {
		return 0;
	    }
	}
	// kaikkien tasojen edess� eli n�kyviss�
	// palauta matka kameraan
	return d + radius;
    }

    /**
     * box testaus
     */
    public static boolean boxInFrustum(float x, float y, float z, BoundingArea bb)
    {
	int q;
	for (q = 0; q < 6; q++)
	{
	    if ((frustum[q][0] * (x + bb.min.x)) + (frustum[q][1] * (y + bb.min.y)) + (frustum[q][2] * (z + bb.min.z)) + frustum[q][3] > 0)
	    {
		continue;
	    }

	    if ((frustum[q][0] * (x + bb.max.x)) + (frustum[q][1] * (y + bb.min.y)) + (frustum[q][2] * (z + bb.min.z)) + frustum[q][3] > 0)
	    {
		continue;
	    }

	    if ((frustum[q][0] * (x + bb.max.x)) + (frustum[q][1] * (y + bb.min.y)) + (frustum[q][2] * (z + bb.max.z)) + frustum[q][3] > 0)
	    {
		continue;
	    }

	    if ((frustum[q][0] * (x + bb.min.x)) + (frustum[q][1] * (y + bb.min.y)) + (frustum[q][2] * (z + bb.max.z)) + frustum[q][3] > 0)
	    {
		continue;
	    }

	    if ((frustum[q][0] * (x + bb.min.x)) + (frustum[q][1] * (y + bb.max.y)) + (frustum[q][2] * (z + bb.min.z)) + frustum[q][3] > 0)
	    {
		continue;
	    }

	    if ((frustum[q][0] * (x + bb.max.x)) + (frustum[q][1] * (y + bb.max.y)) + (frustum[q][2] * (z + bb.min.z)) + frustum[q][3] > 0)
	    {
		continue;
	    }

	    if ((frustum[q][0] * (x + bb.max.x)) + (frustum[q][1] * (y + bb.max.y)) + (frustum[q][2] * (z + bb.max.z)) + frustum[q][3] > 0)
	    {
		continue;
	    }

	    if ((frustum[q][0] * (x + bb.min.x)) + (frustum[q][1] * (y + bb.max.y)) + (frustum[q][2] * (z + bb.max.z)) + frustum[q][3] > 0)
	    {
		continue;
	    }

	    // jos p��st��n t�nne, objekti ei ole frustumissa
	    return false;
	}

	// vertex ruudulla, objekti on n�kyv�
	return true;

    }

    /**
     * palauttaa 0 jos cube ei ole frustumissa. 1 jos osittain 2 jos
     * kokonaan
     */
    public static int cubeInFrustum(float x, float y, float z, float size)
    {
	int p;
	int c;
	int c2 = 0;

	for (p = 0; p < 6; p++)
	{
	    c = 0;
	    if (frustum[p][0] * (x - size) + frustum[p][1] * (y - size) + frustum[p][2] * (z - size) + frustum[p][3] > 0)
	    {
		c++;
	    }
	    if (frustum[p][0] * (x + size) + frustum[p][1] * (y - size) + frustum[p][2] * (z - size) + frustum[p][3] > 0)
	    {
		c++;
	    }
	    if (frustum[p][0] * (x - size) + frustum[p][1] * (y + size) + frustum[p][2] * (z - size) + frustum[p][3] > 0)
	    {
		c++;
	    }
	    if (frustum[p][0] * (x + size) + frustum[p][1] * (y + size) + frustum[p][2] * (z - size) + frustum[p][3] > 0)
	    {
		c++;
	    }
	    if (frustum[p][0] * (x - size) + frustum[p][1] * (y - size) + frustum[p][2] * (z + size) + frustum[p][3] > 0)
	    {
		c++;
	    }
	    if (frustum[p][0] * (x + size) + frustum[p][1] * (y - size) + frustum[p][2] * (z + size) + frustum[p][3] > 0)
	    {
		c++;
	    }
	    if (frustum[p][0] * (x - size) + frustum[p][1] * (y + size) + frustum[p][2] * (z + size) + frustum[p][3] > 0)
	    {
		c++;
	    }
	    if (frustum[p][0] * (x + size) + frustum[p][1] * (y + size) + frustum[p][2] * (z + size) + frustum[p][3] > 0)
	    {
		c++;
	    }
	    if (c == 0)
	    {
		return 0;
	    }
	    if (c == 8)
	    {
		c2++;
	    }
	}
	return (c2 == 6) ? 2 : 1;
    }

    public static boolean objInFrustum(float x, float y, float z, BoundingArea ba)
    {
	// mode: mik� testaus tehd��n
	switch (ba.mode)
	{
	case BoundingArea.BOX:
	    if (boxInFrustum(x, y, z, ba) == false)
	    {
		return false;
	    }
	    break;

	case BoundingArea.CUBE:
	    if (cubeInFrustum(x, y, z, ba.size) == 0)
	    {
		return false;
	    }
	    break;

	case BoundingArea.SPHERE:
	    if (sphereInFrustum(x, y, z, ba.r) == 0)
	    {
		return false;
	    }
	    break;
	}

	if (Settings.DEBUG)
	{
	    ba.draw();
	}

	return true;
    }
}
