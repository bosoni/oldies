package jsat;

import java.nio.FloatBuffer;
import org.lwjgl.BufferUtils;

public class Buffers
{
    public static FloatBuffer floatBuffer = BufferUtils.createFloatBuffer(16);
    public static FloatBuffer matrixModelView = BufferUtils.createFloatBuffer(16);
    public static FloatBuffer matrixProjection = BufferUtils.createFloatBuffer(16);

    
    
}
