/**
 * @file ShadowMappping.java
 * 
 * @author mjt, 2007-08 mixut@hotmail.com
 * 
 */
// vaadittavat: ARB_depth_texture ARB_shadow GLSL-tuki
// v�hint��n ATI 9500+ tai GeforceFX 5200+
package jsat;

import static org.lwjgl.opengl.GL11.*;

public class ShadowMapping extends Project
{
    /**
     * luo texture johon renderoidaan valosta p�in oleva skene.
     */
    public void makeMap(String textureFileName)
    {
	load(textureFileName);
    }

    /**
     * renderoi skenee valostap�in.
     * 
     */
    public void createLighting()
    {
	glCullFace(GL_FRONT);
	calcProjection(true);
	glCullFace(GL_BACK);
    }

    // renderoi skene valosta p�in kuvattuna. vain zbuffer otetaan talteen.
    public void renderFromLight()
    {
	Texture.active(0);

	glDepthFunc(GL_LEQUAL);
	{
	    glShadeModel(GL_FLAT);
	    Light.disableLights();
	    glBindTexture(GL_TEXTURE_2D, 0);
	    glDisable(GL_TEXTURE_2D);

	    glColorMask(false, false, false, false);

	    // renderoi skene valosta p�in zbufferiin ja ota se talteen
	    createLighting();

	    glColorMask(true, true, true, true);
	    glShadeModel(GL_SMOOTH);
	    Light.enableLights();
	    glEnable(GL_TEXTURE_2D);
	}

    }

    // aseta texturematriisit shadowmapping shaderia varten
    public void setMatrix()
    {
	// aseta light maski
	// jos ladattu texture .DDS:�n� ja ei tukea, �l� bindaa mit��n
	if (texture != null)
	{
	    texture.bind(2);
	}
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();

	Screen.depthTexture().bind(1);
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glTranslatef(0.5f, 0.5f, 0.5f); // remap from [-1,1]^2 to [0,1]^2
	glScalef(0.5f, 0.5f, 0.5f);
	glMultMatrix(lightProjectionMatrix);
	glMultMatrix(lightViewMatrix);

	Texture.active(0);
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();

	glMatrixMode(GL_MODELVIEW);
    }

    /**
     * renderoi skenen textureineen varjostettuna.
     * 
     * ensin renderoidaan skene valosta p�in ilman textureita, otetaan
     * z-buffer talteen. asetetaan matriisit, texturet ym renderoi skene
     * 
     */
    public void renderShadowMapped()
    {
	// renderoi valosta p�in ja skene ilman textureita. zbuffer talteen.
	BaseGame.shadowMap.renderFromLight();
	glClear(Settings.CLEARBUFFERS);
	setMatrix();

	// renderoi skene, nyt k�ytet��n asetettua shaderia
	Frustum.calculateFrustum();
	BaseGame.world.render();
	Screen.unbind();
	Texture.unbind(1);
	Texture.unbind(2);
	Texture.active(0);
    }

    /**
     * renderoi skenen varjot, otetaan ne talteen. shadowpass shaderille.
     * 
     */
    public void renderShadowMapped2Texture()
    {
	if (Settings.useShadowMapping == false)
	    return;

	if (Settings.GL10_11_12)
	{
	    // renderoi valosta p�in ja skene ilman textureita. zbuffer talteen.
	    BaseGame.shadowMap.renderFromLight();
	    glClear(Settings.CLEARBUFFERS);
	    setMatrix();

	    BaseGame.screen.bind(); // jos fbo k�yt�ss�, renderoidaan suoraan screen
	    // textureen
	    BaseGame.screen.setViewport();

	    // renderoi skene, nyt k�ytet��n asetettua shaderia
	    Frustum.calculateFrustum();
	    BaseGame.world.render();
	    Screen.unbind();
	    Texture.unbind(1);
	    Texture.unbind(2);

	    BaseGame.screen.restoreViewport();
	    Texture.active(0);
	    BaseGame.screen.copyScreen(); // ellei fbo k�yt�ss�, kopioi kamat
	    glClear(Settings.CLEARBUFFERS);
	    
	    return;
	}

	// renderoi valosta p�in ja skene ilman textureita. zbuffer talteen.
	BaseGame.shadowMap.renderFromLight();
	glClear(Settings.CLEARBUFFERS);

	BaseGame.screen.bind(); // jos fbo k�yt�ss�, renderoidaan suoraan screen
	// textureen
	BaseGame.screen.setViewport();
	// aseta light maski
	// jos ladattu texture .DDS:�n� ja ei tukea, �l� bindaa mit��n
	if (texture != null)
	{
	    texture.bind(2);
	}

	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();

	// aseta syvyyskartta
	Screen.depthTexture().bind(1);
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glTranslatef(0.5f, 0.5f, 0.5f); // remap from [-1,1]^2 to [0,1]^2
	glScalef(0.5f, 0.5f, 0.5f);
	glMultMatrix(lightProjectionMatrix);
	glMultMatrix(lightViewMatrix);
	glMatrixMode(GL_MODELVIEW);

	Texture.active(0);

	Frustum.calculateFrustum();
	BaseGame.world.render();

	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	Texture.unbind(1); // Screen.depthTexture
	Screen.unbind();
	Texture.unbind(2);

	BaseGame.screen.restoreViewport();
	Texture.active(0);

	BaseGame.screen.copyScreen(); // ellei fbo k�yt�ss�, kopioi kamat
	// screen-textureen

	glClear(Settings.CLEARBUFFERS);
    }
}
