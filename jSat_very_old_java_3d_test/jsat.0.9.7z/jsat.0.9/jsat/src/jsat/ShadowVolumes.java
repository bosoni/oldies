/**
 * @file ShadowVolumes.java
 *
 * @author mjt, 2007-08
 * mixut@hotmail.com
 *
 * renderoi varjot z-fail shadow volumes menetelm�ll�.
 *
 * linkkej� varjoihin:
 *
 * http://nehe.gamedev.net/data/lessons/lesson.asp?lesson=27
 * http://www.angelfire.com/games5/duktroa/RealTimeShadowTutorial.htm
 * http://www.paulsprojects.net/opengl/shadvol/shadvol.html
 *
 */
package jsat;

import org.lwjgl.BufferUtils;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import static org.lwjgl.opengl.GL11.*;

public class ShadowVolumes
{
    Geometry shadow; // varjon vertex arrayt

    private static Vector3f lightPos = new Vector3f();

    private static Vector3f lPos = new Vector3f();

    // onko face valoon p�in
    boolean[] visible = null;

    // naapuri face
    int[][] neightbourInd = null;

    int faces = 0;

    public ShadowVolumes(int faces)
    {
	visible = new boolean[faces];
	neightbourInd = new int[faces][3];
	this.faces = faces;

	shadow = new Geometry();
	FloatBuffer vbuf = BufferUtils.createFloatBuffer(faces*3); // varataan v�h�n vertexeille tilaa
	shadow.setVerts(vbuf);

	IntBuffer indices = BufferUtils.createIntBuffer(faces);
	shadow.setIndices(indices);
    }

    /**
     * taulukoi joka polyn naapurit connectivity procedure - based on
     * Gamasutra's article
     */
    void setConnectivity(int[][] ind)
    {
	int p1i, p2i, p1j, p2j;
	int P1i, P2i, P1j, P2j;
	int i, j, ki, kj;

	for (i = 0; i < faces - 1; i++)
	{

	    for (j = i + 1; j < faces; j++)
	    {
		for (ki = 0; ki < 3; ki++)
		{
		    if (neightbourInd[i][ki] == 0)
		    {
			for (kj = 0; kj < 3; kj++)
			{
			    p1i = ki;
			    p1j = kj;
			    p2i = (ki + 1) % 3;
			    p2j = (kj + 1) % 3;

			    p1i = ind[i][p1i];
			    p2i = ind[i][p2i];
			    p1j = ind[j][p1j];
			    p2j = ind[j][p2j];

			    P1i = ((p1i + p2i) - Math.abs(p1i - p2i)) / 2;
			    P2i = ((p1i + p2i) + Math.abs(p1i - p2i)) / 2;
			    P1j = ((p1j + p2j) - Math.abs(p1j - p2j)) / 2;
			    P2j = ((p1j + p2j) + Math.abs(p1j - p2j)) / 2;

			    // they are neighbours
			    if ((P1i == P1j) && (P2i == P2j))
			    {
				neightbourInd[i][ki] = j + 1;
				neightbourInd[j][kj] = i + 1;
			    }
			}
		    }
		}
	    }
	}

    }

    Vector4f[] planeEquation;

    void setPlanes(Vector4f[] planes)
    {
	planeEquation = planes;
    }

    /**
     * Tsekkaa onko poly valoon p�in
     */
    boolean faceVisible(int ind)
    {
	return visible[ind];
    }

    /**
     * Taulukoi onko facet valoon p�in
     */
    void checkFacesVisible()
    {
	for (int q = 0; q < planeEquation.length; q++)
	{
	    float side = planeEquation[q].x * lightPos.x + planeEquation[q].y * lightPos.y + planeEquation[q].z * lightPos.z + planeEquation[q].w;

	    if (side < 0)
	    {
		visible[q] = true;
	    } else
	    {
		visible[q] = false;
	    }
	}

    }

    static void setupPass1(Vector3f light)
    {
	lPos = light;

	glDisable(GL_BLEND);
	glClear(GL_STENCIL_BUFFER_BIT);
	glDepthFunc(GL_LESS);
	glColorMask(false, false, false, false); // ei rendata ruudulle mit��n, vain z-bufferiin
	glStencilFunc(GL_ALWAYS, 0, 0); // stencil bufferiin aina

	glCullFace(GL_FRONT); // back facet
	glStencilOp(GL_KEEP, GL_INCR, GL_KEEP); // increment
    }

    static void setupPass2()
    {
	glCullFace(GL_BACK); // front facet
	glStencilOp(GL_KEEP, GL_DECR, GL_KEEP); // decrement
    }

    static void setupFinal()
    {
	glDepthFunc(GL_LEQUAL);
	glCullFace(GL_BACK);
	glEnable(GL_BLEND);
	glColorMask(true, true, true, true); // nyt renderoidaan skene valoineen
	glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP); // ei vaikuta stencil bufferiin
	glStencilFunc(GL_EQUAL, 0x0, 0xff); // piirr� jos 0

	Light.enableLights();
    }

    /**
     * matriisi * vektori
     * 
     * @param M
     *                matriisi
     * @param v
     *                vektori
     */
    private void vMatMult(float M[], float v[])
    {

	float res[] = new float[4];
	res[0] = M[0] * v[0] + M[4] * v[1] + M[8] * v[2] + M[12] * v[3];
	res[1] = M[1] * v[0] + M[5] * v[1] + M[9] * v[2] + M[13] * v[3];
	res[2] = M[2] * v[0] + M[6] * v[1] + M[10] * v[2] + M[14] * v[3];
	res[3] = M[3] * v[0] + M[7] * v[1] + M[11] * v[2] + M[15] * v[3];
	v[0] = res[0];
	v[1] = res[1];
	v[2] = res[2];
	v[3] = res[3];
    }

    /**
     * calculate light's position relative to local coordinate system
     * 
     * @param position
     *                objektin paikka
     * @param rotation
     *                objektin asento
     */
    void calcLight(Vector3f position, Vector3f rotation)
    {
	float Minv[] = new float[16];
	float lp[] = new float[4];

	// calculate light's position relative to local coordinate system
	// dunno if this is the best way to do it, but it actually works
	// we build the inversed matrix by doing all the actions in reverse
	// order
	// and with reverse parameters (notice -xrot, -yrot, -ObjPos[], etc.)
	glPushMatrix();

	glLoadIdentity();
	glRotatef(-rotation.z, 0.0f, 0.0f, 1.0f);
	glRotatef(-rotation.y, 0.0f, 1.0f, 0.0f);
	glRotatef(-rotation.x, 1.0f, 0.0f, 0.0f);
	glTranslatef(-position.x, -position.y, -position.z);
	Buffers.floatBuffer.clear();
	glGetFloat(GL_MODELVIEW_MATRIX, Buffers.floatBuffer);
	Buffers.floatBuffer.get(Minv);
	lp[0] = lPos.x;
	lp[1] = lPos.y;
	lp[2] = lPos.z;
	lp[3] = 1;
	vMatMult(Minv, lp);

	lightPos.x = lp[0];
	lightPos.y = lp[1];
	lightPos.z = lp[2];

	glPopMatrix();
    }

    /**
     * luo shadow volumen objektista
     * 
     */
    void buildShadowVolume(FloatBuffer vert, int[][] ind, Vector3f position, Vector3f rotation)
    {
	calcLight(position, rotation);
	checkFacesVisible();

	glPushMatrix();
	glTranslatef(position.x, position.y, position.z);
	glRotatef(rotation.x, 1.0f, 0.0f, 0.0f);
	glRotatef(rotation.y, 0.0f, 1.0f, 0.0f);
	glRotatef(rotation.z, 0.0f, 0.0f, 1.0f);

	glEnable(GL_POLYGON_OFFSET_FILL);
	glPolygonOffset(0.0f, 100.0f);

	glBegin(GL_QUADS);

	for (int a = 0; a < ind.length; a++)
	{
	    if (faceVisible(a) == false)
	    {
		continue;
	    }

	    for (int b = 0; b < 3; b++)
	    {
		int c = neightbourInd[a][b];
		if (c == 0 || faceVisible(c - 1) == false) // jos ei ole viereist� tai viereinen ei n�y, niin reunapoly
		{

		    // viimeinen vertex on ensimm�inen vertex
		    int e0 = b;
		    int e1 = b + 1;
		    if (e1 >= 3)
		    {
			e1 = 0;
		    }

		    // objektin joka reuna vedet��n ��rett�m��n
		    // shadow volume
                    
                    // hidas tapa, glVertexeill�  -todo fix
		    int i;
		    i = ind[a][e0]*3;
		    glVertex3f(vert.get(i), vert.get(i+1), vert.get(i+2));

		    i = ind[a][e1]*3;
		    glVertex3f(vert.get(i), vert.get(i+1), vert.get(i+2));

		    glVertex4f(vert.get(i)- lightPos.x, vert.get(i+1)- lightPos.y, vert.get(i+2)- lightPos.z, 0);

		    i = ind[a][e0]*3;
		    glVertex4f(vert.get(i)- lightPos.x, vert.get(i+1)- lightPos.y, vert.get(i+2)- lightPos.z, 0);
		}
	    }

	}
	glEnd();

	glBegin(GL_TRIANGLES);

	// rendaa capsit
	for (int a = 0; a < ind.length; a++)
	{
	    if (faceVisible(a) == false)
	    {
		continue;
	    }

	    for (int b = 0; b < 3; b++)
	    {
		int i;
		i = ind[a][2 - b]*3;
		glVertex3f(vert.get(i), vert.get(i+1), vert.get(i+2));

	    }
	}

	for (int a = 0; a < ind.length; a++)
	{
	    if (faceVisible(a) == false)
	    {
		continue;
	    }

	    for (int b = 0; b < 3; b++)
	    {
		int i;
		i = ind[a][b]*3;
                glVertex4f(vert.get(i)- lightPos.x, vert.get(i+1)- lightPos.y, vert.get(i+2)- lightPos.z, 0);

	    }
	}

	glEnd();

	glPopMatrix();

	glDisable(GL_POLYGON_OFFSET_FILL);
    }

    /**
     * luo shadow volumen objektista
     * 
     */
    void buildShadowVolume(Vector3f[] vert, int[][] ind, Vector3f position, Vector3f rotation)
    {
	calcLight(position, rotation);
	checkFacesVisible();

	glPushMatrix();
	glTranslatef(position.x, position.y, position.z);
	glRotatef(rotation.x, 1.0f, 0.0f, 0.0f);
	glRotatef(rotation.y, 0.0f, 1.0f, 0.0f);
	glRotatef(rotation.z, 0.0f, 0.0f, 1.0f);

	glEnable(GL_POLYGON_OFFSET_FILL);
	glPolygonOffset(0.0f, 100.0f);

	glBegin(GL_QUADS);

	for (int a = 0; a < ind.length; a++)
	{
	    if (faceVisible(a) == false)
	    {
		continue;
	    }

	    for (int b = 0; b < 3; b++)
	    {
		int c = neightbourInd[a][b];
		if (c == 0 || faceVisible(c - 1) == false) // jos ei ole viereist� tai viereinen ei n�y, niin reunapoly
		{

		    // viimeinen vertex on ensimm�inen vertex
		    int e0 = b;
		    int e1 = b + 1;
		    if (e1 >= 3)
		    {
			e1 = 0;
		    }

		    // objektin joka reuna vedet��n ��rett�m��n
		    // shadow volume
		    int i;
		    i = ind[a][e0];
		    glVertex3f(vert[i].x, vert[i].y, vert[i].z);

		    i = ind[a][e1];
		    glVertex3f(vert[i].x, vert[i].y, vert[i].z);

		    glVertex4f(vert[i].x - lightPos.x, vert[i].y - lightPos.y, vert[i].z - lightPos.z, 0);

		    i = ind[a][e0];
		    glVertex4f(vert[i].x - lightPos.x, vert[i].y - lightPos.y, vert[i].z - lightPos.z, 0);
		}
	    }

	}
	glEnd();

	glBegin(GL_TRIANGLES);

	// rendaa capsit
	for (int a = 0; a < ind.length; a++)
	{
	    if (faceVisible(a) == false)
	    {
		continue;
	    }

	    for (int b = 0; b < 3; b++)
	    {
		int i;
		i = ind[a][2 - b];
		glVertex3f(vert[i].x, vert[i].y, vert[i].z);

	    }
	}

	for (int a = 0; a < ind.length; a++)
	{
	    if (faceVisible(a) == false)
	    {
		continue;
	    }

	    for (int b = 0; b < 3; b++)
	    {
		int i;
		i = ind[a][b];
		glVertex4f(vert[i].x - lightPos.x, vert[i].y - lightPos.y, vert[i].z - lightPos.z, 0);

	    }
	}

	glEnd();

	glPopMatrix();

	glDisable(GL_POLYGON_OFFSET_FILL);

    }
    
}
