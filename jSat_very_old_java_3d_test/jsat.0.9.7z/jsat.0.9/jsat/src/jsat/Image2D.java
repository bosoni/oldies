/**
 * @file Image2D.java
 *
 * @author mjt, 2007
 * mixut@hotmail.com
 *
 * 2d kuvan piirto
 */
package jsat;

import static org.lwjgl.opengl.GL11.*;

public class Image2D extends Node
{
    /**
     * 2d kuva
     */
    public Texture texture = null;

    public float scaleX = 1, scaleY = 1, angle = 0;

    public Image2D()
    {
	super("image2d");
	setType(IMAGE);
    }

    public Image2D(String fileName)
    {
	super(fileName);
	load(fileName);
	setType(IMAGE);
    }

    public void load(String fileName)
    {
	name = fileName;
	fileName = Settings.TEXTUREDIR + fileName;
	texture = new Texture(fileName);
    }

    public void set(float x, float y, float sx, float sy, float _angle)
    {
	setPosition(x, y, 0);
	scaleX = sx;
	scaleY = sy;
	angle = _angle;
    }

    public void render(float x, float y, float sx, float sy, float _angle)
    {
	set(x, y, sx, sy, _angle);
	render();
    }

    public void render()
    {
	if (texture == null)
	{
	    return;
	}

	glLoadIdentity();
	texture.bind(0);

	glPushAttrib(GL_COLOR_BUFFER_BIT | GL_ENABLE_BIT | GL_POLYGON_BIT);
	glDisable(GL_LIGHTING);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	float tw = texture.getWidth();
	float th = texture.getHeight();
	float x = getPosition().x;
	float y = BaseGame.getScreenHeight() - getPosition().y - th;

	tw /= 2;
	th /= 2;

	glTranslatef(x + tw, y + th, 0);
	glRotatef(angle, 0, 0, 1);

	glBegin(GL_TRIANGLE_FAN);
	glTexCoord2f(0, 1);
	glVertex3f(-tw*scaleX, -th*scaleY, 0);
	glTexCoord2f(1, 1);
	glVertex3f((tw) * scaleX, -th*scaleY, 0);
	glTexCoord2f(1, 0);
	glVertex3f(tw * scaleX, th * scaleY, 0);
	glTexCoord2f(0, 0);
	glVertex3f(-tw*scaleX, th * scaleY, 0);
	glEnd();

	glPopAttrib();

    }

    public static void render_tex(float x, float y, float scaleX, float scaleY, Texture tex)
    {
	if (tex == null)
	{
	    return;
	}

	tex.bind(0);
	glPushAttrib(GL_COLOR_BUFFER_BIT | GL_ENABLE_BIT | GL_POLYGON_BIT);
	glDisable(GL_LIGHTING);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glColor4f(1, 1, 1, 1);

	float tw = tex.getWidth();
	float th = tex.getHeight();

	glBegin(GL_TRIANGLE_FAN);
	glTexCoord2f(0, 1);
	glVertex3f(x, y, 0);
	glTexCoord2f(1, 1);
	glVertex3f((x + tw) * scaleX, y, 0);
	glTexCoord2f(1, 0);
	glVertex3f((x + tw) * scaleX, (y + th) * scaleY, 0);
	glTexCoord2f(0, 0);
	glVertex3f(x, (y + th) * scaleY, 0);
	glEnd();

	glPopAttrib();

	glLoadIdentity();
    }
}
