package demos;

/**
 * @file Test18.java
 *
 * @author mjt, mixut@hotmail.com
 *
 * ruudulla n�kyv� -z,  monitorista ulos +z
 *
 */
/**
 *
 * camera path
 *
 * + ja -  s��t�� objektin et�isyyden kameraan
 * 1, 2  vaihtaa nopeutta
 *
 */
import jsat.*;
import org.lwjgl.input.Keyboard;

public class Test18 extends BaseGame
{

    Input input = new Input();

    Font fnt = null;

    Object3D sobj = null;

    public void init()
    {
	try
	{
	    setDisplayMode();

	    fnt = new Font("comic12.PNG");

	    Object3D mesh = null;
	    mesh = new Object3D("scene", "rooms2_eriks.obj", 30, 10, 30, false);

	    world.add(mesh);

	    // lataa reitti, luotu blenderill�
	    mesh = new Object3D("path", "path.obj", 30, 10, 30, false); // skaalataan
	    // reitti�
	    // kuten
	    // scene�
	    camera.setPath(mesh); // kamera kulkemaan reitti� pitkin
	    camera.makeCurve(5, true); // luo viivarykelm�st� kaari,
	    // parametrina lod (suurempi ->
	    // "pehme�mpi" kaari)

	    // lataa objekti. seuraa my�s samaa reitti� mit� kamera, v�h�n
	    // edell� vaan
	    sobj = new Object3D("obu", "obj.obj");
	    sobj.setPath(mesh); // seuraa reitti�
	    world.add(sobj);

	    sobj.setTime(1.5f); // aloituspaikka. objekti kameran eteen, koska se
	    // alkaa 0.0:sta

	    camera.setPosition(0, 6, 5);

	    // aseta valo
	    Light light = new Light("valo", 0);
	    light.setPosition(10, 50, 10);
	    light.setAmbient(new Colorf(0.1f, 0.1f, 0f, 1));
	    light.setSpecular(new Colorf(0.5f, 0.5f, 0.5f, 1));
	    light.setDiffuse(new Colorf(0f, 0.4f, 0.7f, 1));
	    light.enable();
	    world.add(light);

	    // Mouse.setGrabbed(true); // hiiri ei poistu ikkunasta
	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}

	// ohje
	Log.write("\n#########################################################\n+ ja -  s��t�� objektin et�isyyden kameraan\n1, 2  vaihtaa nopeutta");
    }

    public void cleanup()
    {

    }

    float objDist = 15f; // matka kamerasta

    float mult = 15; // suurempi -> nopeuttaa (voi muuttaa 1,2 n�pp�imill�)

    public void render(float time)
    {

	if (Keyboard.isKeyDown(Keyboard.KEY_ADD))
	{
	    objDist += 0.01f;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_SUBTRACT))
	{
	    objDist -= 0.01f;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_1))
	{
	    if (mult > 0)
	    {
		mult -= 0.01f;
	    }
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_2))
	{
	    mult += 0.01f;
	}

	input.checkKeyb(time * 5);
	input.checkMouse();

	camera.updatePath(time * mult); // p�ivit� kameran paikka reitill�

	if (objDist <= 0)
	{
	    objDist = 0.01f;
	}

	// p�ivit� objektin paikka
	sobj.setTime(camera.getTime() + objDist); // hieman edelle kameraa
        

        //sobj.lookAt(null); // jos ei haluta objektin "katsovan" menosuuntaan
                
	world.render();

	sobj.setPosition(0, 4, 0);
	sobj.render();

	world.renderBillboards();
	set2DMode();
	fnt.print("FPS:" + Main.calcFPS() + " objsRend:" + objectsRendered + " dist:" + objDist + " speed: "+mult, 5, 10);
	set3DMode();

    }
}
