package demos;

/**
 * @file Test14.java
 *
 * @author mjt, mixut@hotmail.com
 *
 * ruudulla n�kyv� -z,  monitorista ulos +z
 *
 */
/*
 * terrain 2
 * v�h�n kamaa maastoon
 */
import jsat.*;
import org.lwjgl.util.vector.Vector3f;
import static org.lwjgl.opengl.GL11.*;
import org.lwjgl.util.vector.Vector2f;

public class Test14 extends BaseGame
{
    Input input = new Input(false);

    Font fnt = null;

    Terrain terrain = new Terrain("terrain");

    BillBoard tree = null;

    public void init()
    {

	try
	{
	    setDisplayMode();

	    fnt = new Font("arial12.PNG");

	    // Mouse.setGrabbed(true); // hiiri ei poistu ikkunasta
	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}
    }

    public void cleanup()
    {

    }

    // n�yt� logo alussa
    boolean showLogo = true;

    Image2D pic = null;

    float alpha = 0, mul = 1, angle = 0;

    void showLogo(float time)
    {
	if (pic == null)
	    pic = new Image2D("jsat.png");
	alpha += time * 0.5f * mul;
	if (alpha >= 2)
	{
	    alpha = 1;
	    mul = -1;
	}
	if (alpha <= 0)
	    showLogo = false;
	glColor4f(1, 1, 1, alpha);
	set2DMode();
	pic.render(getScreenWidth() / 2 - pic.texture.getWidth() / 2, getScreenHeight() / 2 - pic.texture.getHeight() / 2, 1, 1, angle += 0.2f);
	set3DMode();
	glColor4f(1, 1, 1, 1);
	if (input.mButtonDown == 1)
	    showLogo = false;
    }

    // --------------------
    int inited = -1;

    void initDemo(int num)
    {
	if (inited == num)
	    return;
	inited = num;
	try
	{
	    if (num == 0)
	    {
		pic = null; // logon poisto

		// aseta valo
		Light light = new Light("valo", 0);
		light.setPosition(230, 50, 220);
		light.setAmbient(new Colorf(0.1f, 0.1f, 0.1f, 1));
		light.setSpecular(new Colorf(0.5f, 0.5f, .5f, 1));
		light.setDiffuse(new Colorf(.60f, 0.6f, 0.6f, 1));
		light.enable();
		world.add(light);

		camera.setPosition(50, 20, 200);

		String[] names = { "grass.jpg", "sand.jpg", "part.jpg" };
		terrain.load("terrain.jpg", "terrain_tex.jpg", names);

		// ota kartan koko
		Vector2f mapSize = terrain.getSize();

		// laita puita maastoon
		for (int c = 0; c < 600; c++)
		{
		    Vector3f pos = new Vector3f();
		    pos.x = (float) Math.random() * mapSize.x;
		    pos.z = (float) Math.random() * mapSize.y;
		    pos.y = terrain.getY(pos) + 3;

		    if (Math.random() * 10 < 5.0)
		    {
			tree = new BillBoard("tree", "tree1.png", pos, GL_LINEAR, GL_LINEAR);
		    } else
		    {
			tree = new BillBoard("tree", "tree2.png", pos, GL_LINEAR, GL_LINEAR);
		    }
		    tree.scale(4 + (float) Math.random() * 4, 6 + (float) Math.random() * 25);
		    world.add(tree);

		}

		BillBoard.rendOrig = false; // k�yt� toista renderointia
		// puille

	    }
	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}

    }

    public void render(float time)
    {
	input.checkKeyb(time * 15);
	input.checkMouse();

	if (showLogo)
	{
	    showLogo(time);
	    return;
	} else
	    initDemo(0);

	terrain.cameraOnGround(5);
	camera.updateXZ();

	terrain.render();

	BillBoard.billboardsRendered = 0;
	world.renderBillboardsXZ(); // renderoi puut

	set2DMode();
	fnt.print("FPS:" + Main.calcFPS() + " " + BillBoard.billboardsRendered + " mode:" + mode, 5, 10);
	set3DMode();
    }

}
