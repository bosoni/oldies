package demos;

/**
 * @file SetBoundings.java
 *
 * @author mjt, mixut@hotmail.com
 *
 * ruudulla n�kyv� -z,  monitorista ulos +z
 *
 */
/*
 * apuohjelma mill� saa liitetty� bounding boxit/spheret objekteihin.
 *
 * TAB vaihtaa moodia: kamera/valinta
 *
 * ensin ladataan obj/md5 ja sitten kehikko, sitten valitaan hiiren vasemmalla
 * objekti, hiiren oikealla oikea kehikko ja Join.
 *
 * 3d-mallinnusohjelmassa tehd��n laatikot ja pallot.
 * setBoundings ohjelma laskee n�ille objekteille bounding areat ja tallentaa ne.
 *
 * bounding tyypin voi vaihtaa, eli esim laatikko-kehikosta tallennetaankin s�de.
 *
 * ----KESKEN---
 *
 * objektin/bounding boxin voi valita, v�ri/viivan paksuus muuttuu.
 *
 *todo
 * liitt�� ne yhteen. joka boundingille tiedot (tyyppi, paino, jne)
 *
 */
/*
 *
 *
 jos valkataan obu ja bbox, painetaan Join niin ne liitet��n yhteen.
 boundingit pit�� tietty s��t�� (box, sphere, capsule, trimesh).
 ne sit tallennetaan erilliseen filuun, ne infot siis.

 jos objektille ei ole tehty boundingia, voidaan klikata esim rengasta,
 m��r�t� sille sphere. silloin siin� tallennettaisiin sphere info.

 eli boundingeille vakiona bbox kaikille.
 objekteilla ei mit��n. mut jos valikoi jonkun, sille tuleekin sitten se.
 unjoin poistaa objektilta boundingin.
 boundingilta unjoin poistaa linkin objektiin.


 tsekkaa mit� ode tukee: 
 Pallonivelliitos (ball and socket joint)
 Saranaliitos (hinge joint)
 Liukuliitos (slider joint)
 Ristinivelliitos (universal joint)



 */
import jsat.*;
import java.util.Vector;
import org.lwjgl.input.Keyboard;
import org.lwjgl.util.glu.GLU;
import static org.lwjgl.opengl.GL11.*;
import org.lwjgl.util.vector.Vector3f;

// bounding arean tiedot
class BInfo
{
    final int BOX = 1;

    final int SPHERE = 2;

    final int CAPSULE = 3;

    final int TRI = 4;

    int type = 1; // box, sphere, ..

    int mass = 0; // 0==static obj

    int objNr = -1; // mihin objektiin t�m� kehikko on liitetty

}

// todo t�st� jatkamaan sitten

public class SetBoundings extends BaseGame implements Callback
{
    Vector<BInfo> info = new Vector<BInfo>();

    int mode = 1; // camera / select

    boolean keyUp = true;

    Input input = new Input(false);

    Font fnt = null;

    Object3D object = null;

    MD5Model model = null;

    Object3D bounding = null;

    /**
     * filemode==1 lataa obj tiedoston filemode==2 lataa md5 filemode==3
     * lataa bounding tiedoston
     */
    public void loadFile(String fileName, int mode)
    {
	objectFile = fileName;
	filemode = mode;
    }

    private String objectFile = "";

    private int filemode = 0;

    private void load_File(String fileName, int mode)
    {
	if (fileName == null)
	    return;

	// s��det��n hakemistot kohilleen hetkeksi
	int q;
	for (q = fileName.length() - 1; q > 0; q--)
	    if (fileName.charAt(q) == '/' || fileName.charAt(q) == '\\')
		break;
	Settings.DATADIR = fileName.substring(0, q + 1);

	int w = q + 1;
	q--;
	for (; q > 0; q--)
	    if (fileName.charAt(q) == '/' || fileName.charAt(q) == '\\')
		break;
	Settings.TEXTUREDIR = fileName.substring(0, q + 1) + "texture/";
	fileName = fileName.substring(w, fileName.length());

	Log.write("datadir=" + Settings.DATADIR);
	Log.write("texdir=" + Settings.TEXTUREDIR);
	Log.write("filename=" + fileName);

	try
	{
	    if (mode == 1)
	    {
		world.remove("object");
		world.remove("model");
		object = new Object3D("object", fileName);
		world.add(object);

		object.setCallback(this);
	    } else if (mode == 2)
	    {
		world.remove("object");
		world.remove("model");
		model = new MD5Model("model", fileName, null);
		world.add(model);

		model.setCallback(this);
	    } else if (mode == 3)
	    {
		world.remove("bounding");
		bounding = new Object3D("bounding", fileName);

		bounding.setCallback(this);
	    }

	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}

	// nollaus
	Settings.DATADIR = "";
	Settings.TEXTUREDIR = "";

    }

    @Override
    public void init()
    {
	Settings.TITLE = "SetBoundings";
	Settings.fullScreen = false;
	Settings.DATADIR = "";
	Settings.TEXTUREDIR = "";
	Settings.FONTDIR = "";
	Settings.SHADERDIR = "";

	try
	{
	    setDisplayMode();

	    glDisable(GL_LIGHTING);
	    camera.setPosition(0, 1, 3);

	    Settings.GLSLSupported = false; // shadereita ei k�ytet�

	    glClearColor(1, 1, 1, 1);
	    glClear(Settings.CLEARBUFFERS);

	    // Mouse.setGrabbed(true); // hiiri ei poistu ikkunasta
	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}
    }

    @Override
    public void cleanup()
    {

    }

    @Override
    public void render(float time)
    {
	try
	{
	    Thread.sleep(10);
	    if (filemode != 0)
	    {
		load_File(objectFile, filemode);
		objectFile = "";
		filemode = 0;
	    }

	    if (world.getNumNodes() == 0 && bounding == null)
	    {
		Thread.sleep(300);
		return;
	    }
	} catch (InterruptedException i)
	{
	}

	glClear(Settings.CLEARBUFFERS);
	glLoadIdentity();

	if (Keyboard.isKeyDown(Keyboard.KEY_TAB))
	{
	    input.mButtonDown = 0; // resetoi
	    if (keyUp == true)
	    {
		keyUp = false;
		if (mode == 1)
		    mode = 2;
		else
		    mode = 1;
		SetBoundingsGUI.GUI.changeMode(mode);
	    }
	} else
	    keyUp = true;

	if (mode == 1)
	{
	    input.checkMouse();
	    input.checkKeyb(time);
	} else
	    input.updateMouse();

	camera.updateXZ();
	drawGrid();
	world.render();

	// jos kehikot ladattu, piirr� ne
	if (bounding != null)
	    bounding.render();

	// select mode
	if (mode == 2)
	{
	    if ((input.mButtonDown & 1) == 1) // vasen napppi
	    {
		getSelection(1);
	    }
	    if ((input.mButtonDown & 2) == 2) // oikea nappi
	    {
		getSelection(2);
	    }
	}

    }

    // ----------------------selection code-----------------
    static int choose = -1, boundchoose = -1;

    void getSelection(int sel)
    {
	BaseGame.selectMode = 1;
	// This Sets The Array <viewport> To The Size And Location Of The Screen
	// Relative To The Window
	ObjectInfo.viewpbuf.clear();
	ObjectInfo.viewpbuf.order();

	glGetInteger(GL_VIEWPORT,  ObjectInfo.viewpbuf);
//	ObjectInfo.viewpbuf.get(ObjectInfo.viewport);

	ObjectInfo.selbuf.clear();
	glSelectBuffer(ObjectInfo.selbuf); // Tell OpenGL To Use Our Array
	// For Selection

	// Puts OpenGL In Selection Mode. Nothing Will Be Drawn. Object ID's and
	// Extents Are Stored In The Buffer.
	glRenderMode(GL_SELECT);

	glInitNames(); // Initializes The Name Stack
	glPushName(0); // Push 0 (At Least One Entry) Onto The Stack

	glMatrixMode(GL_PROJECTION); // Selects The Projection Matrix
	glPushMatrix(); // Push The Projection Matrix
	glLoadIdentity(); // Resets The Matrix

	// This Creates A Matrix That Will Zoom Up To A Small Portion Of The
	// Screen, Where The Mouse Is.
	GLU.gluPickMatrix((float) input.cursorX, (float) input.cursorY, 1.0f, 1.0f, ObjectInfo.viewpbuf);

	GLU.gluPerspective(fov, BaseGame.mode.getWidth() / BaseGame.mode.getHeight(), nearClipping, farClipping);

	glMatrixMode(GL_MODELVIEW); // Select The Modelview Matrix
	glLoadIdentity();
	camera.updateXZ();

	// Render The Targets To The Selection Buffer
	if (sel == 1)
	{
	    if (object != null)
		object.render();
	    else if (model != null)
		model.render();
	} else
	{
	    if (bounding != null)
		bounding.render();
	}

	glMatrixMode(GL_PROJECTION); // Select The Projection Matrix
	glPopMatrix(); // Pop The Projection Matrix
	glMatrixMode(GL_MODELVIEW); // Select The Modelview Matrix
	int hits = glRenderMode(GL_RENDER); // Switch To Render Mode, Find
	// Out How Many
	// Objects Were Drawn Where The Mouse Was
	ObjectInfo.selbuf.get(ObjectInfo.buffer);

	if (hits > 0) // If There Were More Than 0 Hits
	{
	    int chs = (int) ObjectInfo.buffer[3]; // Make Our Selection
	    // The First Object
	    int depth = (int) ObjectInfo.buffer[1]; // Store How Far Away It
	    // Is
	    for (int i = 1; i < hits; i++) // Loop Through All The Detected
	    // Hits
	    {
		// If This Object Is Closer To Us Than The One We Have Selected
		if (ObjectInfo.buffer[i * 4 + 1] < (int) depth)
		{
		    chs = (int) ObjectInfo.buffer[i * 4 + 3]; // Select The
		    // Closer Object
		    depth = (int) ObjectInfo.buffer[i * 4 + 1]; // Store How Far
		    // Away It Is
		}
	    }

	    if (sel == 1)
	    {
		choose = chs;
		world.render();
	    } else
	    {
		boundchoose = chs;
		if (bounding != null)
		{
		    bounding.render();
		}
	    }

	} else
	{
	    if (sel == 1)
		choose = -1;
	    else
		boundchoose = -1;
	}

	BaseGame.selectMode = 0;
	glPopName();

    }

    /**
     * callback metodi. kutsutaan kun renderoidaan objektia, id on objektin
     * tunniste
     */
    public void objAction(String objName, int id, Node obj, Vector3f pos, Vector3f rot)
    {
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glEnable(GL_DEPTH_TEST);
	boolean bound = false;

	if (id == boundchoose && objName.equals("bounding"))
	{
	    glLineWidth(1.5f);
	    bound = true;
	}

	if (objName.equals("bounding"))
	{
	    glDisable(GL_DEPTH_TEST);
	    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	}

	if (id == choose || bound)
	{
	    Log.write(objName + " selected: " + choose, Log.INFO);

	    glColor4f(s_col, 0.2f, 0.2f, 0.5f);
	    s_col = (float) Math.sin(s_colc);
	    if (s_col < 0)
		s_col = -s_col;
	    s_colc += 0.02f;
	} else
	{
	    if (objName.equals("bounding") == false)
	    {
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		glEnable(GL_DEPTH_TEST);
	    } else
		glLineWidth(1f);

	    glColor4f(1, 1, 1, 1);
	}

    }

    float s_col = 0, s_colc = 0;

}
