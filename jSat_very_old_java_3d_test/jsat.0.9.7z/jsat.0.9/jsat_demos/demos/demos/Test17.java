package demos;

/**
 * @file Test17.java
 *
 * @author mjt, mixut@hotmail.com
 *
 * ruudulla n�kyv� -z,  monitorista ulos +z
 *
 */

/**
 * odejava testi
 *
 * n�pp�imet:
 *  space tipauttaa uuden palikan
 *
 */
import jsat.*;
import static org.lwjgl.opengl.GL11.*;
import org.lwjgl.input.Keyboard;
import org.lwjgl.util.vector.Vector3f;

public class Test17 extends BaseGame
{
    Input input = new Input();

    Font fnt = null;

    PhysicsOdeJava phys = new PhysicsOdeJava();

    Object3D sphere = null;

    public void init()
    {

	try
	{
	    setDisplayMode();

	    fnt = new Font("xirod14.PNG");

	    // Mouse.setGrabbed(true); // hiiri ei poistu ikkunasta

	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}
	// ohje
	Log.write("\n#########################################################\nv�lily�nti lis�� palikan skeneen");

    }

    public void cleanup()
    {

    }

    // n�yt� logot
    boolean showLogo = true;

    Image2D pic = null, pic2 = null;

    void showLogo(float time)
    {
	if (pic == null)
	{
	    pic = new Image2D("jsat.png");
	    // pic2=new Image2D("odejava.png");
	}

	set2DMode();
	pic.render(getScreenWidth() / 2 - pic.texture.getWidth() / 2, 50, 1, 1, 0);
	// pic2.render( getScreenWidth()/2 - pic2.texture.getWidth()/2, 150,
	// 1,1, 0);
	set3DMode();

	if (input.mButtonDown == 1)
	    showLogo = false;
    }

    // --------------------
    int inited = -1;

    void initDemo(int num)
    {
	if (inited == num)
	    return;
	inited = num;
	try
	{
	    if (num == 0)
	    {
		pic = null; // logon poisto
		pic2 = null;

		// aseta valo
		Light light = new Light("valo", 0);
		light.setPosition(0, 5, 0);
		light.setAmbient(new Colorf(0.1f, 0.1f, 0.1f, 1));
		light.setSpecular(new Colorf(0.2f, 0.2f, 0.2f, 1));
		light.setDiffuse(new Colorf(0.5f, 0.5f, 0.5f, 1));
		light.enable();
		world.add(light);

		camera.setPosition(0, 5, 55);

		phys.setupWorld();
		makeGeom();
	    }
	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}

    }

    void makeGeom()
    {
	// floor
	Object3D box = Make3DObject.box(new Vector3f(500, 0, 500));
	box.setPosition(0, 0, 0);
	box.getMesh(0).setEmission(new Colorf(0.2f, -5.0f, 0.2f));
	world.add(box);

	box.setRotation(0, 1, 0); // rot on planella normaali
	phys.addObject(box, new Vector3f(0, 0, 0), 0, PhysicsOdeJava.PLANE);

	// V muotoinen meshi johon obut t�rm�ilee
	Vector3f[] vert = new Vector3f[3];
	vert[0] = new Vector3f(-15, 35, 0);
	vert[1] = new Vector3f(0, -1, 0);
	vert[2] = new Vector3f(15, 35, 0);
	box = Make3DObject.extrude(vert, 20, false);
	box.setPosition(0, 0, -10);
	world.add(box);

	phys.addObject(box, new Vector3f(0, 0, 0), 0, PhysicsOdeJava.TRIMESH);

    }

    int objs = 0;

    void keys()
    {
	// tipauta random kohdasta palikka alas
	if (Keyboard.isKeyDown(Keyboard.KEY_SPACE))
	{
	    objs++;

	    Object3D obj = null;
	    boolean box = false;

	    // box / sphere
	    if (Math.random() > 0.5f)
	    {
		obj = Make3DObject.sphere(new Vector3f(1, 1, 1), 10, 10);
	    } else
	    {
		box = true;
		obj = Make3DObject.box(new Vector3f(1, 1, 1));
	    }

	    obj.setPosition(-5 + (float) Math.random() * 12, 15, -5 + (float) Math.random() * 12); // random paikka
	    obj.getMesh(0).setDiffuse(new Colorf(0.4f, (float) Math.random(), 0.3f));
	    obj.getMesh(0).setEmission(new Colorf((float) Math.random(), 0.2f, (float) Math.random()));
	    world.add(obj);

	    float mass = 0.2f + (float) Math.random() * 2;
	    ;

	    // lis�� objekti fysiikkamoottoriin
	    if (box == false)
		phys.addObject(obj, new Vector3f(1f, 0, 0), mass, PhysicsOdeJava.SPHERE);
	    else
		phys.addObject(obj, new Vector3f(1f, 1, 1), mass, PhysicsOdeJava.BOX);

	}

	if (Keyboard.isKeyDown(Keyboard.KEY_1))
	{
	    // phys.ballBody.addForce(-5.0f, 0.0f, 0f);
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_2))
	{
	    // phys.ballBody.addForce(5.0f, 0.0f, 0);
	}

    }

    public void render(float time)
    {
	input.checkKeyb(time * 5);
	input.checkMouse();

	if (showLogo)
	{
	    showLogo(time);
	    return;
	} else
	    initDemo(0);

	keys();

	phys.update(time * 0.5f);

	camera.updateXZ();

	glDisable(GL_TEXTURE_2D);
	glDisable(GL_CULL_FACE);
	world.render();
	glEnable(GL_CULL_FACE);
	glEnable(GL_TEXTURE_2D);

	world.renderBillboards();
	set2DMode();
	fnt.print("FPS:" + Main.calcFPS() + " mode:" + mode + " objRend: " + objectsRendered + " objs: " + objs, 5, 10);
	set3DMode();

    }

}
