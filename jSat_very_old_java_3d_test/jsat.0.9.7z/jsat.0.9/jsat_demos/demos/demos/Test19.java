package demos;

/**
 * @file Test19.java
 *
 * @author mjt, mixut@hotmail.com
 *
 */

/*
 * shader testi.
 * 
 * lataa skenen jossa objekteilla erilaisia shadereita (m��ritelty .mtl tiedostossa).
 * 
 * normalmapping, toon shading, ..
 *
 * 23.5
 * kuvan blurraus ym efut poistetu, ei toiminu kunnolla.
 */
import jsat.*;
import org.lwjgl.input.Keyboard;
import static org.lwjgl.opengl.GL11.*;
import org.lwjgl.util.vector.Vector3f;

public class Test19 extends BaseGame
{

    final int BLOOMPROG = 0;

    final int BLURPROG = 1;

    Input input = new Input();

    Font fnt = null;

    Image2D pic = null;

    BillBoard lightImg = null;

    BlurParameters blurParameters;

    GLSL bump;

    public void init()
    {
	try
	{
	    setDisplayMode();

	    fnt = new Font("font.png");
	    pic = new Image2D("jsat.png");

	    // kaivo.obj : renderoi k�ytt�en normal mappingia (mtl
	    // tiedostoon kirjoitettu)
	    Object3D mesh = new Object3D("scene", "kaivo.obj", 30, 20, 30, false);
	    bump = mesh.getShader("normalmap"); // ota normalmapping shader ett�
	    // voidaan antaa loopissa valon ja kameran paikat
	    world.add(mesh);

	    mesh = new Object3D("scene", "ball.obj");
	    mesh.setPosition(0, 15, 0);
	    world.add(mesh);

	    // aseta valo
	    Light light = new Light("valo", 0);
	    light.setPosition(0, 0, 0); // paikka 0,0,0 koska liitet��n
	    // billboardiin joka m��r�� sitten valon paikan

	    light.setAmbient(new Colorf(0.5f, 0.5f, 0.5f, 1));
	    light.setSpecular(new Colorf(0.5f, 0.5f, 0.5f, 1));
	    light.setDiffuse(new Colorf(0.8f, 0.8f, 0.8f, 1));
	    light.enable();
	    Light.disableLights();

	    lightImg = new BillBoard("light", "lightimg.png", new Vector3f(0, 10, 0), GL_LINEAR, GL_LINEAR);
	    lightImg.add(light); // liit� valo billboardiin
	    world.add(lightImg);

	    camera.setPosition(0, 10, 15);

	    screen.loadFilter(BLOOMPROG, "bloom.vert", "bloom.frag");
	    screen.loadFilter(BLURPROG, "blur.vert", "blur.frag");

	    blurParameters = new BlurParameters();
	    blurParameters.set(BLURPROG, 1.1f, 256, 0.7f);

	    // Mouse.setGrabbed(true); // hiiri ei poistu ikkunasta
	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}
    }

    public void cleanup()
    {

    }

    void preRender(float time)
    {
	time *= 5;

	input.checkKeyb(time * 3);
	input.checkMouse();

	// UHJK
	if (Keyboard.isKeyDown(Keyboard.KEY_U))
	{
	    lightImg.getPosition().y += 2 * time;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_J))
	{
	    lightImg.getPosition().y -= 2 * time;
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_H))
	{
	    lightImg.getPosition().x -= 2 * time;

	}
	if (Keyboard.isKeyDown(Keyboard.KEY_K))
	{
	    lightImg.getPosition().x += 2 * time;
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_O))
	{
	    lightImg.getPosition().z -= 2 * time;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_P))
	{
	    lightImg.getPosition().z += 2 * time;
	}
    }

    public void render(float time)
    {
	preRender(time);

	camera.updateXZ();
        
	bump.bind();
	bump.setUniform("lightPos", new float[] { lightImg.getPosition().x, lightImg.getPosition().y, lightImg.getPosition().z, 1 }, null);
	bump.setUniform("cameraPos", new float[] { camera.getPosition().x, camera.getPosition().y, camera.getPosition().z, 1 }, null);
	GLSL.unbind();
	
	world.render();
	world.renderBillboards();

	set2DMode();
	pic.render(10, 10, 1, 1, 0); // logo
	fnt.print("FPS:" + Main.calcFPS() + " objsRend:" + objectsRendered + " camxyz: " + camera.getPosition().x + " " + camera.getPosition().y + " "
		+ camera.getPosition().z, 5, 10);

	set3DMode();

    }

    
}
