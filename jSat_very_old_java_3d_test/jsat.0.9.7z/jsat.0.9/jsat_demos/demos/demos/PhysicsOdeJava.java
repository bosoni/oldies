package demos;

/**
 * @file PhysicsOdeJava.java
 *
 * @author mjt, mixut@hotmail.com
 *
 * odejava apuluokka
 */
import jsat.*;

import java.util.Vector;
import javax.vecmath.Matrix3f;
import org.lwjgl.util.vector.Matrix4f;

import org.odejava.Body;
import org.odejava.GeomBox;
import org.odejava.GeomCapsule;
import org.odejava.GeomPlane;
import org.odejava.GeomSphere;
import org.odejava.GeomTriMesh;
import org.odejava.HashSpace;
import org.odejava.Odejava;
import org.odejava.PlaceableGeom;
import org.odejava.World;
import org.odejava.collision.Contact;
import org.odejava.collision.JavaCollision;
import org.odejava.ode.Ode;

public class PhysicsOdeJava
{

    static int objs = 0;

    public final static int PLANE = 1;

    public final static int BOX = 2;

    public final static int SPHERE = 3;

    public final static int CAPSULE = 4;

    public final static int TRIMESH = 5;

    Vector<org.lwjgl.util.vector.Vector3f> positions = new Vector<org.lwjgl.util.vector.Vector3f>();

    Vector<org.lwjgl.util.vector.Matrix4f> matrixV = new Vector<org.lwjgl.util.vector.Matrix4f>();

    // World that contains our simulation space
    World world = null;

    // A simulation space that contains objects (geoms and bodies)
    HashSpace space = null;

    // Collision
    JavaCollision collision;

    // Helper class to read / write collision data (DirectBuffer)
    Contact contact;

    void setupWorld()
    {
	// Initialize Odejava
	Odejava.init();

	// Create ODE world
	world = new World();

	world.setGravity(0f, -9.81f, 0);

	// Set max interactions per step (bigger is more accurate, but slower)
	world.setStepInteractions(10);

	// Set step size (smaller is more accurate, but slower)
	world.setStepSize(0.01f);

	// Create space that contains all of our geoms / bodies
	space = new HashSpace();

	// Setup some surface parameters: maximum friction
	// Odejava.setSurfaceMu(Float.MAX_VALUE);

	// Use JavaCollision
	collision = new JavaCollision(world);
	// Setup DirectBuffers reader
	contact = new Contact(collision.getContactIntBuffer(), collision.getContactFloatBuffer());

	// Sets the surface properties - see the javadocs for more info
	collision.setSurfaceMu(1f);
	collision.setSurfaceBounce(0.14f);
	collision.setSurfaceBounceVel(0.1f);
	collision.setSurfaceMode(Ode.dContactBounce | Ode.dContactApprox1);
	collision.setSurfaceMode(0);
	collision.setSurfaceMu(Float.MAX_VALUE);
    }

    /**
     * Clean up native ODE objects. Call this before ending your Java
     * program.
     */
    public void cleanup()
    {
	positions.clear();
	// rotations.clear();
	matrixV.clear();

	space.delete();
	collision.delete();
	world.delete();
	Ode.dCloseODE();
    }

    void addObject(Object3D obj, org.lwjgl.util.vector.Vector3f size, float mass, int mode)
    {
	objs++;
	org.lwjgl.util.vector.Vector3f pos = obj.getPosition();
	org.lwjgl.util.vector.Vector3f rot = obj.getRotation();

	obj.matrix = new Matrix4f();
	Matrix4f mat = obj.matrix;

	switch (mode)
	{
	case PLANE:
	{
	    // Create plane
	    GeomPlane groundGeom = new GeomPlane(rot.x, rot.y, rot.z, pos.x); // rot
	    // on
	    // planella
	    // normaali
	    space.add(groundGeom);

	    // Static geometry
	    // PlaceableGeom planeGeom = new GeomBox("plane"+objs, 100f, 1f,
	    // 100f);
	    // planeGeom.setPosition(pos.x, pos.y, pos.z);
	    // space.add(planeGeom);

	    break;
	}
	case BOX:
	{
	    // static
	    if (mass == 0)
	    {
		PlaceableGeom geom = new GeomBox("box" + objs, size.x, size.y, size.z);
		geom.setPosition(pos.x, pos.y, pos.z);
		space.add(geom);
	    } else
	    {
		// Create a box geom and set it to body (dynamic object)
		Body box = new Body("box" + objs, world, new GeomBox(size.x, size.y, size.z));
		space.addBodyGeoms(box);
		box.setPosition(pos.x, pos.y, pos.z);
		box.adjustMass(mass);

		positions.add(pos);
		matrixV.add(mat);
	    }

	    break;
	}
	case SPHERE:
	{
	    if (mass == 0)
	    {
		PlaceableGeom geom = new GeomSphere("sphere" + objs, size.x);
		geom.setPosition(pos.x, pos.y, pos.z);
		space.add(geom);
	    } else
	    {
		// Create a sphere geom and set it to body (dynamic object)
		Body sphere = new Body("sphere" + objs, world, new GeomSphere(size.x));
		space.addBodyGeoms(sphere);
		sphere.setPosition(pos.x, pos.y, pos.z);
		sphere.adjustMass(mass);

		positions.add(pos);
		matrixV.add(mat);
	    }

	    break;
	}

	case CAPSULE:
	{
	    if (mass == 0)
	    {
		PlaceableGeom geom = new GeomCapsule("caps" + objs, size.x, size.y);
		geom.setPosition(pos.x, pos.y, pos.z);
		space.add(geom);
	    } else
	    {
		Body caps = new Body("sphere" + objs, world, new GeomCapsule(size.x, size.y));
		space.addBodyGeoms(caps);
		caps.setPosition(pos.x, pos.y, pos.z);
		caps.adjustMass(mass);

		positions.add(pos);
		matrixV.add(mat);
	    }

	    break;
	}

	case TRIMESH:
	{
	    Mesh mesh = obj.getMesh(0);
	    float[] vert = new float[mesh.vertex.length * 3];
	    int[] ind = new int[obj.getMesh(0).faces.length * 3];

	    for (int v = 0; v < mesh.vertex.length; v++)
	    {
		vert[3 * v] = mesh.vertex[v].x;
		vert[3 * v + 1] = mesh.vertex[v].y;
		vert[3 * v + 2] = mesh.vertex[v].z;
	    }
	    for (int v = 0; v < obj.getMesh(0).faces.length; v++)
	    {
		ind[3 * v] = obj.getMesh(0).faces[v][0];
		ind[3 * v + 1] = obj.getMesh(0).faces[v][1];
		ind[3 * v + 2] = obj.getMesh(0).faces[v][2];
	    }

	    if (mass == 0)
	    {
		PlaceableGeom geom = new GeomTriMesh("trimesh" + objs, vert, ind);
		geom.setPosition(pos.x, pos.y, pos.z);
		space.add(geom);
	    } else
	    {
		// Create a sphere geom and set it to body (dynamic object)
		Body tri = new Body("trimesh" + objs, world, new GeomTriMesh(vert, ind));
		space.addBodyGeoms(tri);
		tri.setPosition(pos.x, pos.y, pos.z);
		tri.adjustMass(mass);

		positions.add(pos);
		matrixV.add(mat);
	    }
	    break;
	}
	}

    }

    void update(float step)
    {
	if (step != 0)
	{
	    world.setStepSize(step);
	}

	// Collide objects in given space
	collision.collide(space);

	// Read & modify contact information
	// iterateContacts();

	// Add all contacts to contact jointGroup
	collision.applyContacts();

	world.stepFast();

	// p�ivit� kaikkien objektien paikat
	for (int q = 0; q < positions.size(); q++)
	{
	    org.lwjgl.util.vector.Vector3f pos = positions.get(q);

	    Body body = (Body) world.getBodies().get(q);
	    pos.x = body.getPosition().x;
	    pos.y = body.getPosition().y;
	    pos.z = body.getPosition().z;

	    Matrix4f rot = matrixV.get(q);
	    Matrix3f m = body.getRotation();
	    // mat3 -> mat4
	    rot.m00 = m.m00;
	    rot.m10 = m.m10;
	    rot.m20 = m.m20;
	    rot.m01 = m.m01;
	    rot.m11 = m.m11;
	    rot.m21 = m.m21;
	    rot.m02 = m.m02;
	    rot.m12 = m.m12;
	    rot.m22 = m.m22;
	    rot.m03 = 0;
	    rot.m13 = 0;
	    rot.m23 = 0;
	    rot.m30 = 0;
	    rot.m31 = 0;
	    rot.m32 = 0;
	    rot.m33 = 1;
	}
    }
}
