package demos;

/**
 * @file Test12.java
 *
 * @author mjt, mixut@hotmail.com
 *
 */
/**
 * skybox, objektin lookAt
 *
 */
import jsat.*;
import org.lwjgl.input.Keyboard;
import org.lwjgl.util.vector.Vector3f;
import static org.lwjgl.opengl.GL11.*;

public class Test12 extends BaseGame
{
    Input input = new Input();

    Font fnt = null;

    Image2D pic = null;

    BillBoard lightImg = null;

    Object3D ob1, ob2;

    public void init()
    {

	try
	{
	    setDisplayMode();

	    fnt = new Font("font.png");
	    pic = new Image2D("jsat.png");

	    Object3D mesh = new Object3D("scene", "scene1.obj");
	    world.add(mesh);

	    // pari objektia.
	    ob1 = new Object3D("obj", "obj.obj", 5, 5, 5, false);
	    ob1.setPosition(new Vector3f(0, 10, 25));
	    world.add(ob1);
	    ob2 = Object3D.makeClone("clone", ob1);
	    ob2.setPosition(new Vector3f(5, 30, 0));
	    world.add(ob2);

	    // aseta valo
	    Light light = new Light("valo", 0);
	    light.setPosition(0, 0, 0); // paikka 0,0,0 koska liitet��n
	    // billboardiin joka m��r�� sitten valon
	    // paikan
	    light.setAmbient(new Colorf(0.1f, 0.1f, 0.1f, 0));
	    light.setSpecular(new Colorf(0.2f, 0.2f, 0.2f, 1));
	    light.setDiffuse(new Colorf(0.4f, 0.4f, 0.4f, 1));
	    light.enable();

	    lightImg = new BillBoard("light", "lightimg.png", new Vector3f(0, 10, 0), GL_LINEAR, GL_LINEAR);
	    lightImg.add(light);
	    world.add(lightImg);

	    camera.setPosition(0, 10, 15);

	    skybox.load("plainsky_", "jpg"); // nimi ja p��te esim t�ll�
	    // ladataan plainsky_top.jpg,
	    // plainsky_bottom.jpg, jne

	    // Mouse.setGrabbed(true); // hiiri ei poistu ikkunasta
	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}
    }

    public void cleanup()
    {

    }

    void preRender(float time)
    {
	time *= 5;

	input.checkKeyb(time * 3);
	input.checkMouse();

	// UHJK
	if (Keyboard.isKeyDown(Keyboard.KEY_U))
	{
	    ob2.getPosition().z -= time;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_J))
	{
	    ob2.getPosition().z += time;
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_H))
	{
	    ob2.getPosition().x -= time;

	}
	if (Keyboard.isKeyDown(Keyboard.KEY_K))
	{
	    ob2.getPosition().x += time;
	}

	// yl�s/alas
	if (Keyboard.isKeyDown(Keyboard.KEY_O))
	{
	    ob2.getPosition().y += time;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_L))
	{
	    ob2.getPosition().y -= time;
	}

	ob1.lookAt(ob2.getPosition());

    }

    public void render(float time)
    {
	preRender(time);

	skybox.render(camera);
	camera.updateXZ();

	world.render();

	world.renderBillboards();
	set2DMode();
	pic.render(10, 10, 1, 1, 0); // logo

	fnt.print("FPS:" + Main.calcFPS() + " mode:" + mode + " objsRend:" + objectsRendered + " camxyz: " + camera.getPosition().x + " "
		+ camera.getPosition().y + " " + camera.getPosition().z, 5, 10);
	set3DMode();

    }

}
