package demos;

/**
 * @file Test1.java
 *
 * @author mjt, mixut@hotmail.com
 *
 * ruudulla n�kyv� -z,  monitorista ulos +z
 *
 */

/*
 * Stencil shadow -testi
 *
 * lataa billboardin (lightimg) ja liitt�� siihen valon.
 * lis�� billobardin worldiin.
 *
 *
 * hiirennappi pohjassa ja hiirt� liikuttamalla voi vaihtaa kuvakulmaa, kuten
 * m�ys nuolin�pp�imill�.
 *
 * w,s,a,d liikuttaa kameraa.
 *
 * billboardia liikuttamalla u,j,h,k -napeista valo liikkuu mukana.
 */
import jsat.*;
import org.lwjgl.input.Keyboard;
import org.lwjgl.util.vector.Vector3f;
import static org.lwjgl.opengl.GL11.*;

public class Test1 extends BaseGame
{
    Input input = new Input();

    Font fnt = null;

    Image2D pic = null;

    BillBoard lightImg = null;

    public void init()
    {

	try
	{
	    setDisplayMode();

	    useShadowVolumes(true);

	    fnt = new Font("sylfaen14.PNG");
	    pic = new Image2D("jsat.png");

	    Object3D mesh = new Object3D("scene", "scene1.obj");
	    world.add(mesh);

	    // aseta valo
	    Light light = new Light("valo", 0);
	    light.setPosition(0, 0, 0); // paikka 0,0,0 koska liitet��n
	    // billboardiin joka m��r�� sitten valon
	    // paikan
	    light.setAmbient(new Colorf(0.4f, 0.4f, 0.4f, 1f));
	    light.setSpecular(new Colorf(0.2f, 0.2f, 0.2f, 1));
	    light.setDiffuse(new Colorf(0.4f, 0.4f, 0.4f, 1));
	    light.enable();

	    lightImg = new BillBoard("light", "lightimg.png", new Vector3f(0, 10, 0), GL_LINEAR, GL_LINEAR);
	    lightImg.add(light);
	    world.add(lightImg);

	    camera.setPosition(0, 10, 15);

	    // Mouse.setGrabbed(true); // hiiri ei poistu ikkunasta
	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}
    }

    public void cleanup()
    {

    }

    void preRender(float time)
    {
	time *= 5;

	input.checkKeyb(time * 3);
	input.checkMouse();

	// UHJK
	if (Keyboard.isKeyDown(Keyboard.KEY_U))
	{
	    lightImg.getPosition().y += time;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_J))
	{
	    lightImg.getPosition().y -= time;
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_H))
	{
	    lightImg.getPosition().x -= time;

	}
	if (Keyboard.isKeyDown(Keyboard.KEY_K))
	{
	    lightImg.getPosition().x += time;
	}

    }

    public void render(float time)
    {
	preRender(time);

	camera.updateXZ();

	world.render();

	world.renderBillboards();
	set2DMode();
	pic.render(10, 10, 1, 1, 0); // logo

	fnt.print("FPS:" + Main.calcFPS() + " mode:" + mode + " objsRend:" + objectsRendered + " camxyz: " + camera.getPosition().x + " "
		+ camera.getPosition().y + " " + camera.getPosition().z, 5, 10);
	set3DMode();
    }

}
