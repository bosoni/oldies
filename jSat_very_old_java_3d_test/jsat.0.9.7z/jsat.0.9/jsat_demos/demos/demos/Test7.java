package demos;

/**
 * @file Test7.java
 *
 * @author mjt, mixut@hotmail.com
 *
 * ruudulla n�kyv� -z,  monitorista ulos +z
 *
 */
/*
 * make 3d object -testi
 *
 * luo objekteja extrudella ja lathella.
 * luo my�s laatikon ja pallon.
 * asettaa v�rit.
 *
 * n�ytt�� rumalta. ..joojoo mik� ei n�ytt�is.. :)
 *
 * koska n�ill� ei ole textureita, pit�� olla glDisable(GL_TEXTURE_2D);
 */
import jsat.*;
import org.lwjgl.input.Keyboard;
import static org.lwjgl.opengl.GL11.*;
import org.lwjgl.util.vector.Vector3f;

public class Test7 extends BaseGame
{
    Input input = new Input();

    Font fnt = null;

    Image2D pic = null;

    BillBoard lightImg = null;

    public void init()
    {

	try
	{
	    setDisplayMode();

	    fnt = new Font("font.png");
	    pic = new Image2D("jsat.png");

	    // aseta valo
	    Light light = new Light("valo", 0);
	    light.setPosition(0, 0, 0); // paikka 0,0,0 koska liitet��n
	    // billboardiin joka m��r�� sitten valon
	    // paikan

	    light.setAmbient(new Colorf(0.1f, 0.1f, 0.1f, 1));
	    light.setSpecular(new Colorf(0.2f, 0.2f, 0.2f, 1));
	    light.setDiffuse(new Colorf(0.4f, 0.4f, 0.4f, 1));
	    light.enable();

	    lightImg = new BillBoard("light", "lightimg.png", new Vector3f(1, 4, 3), GL_LINEAR, GL_LINEAR);
	    lightImg.add(light);
	    world.add(lightImg);

	    camera.setPosition(0, 1, 15);

	    // Mouse.setGrabbed(true); // hiiri ei poistu ikkunasta

	    makeObjects();

	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}
    }

    public void cleanup()
    {

    }

    // luo objektit vertex datoista
    void makeObjects()
    {
	// luo laatikko
	Object3D box = Make3DObject.box(new Vector3f(2, 4, 2));
	box.setPosition(5, 1, -2);
	box.getMesh(0).setEmission(new Colorf(0f, 0f, 1f));
	world.add(box);

	// luo pallo
	Object3D sphere = Make3DObject.sphere(new Vector3f(1, 1.5f, 0), 10, 10);
	sphere.setPosition(0, 3, 0);
	sphere.getMesh(0).setDiffuse(new Colorf(0f, 0f, 1f));
	sphere.getMesh(0).setEmission(new Colorf(1f, 0f, 1f));
	world.add(sphere);

	// luo joku obu, extrude test
	Vector3f[] vert = new Vector3f[5];
	vert[0] = new Vector3f(0, 3, 0);
	vert[1] = new Vector3f(1, 3, 0);
	vert[2] = new Vector3f(2, 0, 0);
	vert[3] = new Vector3f(-2, 0, 0);
	vert[4] = new Vector3f(-1, 3, 0);
	Object3D mobj = Make3DObject.extrude(vert, 2, true);
	mobj.setPosition(-5, 0, -2);
	mobj.getMesh(0).setSpecular(new Colorf(1f, 1f, 0f));
	mobj.getMesh(0).setEmission(new Colorf(0f, 1f, 0f)); // vihre� v�ri
	world.add(mobj);

	// lathe test
	Vector3f[] v = new Vector3f[4];
	v[0] = new Vector3f(0, 2, 0);
	v[1] = new Vector3f(2, 1, 0);
	v[2] = new Vector3f(3, 0, 0);
	v[3] = new Vector3f(1, -1, 0);
	Object3D lobj = Make3DObject.lathe(v, 4);
	lobj.getMesh(0).setDiffuse(new Colorf(0f, 1f, 0f)); // vihre� v�ri
	lobj.getMesh(0).setSpecular(new Colorf(0f, 1f, 0f));
	lobj.getMesh(0).setEmission(new Colorf(0f, 1f, 0f));
	world.add(lobj);

    }

    void preRender(float time)
    {
	time *= 5;

	input.checkKeyb(time * 4);
	input.checkMouse();

	// UHJK
	if (Keyboard.isKeyDown(Keyboard.KEY_U))
	{
	    lightImg.getPosition().y += 2 * time;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_J))
	{
	    lightImg.getPosition().y -= 2 * time;
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_H))
	{
	    lightImg.getPosition().x -= 2 * time;

	}
	if (Keyboard.isKeyDown(Keyboard.KEY_K))
	{
	    lightImg.getPosition().x += 2 * time;
	}

    }

    public void render(float time)
    {
	preRender(time);

	camera.updateXZ();

	drawGrid();
	glDisable(GL_TEXTURE_2D);

	world.render();

	glEnable(GL_TEXTURE_2D);

	world.renderBillboards();
	set2DMode();
	pic.render(10, 10, 1, 1, 0); // logo

	fnt.print("FPS:" + Main.calcFPS() + " mode:" + mode + " objsRend:" + objectsRendered + " camxyz: " + camera.getPosition().x + " "
		+ camera.getPosition().y + " " + camera.getPosition().z, 5, 10);
	set3DMode();

    }

}
