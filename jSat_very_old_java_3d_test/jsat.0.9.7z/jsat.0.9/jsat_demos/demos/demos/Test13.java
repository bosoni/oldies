package demos;

/**
 * @file Test13.java
 *
 * @author mjt, mixut@hotmail.com
 *
 * ruudulla n�kyv� -z,  monitorista ulos +z
 *
 */
/*
 * pre-renderoitu lightmap demo
 * vaatii multitexture-tuen.
 *
 * blenderilla saa luotua lightmapit kun yhdist�� kaikki objektit yhteen,
 * luo texturen, facemodessa valikoi kaikki ja wrappaa oikein, ctrl+alt+B
 * ja renderoidaan skenen polyt textureen.
 *
 * lightmapinfo apuohjelmalla otetaan lightmapin uv:t ym tiedot tekstitiedostoon jotka ladataan
 * samalla kuin skenekin. n�in saadaan lightmapattu skene.
 */

/*
 * 1, 2: vaihtaa lightmappia
 * 
 */

import org.lwjgl.input.Keyboard;

import jsat.*;
import static org.lwjgl.opengl.GL11.*;

public class Test13 extends BaseGame
{
    Input input = new Input();

    Font fnt = null;

    Texture lm1, lm2;

    public void init()
    {

	try
	{
	    setDisplayMode();

	    fnt = new Font("font.png");

	    // Mouse.setGrabbed(true); // hiiri ei poistu ikkunasta
	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}
    }

    public void cleanup()
    {

    }

    // n�yt� logo alussa
    boolean showLogo = true;

    Image2D pic = null;

    Object3D mesh = null;

    float alpha = 0, mul = 1;

    void showLogo(float time)
    {
	if (pic == null)
	    pic = new Image2D("jsat.png");

	alpha += time * 0.5f * mul;

	if (alpha >= 2)
	{
	    alpha = 1;
	    mul = -1;
	}

	if (alpha <= 0)
	    showLogo = false;

	glColor4f(1, 1, 1, alpha);
	set2DMode();
	pic.render(getScreenWidth() / 2 - pic.texture.getWidth() / 2, getScreenHeight() / 2 - pic.texture.getHeight() / 2, 1, 1, 0);
	set3DMode();
	glColor4f(1, 1, 1, 1);
	if (input.mButtonDown == 1)
	    showLogo = false;
    }

    // --------------------
    int inited = -1;

    void initDemo(int num)
    {
	if (inited == num)
	    return;
	inited = num;
	try
	{
	    if (num == 0)
	    {
		// lataa skene ja lightmap-tiedot 
		// (skaalataan v�h�n, x ja z-suunnassa 15, y-suunnassa 10 kertaisesti
		mesh = new Object3D("lmscene", "stupid_skene_.obj", "lightmapinfo.txt", 15, 10, 15, false);
		world.add(mesh);

		lm1 = mesh.getMesh(0).getTexture(1); // ota ladattu lightmap
		lm2 = Texture.loadTexture(Settings.TEXTUREDIR + "LM_2.png"); // lataa toinen lightmap

		camera.setPosition(0, 4, 5);
		glDisable(GL_LIGHTING);

		pic = null; // logon poisto
	    }
	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}

	Log.write("######################################\n1, 2: vaihtaa lightmappia");

    }

    public void render(float time)
    {
	// aseta lightmap 1
	if (Keyboard.isKeyDown(Keyboard.KEY_1))
	    for (int q = 0; q < mesh.getNumMeshes(); q++)
		mesh.getMesh(q).setTexture(1, lm1);

	// aseta lightmap 2
	if (Keyboard.isKeyDown(Keyboard.KEY_2))
	    for (int q = 0; q < mesh.getNumMeshes(); q++)
		mesh.getMesh(q).setTexture(1, lm2);

	input.checkKeyb(time * 15);
	input.checkMouse();

	if (showLogo)
	{
	    showLogo(time);
	    return;
	} else
	    initDemo(0);

	camera.updateXZ();

	world.render();

	world.renderBillboards();
	set2DMode();
	fnt.print("FPS:" + Main.calcFPS() + " mode:" + mode, 5, 10);
	set3DMode();

    }

}
