package demos;

/**
 * @file LightMapInfo.java
 *
 * @author mjt, 2008
 * mixut@hotmail.com
 *
 *
 */
/**
 * ohjelma pyyt�� 2 tiedostoa, k�ytett�v�n skenen ja skene uv-texturella (ja uv:illa).
 * 
 * ohjelma luo uv-taulukon jota voi k�ytt�� skenen kanssa ja tallentaa sen tekstitiedostoon.
 * 
 */
/*
 * blenderilla saa luotua lightmapit kun yhdist�� kaikki objektit yhteen (CTRL+J),
 * luo texturen, facemodessa (F) valikoi kaikki ja wrappaa oikein (U, unwrap smart projections), ctrl+alt+B (bake)
 * ja renderoidaan skenen polyt textureen.
 * 
 * 
 */

import java.util.Scanner;
import jsat.*;

public class LightMapInfo extends BaseGame
{
    Input input = new Input();

    Font fnt = null;

    Image2D pic = null;

    BillBoard lightImg = null;

    void saveUV(String fileName, String lightMapFileName, String outFileName)
    {
	try
	{
	    // halutaan skenest� alkup face-tiedot, eli ei korjata meshien indexej� (siit� eka false) 
	    Object3D o1 = new Object3D(false, "skene", fileName);
	    Object3D o2 = new Object3D("uv", lightMapFileName);
	    String out = "";
	    int c;

	    for (int lm = 0; lm < o2.getNumMeshes(); lm++) // joka lightmapattu meshi l�pi
	    {
		out += o2.getMesh(lm).material.getDiffuseTexName() + "\n"; // lightmapin nimi

		for (int m = 0; m < o1.getNumMeshes(); m++) // joka meshi l�pi
		{
		    for (int f = 0; f < o1.getMesh(m).faces.length; f++) // joka face
		    {
			// etsi lightmapscenest� t�m� kyseinen f-face ja k�yt�
			// lightmapscenen uv-tietoja
			for (c = 0; c < o2.getMesh(lm).faces.length; c++)
			{
			    int face[] = o1.getMesh(m).faces[f];
			    int face2[] = o2.getMesh(lm).faces[c];

			    // etsi sama face
			    if (face[0] == face2[0] && face[1] == face2[1] && face[2] == face2[2])
			    {
				// l�ytyi. tallenna uv arvot
				for (int w = 0; w < 3; w++)
				{
				    int ti = o2.getMesh(lm).uvIndex[c][w];
				    out += o2.getMesh(lm).uv[ti].x + "\n";
				    out += o2.getMesh(lm).uv[ti].y + "\n";
				}
			    }
			}
		    }
		}
	    }

	    FileIO fileOut = new FileIO();
	    // tallenna tiedot
	    if (fileOut.createFile(Settings.DATADIR + outFileName) == true)
	    {
		fileOut.writeFile(out);

		Log.write("* tiedot tallennettu tiedostoon " + Settings.DATADIR + outFileName);
	    }

	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}

    }

    @Override
    public void init()
    {
	Log.write("LightMapInfo  -mjt, 2008");

	System.out.println("Anna skenen tiedostonimi (esim stupid_skene_.obj (tiedostoa haetaan " + Settings.DATADIR + " hakemistosta)): ");
	Scanner in = new Scanner(System.in);
	String f1 = in.next();

	System.out.println("Anna lightmapatun skenen tiedostonimi (esim stupid_skene_with_LM.obj (tiedostoa haetaan " + Settings.DATADIR + " hakemistosta)):");
	String f2 = in.next();

	System.out.println("Anna luotavan uv-tekstitiedoston nimi (esim out.txt (tallentuu " + Settings.DATADIR + " hakemistoon)): ");
	String outfile = in.next();

	try
	{
	    setDisplayMode();

	    // tallenna uv:t
	    saveUV(f1, f2, outfile);
	    // ladataan uudelleen skene ja luotu uv-tiedot, n�yt� skene
	    Object3D mesh = new Object3D("lmscene", f1, outfile, 5, 5, 5);
	    world.add(mesh);

	    Light.disableLights();
	    camera.setPosition(0, 10, 15);

	    // Mouse.setGrabbed(true); // hiiri ei poistu ikkunasta
	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}

    }

    @Override
    public void cleanup()
    {

    }

    @Override
    public void render(float time)
    {
	input.checkKeyb(time * 15);
	input.checkMouse();

	camera.updateXZ();
	world.render();
    }
}
