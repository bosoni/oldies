package demos;

/**
 * @file Test3.java
 *
 * @author mjt, mixut@hotmail.com
 *
 */

/*
 * Shadow mapping -testi
 *
 * hiirennappi pohjassa ja hiirt� liikuttamalla voi vaihtaa kuvakulmaa, kuten
 * m�ys nuolin�pp�imill�.
 *
 * w,s,a,d liikuttaa kameraa.
 *
 * billboardia liikuttamalla u,j,h,k -napeista valo liikkuu mukana.
 */
import jsat.*;
import org.lwjgl.input.Keyboard;
import static org.lwjgl.opengl.GL11.*;
import org.lwjgl.util.vector.Vector3f;

public class Test3 extends BaseGame
{
    Input input = new Input();

    Font fnt = null;

    Image2D pic = null;

    BillBoard lightImg = null;

    /**
     * aseta glsl shader
     * 
     * 1 tapa k�ytt�� shadereita. ladataan jokaiselle objektille shader ja
     * sit� k�ytet��n kun renderoidaan.
     */
    void loadShaders()
    {
	for (int a = 0; a < world.getNumNodes(); a++)
	{
	    Object3D tmpobj = null;
	    if (world.getNode(a) instanceof Object3D)
		tmpobj = (Object3D) world.getNode(a);
	    else
		continue;

	    for (int b = 0; b < tmpobj.getNumMeshes(); b++)
	    {
		Mesh tmp = (Mesh) tmpobj.getMesh(b);
		tmp.shader = new GLSL();

		if (Settings.GL10_11_12)
		    tmp.shader.loadPrograms("shadow_1pass.vert", "shadow_1pass_2.frag"); // ei tee varjoa
		else
		    tmp.shader.loadPrograms("shadow_1pass.vert", "shadow_1pass.frag");

		tmp.shader.bind();
		tmp.shader.setUniform("diffuse", null, new int[] { 0 });
		tmp.shader.setUniform("shadow0", null, new int[] { 1 });
		tmp.shader.setUniform("lightmask", null, new int[] { 2 });
		tmp.shader.setUniform("lightEnergy", new float[] { 120 }, null); // valon
		// kirkkaus
		// (suurempi=kirkkaampi)
		tmp.shader.setUniform("ambient", new float[] { 0.5f }, null); // kuinka
		// tumma
		// objekti
		// on
		// (pienempi=tummempi)
	    }

	}
	GLSL.unbind();
    }

    public void init()
    {

	try
	{
	    setDisplayMode();

	    useShadowMapping(true);

	    fnt = new Font("font.png");
	    pic = new Image2D("jsat.png");

	    Object3D mesh = new Object3D("scene", "scene1.obj");
	    world.add(mesh);

	    // aseta valo
	    Light light = new Light("valo", 0);
	    light.setPosition(0, 0, 0); // paikka 0,0,0 koska liitet��n
	    // billboardiin joka m��r�� sitten valon
	    // paikan
	    light.setAmbient(new Colorf(0.0f, 0.1f, 0f, 1));
	    light.setSpecular(new Colorf(1.0f, 0.1f, 0f, 1));
	    light.setDiffuse(new Colorf(0.5f, 0.5f, 0.5f, 1));
	    light.enable();

	    lightImg = new BillBoard("light", "lightimg.png", new Vector3f(0, 10, 0), GL_LINEAR, GL_LINEAR);
	    lightImg.add(light);
	    world.add(lightImg);

	    shadowMap.setPosition(lightImg.getPosition()); // aseta
	    // seuraamaan
	    // valoa

	    camera.setPosition(0, 10, 15);

	    loadShaders();

	    // Mouse.setGrabbed(true); // hiiri ei poistu ikkunasta
	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}
    }

    public void cleanup()
    {

    }

    void preRender(float time)
    {
	time *= 5;

	input.checkKeyb(time * 4);
	input.checkMouse();

	// UHJK
	if (Keyboard.isKeyDown(Keyboard.KEY_U))
	{
	    lightImg.getPosition().y += 2 * time;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_J))
	{
	    lightImg.getPosition().y -= 2 * time;
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_H))
	{
	    lightImg.getPosition().x -= 2 * time;

	}
	if (Keyboard.isKeyDown(Keyboard.KEY_K))
	{
	    lightImg.getPosition().x += 2 * time;
	}

    }

    public void render(float time)
    {
	preRender(time);

	camera.updateXZ();

	// renderoi skene varjostettuna. (render k�ytt�� ladattua shaderia)
	shadowMap.renderShadowMapped();
	GLSL.unbind(); // shaderi pois

	world.renderBillboards();
	set2DMode();
	pic.render(10, 10, 1, 1, 0); // logo

	fnt.print("FPS:" + Main.calcFPS() + " objsRend:" + objectsRendered + " camxyz: " + camera.getPosition().x + " " + camera.getPosition().y + " "
		+ camera.getPosition().z, 5, 10);
	set3DMode();

    }

}
