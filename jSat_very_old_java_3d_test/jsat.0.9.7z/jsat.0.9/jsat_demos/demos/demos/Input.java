package demos;

/**
 * @file Input.java
 *
 * @author mjt, mixut@hotmail.com
 *
 */
import jsat.*;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.util.vector.Vector3f;

/**
 * n�ppisk�sittelij�. tarkistaa my�s t�rm�ykset.
 * 
 */
public class Input
{
    static boolean checkCollision = true;

    private static float dist = 2f; // milt� et�isyydelt� collision

    void setDistance(float _dist)
    {
	dist = _dist;
    }

    Input()
    {
    }

    Input(boolean _checkCollision)
    {
	checkCollision = _checkCollision;
    }

    /**
     * tarkista t�rm�ys vanhan ja uuden paikan perusteella. palauttaa true
     * jos t�rm�si johonkin polyyn.
     * 
     * t�nkk�-collision, surkea viritelm�
     */
    boolean checkCollision(Vector3f start, Vector3f end)
    {
	if (checkCollision)
	    return BaseGame.ray.checkIntersection(start, end, BaseGame.world);

	return false;
    }

    void checkKeyb(float animTime)
    {
	float distance = dist + animTime * 2;

	// fog p��lle
	if (Keyboard.isKeyDown(Keyboard.KEY_9))
	{
	    // luo sumu
	    Fog.setColor(new Colorf(0.5f, 0.6f, 0.7f));
	    Fog.createFog(2, 20, 90, 0.1f);

	}
	// fog pois
	if (Keyboard.isKeyDown(Keyboard.KEY_0))
	{
	    Fog.disableFog();
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_LSHIFT))
	    animTime *= 4;

	if (Keyboard.isKeyDown(Keyboard.KEY_ESCAPE))
	{
	    Main.setRunning(false);
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_UP))
	{
	    BaseGame.camera.upDownXZ(-animTime);
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_DOWN))
	{
	    BaseGame.camera.upDownXZ(animTime);
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_LEFT))
	{
	    BaseGame.camera.turnXZ(-animTime);
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_RIGHT))
	{
	    BaseGame.camera.turnXZ(animTime);
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_R))
	{
	    Vector3f start = new Vector3f(BaseGame.camera.getPosition());
	    BaseGame.camera.getPosition().y += distance + animTime;
	    if (checkCollision(start, BaseGame.camera.getPosition()) == true)
	    {
		BaseGame.camera.setPosition(start);
	    } else
	    {
		BaseGame.camera.setPosition(start);
		BaseGame.camera.getPosition().y += animTime;
	    }
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_F))
	{
	    Vector3f start = new Vector3f(BaseGame.camera.getPosition());
	    BaseGame.camera.getPosition().y -= distance - animTime;
	    if (checkCollision(start, BaseGame.camera.getPosition()) == true)
	    {
		BaseGame.camera.setPosition(start);
	    } else
	    {
		BaseGame.camera.setPosition(start);
		BaseGame.camera.getPosition().y -= animTime;
	    }
	}

	// vasemmalle
	if (Keyboard.isKeyDown(Keyboard.KEY_A))
	{
	    Vector3f start = new Vector3f(BaseGame.camera.getPosition());
	    BaseGame.camera.strafeXZ(-distance);
	    if (checkCollision(start, BaseGame.camera.getPosition()) == true)
	    {
		BaseGame.camera.setPosition(start);
	    } else
	    {
		BaseGame.camera.setPosition(start);
		BaseGame.camera.strafeXZ(-animTime);
	    }
	}

	// oikealle
	if (Keyboard.isKeyDown(Keyboard.KEY_D))
	{
	    Vector3f start = new Vector3f(BaseGame.camera.getPosition());
	    BaseGame.camera.strafeXZ(distance);
	    if (checkCollision(start, BaseGame.camera.getPosition()) == true)
	    {
		BaseGame.camera.setPosition(start);
	    } else
	    {
		BaseGame.camera.setPosition(start);
		BaseGame.camera.strafeXZ(animTime);
	    }

	}

	// eteen
	if (Keyboard.isKeyDown(Keyboard.KEY_W))
	{
	    Vector3f start = new Vector3f(BaseGame.camera.getPosition());
	    BaseGame.camera.moveXZ(distance);
	    if (checkCollision(start, BaseGame.camera.getPosition()) == true)
	    {
		BaseGame.camera.setPosition(start);
	    } else
	    {
		BaseGame.camera.setPosition(start);
		BaseGame.camera.moveXZ(animTime);
	    }

	}

	// taakse
	if (Keyboard.isKeyDown(Keyboard.KEY_S))
	{
	    Vector3f start = new Vector3f(BaseGame.camera.getPosition());
	    BaseGame.camera.moveXZ(-distance);
	    if (checkCollision(start, BaseGame.camera.getPosition()) == true)
	    {
		BaseGame.camera.setPosition(start);
	    } else
	    {
		BaseGame.camera.setPosition(start);
		BaseGame.camera.moveXZ(-animTime);
	    }
	}

    }

    // ----
    int cursorX = 0, cursorY = 0, mButtonDown = 0, mouseYInverted = 1, mouseWheel = 0;

    void checkMouse()
    {
	int mouseDX = Mouse.getDX();
	int mouseDY = Mouse.getDY();
	mouseWheel = Mouse.getDWheel();

	updateMouse();

	if ((mButtonDown & 1) == 1)
	{
	    BaseGame.camera.turnXZ(mouseDX);
	    BaseGame.camera.upDownXZ(-mouseDY * mouseYInverted);
	}
    }

    void updateMouse()
    {
	cursorX = Mouse.getX();
	cursorY = Mouse.getY();

	while (Mouse.next())
	{
	    if (Mouse.getEventButtonState() == true)
	    {
		if (Mouse.getEventButton() == 0)
		    mButtonDown += 1;
		if (Mouse.getEventButton() == 1)
		    mButtonDown += 2;
		if (Mouse.getEventButton() == 2)
		    mButtonDown += 4;
	    } else
	    {
		if (Mouse.getEventButton() == 0)
		    mButtonDown -= 1;
		if (Mouse.getEventButton() == 1)
		    mButtonDown -= 2;
		if (Mouse.getEventButton() == 2)
		    mButtonDown -= 4;
	    }

	}

    }

}

/**
 * 6dof kamera
 */
class Input6DOF
{
    static boolean checkCollision = true;

    private static float dist = 2f; // milt� et�isyydelt� collision

    void setDistance(float _dist)
    {
	dist = _dist;
    }

    Input6DOF()
    {
    }

    Input6DOF(boolean _checkCollision)
    {
	checkCollision = _checkCollision;
    }

    /**
     * tarkista t�rm�ys vanhan ja uuden paikan perusteella. palauttaa true
     * jos t�rm�si johonkin polyyn.
     */
    boolean checkCollision(Vector3f start, Vector3f end)
    {
	if (checkCollision)
	    return BaseGame.ray.checkIntersection(start, end, BaseGame.world);
	return false;
    }

    void checkKeyb(float animTime)
    {
	float distance = dist + animTime * 3;

	if (Keyboard.isKeyDown(Keyboard.KEY_LSHIFT))
	    animTime *= 4;

	if (Keyboard.isKeyDown(Keyboard.KEY_ESCAPE))
	{
	    Main.setRunning(false);
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_A))
	{
	    Vector3f start = new Vector3f(BaseGame.camera.getPosition());
	    BaseGame.camera.strafeRight(-distance);
	    if (checkCollision(start, BaseGame.camera.getPosition()) == true)
	    {
		BaseGame.camera.strafeRight(distance);
	    } else
	    {
		BaseGame.camera.strafeRight(distance);
		BaseGame.camera.strafeRight(-animTime);
	    }
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_D))
	{
	    Vector3f start = new Vector3f(BaseGame.camera.getPosition());
	    BaseGame.camera.strafeRight(distance);
	    if (checkCollision(start, BaseGame.camera.getPosition()) == true)
	    {
		BaseGame.camera.strafeRight(-distance);
	    } else
	    {
		BaseGame.camera.strafeRight(-distance);
		BaseGame.camera.strafeRight(animTime);
	    }
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_W))
	{
	    Vector3f start = new Vector3f(BaseGame.camera.getPosition());
	    BaseGame.camera.moveForward(-distance);
	    if (checkCollision(start, BaseGame.camera.getPosition()) == true)
	    {
		BaseGame.camera.moveForward(distance);
	    } else
	    {
		BaseGame.camera.moveForward(distance);
		BaseGame.camera.moveForward(-animTime);
	    }
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_S))
	{
	    Vector3f start = new Vector3f(BaseGame.camera.getPosition());
	    BaseGame.camera.moveForward(distance);
	    if (checkCollision(start, BaseGame.camera.getPosition()) == true)
	    {
		BaseGame.camera.moveForward(-distance);
	    } else
	    {
		BaseGame.camera.moveForward(-distance);
		BaseGame.camera.moveForward(animTime);
	    }

	}

	// roll
	if (Keyboard.isKeyDown(Keyboard.KEY_Z))
	{
	    BaseGame.camera.rotateZ(animTime);
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_X))
	{
	    BaseGame.camera.rotateZ(-animTime);
	}

    }

    // ----
    int cursorX = 0, cursorY = 0, mButtonDown = 0, mouseYInverted = 1, mouseWheel = 0;

    void checkMouse()
    {
	int mouseDX = Mouse.getDX();
	int mouseDY = Mouse.getDY();
	mouseWheel = Mouse.getDWheel();

	updateMouse();

	if (mButtonDown == 1)
	{
	    BaseGame.camera.rotateY(-mouseDX);
	    BaseGame.camera.rotateX(mouseDY * mouseYInverted);
	}
    }

    void updateMouse()
    {

	cursorX = Mouse.getX();
	cursorY = Mouse.getY();

	while (Mouse.next())
	{
	    if (Mouse.getEventButtonState() == true)
	    {
		if (Mouse.getEventButton() == 0)
		    mButtonDown += 1;
		if (Mouse.getEventButton() == 1)
		    mButtonDown += 2;
		if (Mouse.getEventButton() == 2)
		    mButtonDown += 4;
	    } else
	    {
		if (Mouse.getEventButton() == 0)
		    mButtonDown -= 1;
		if (Mouse.getEventButton() == 1)
		    mButtonDown -= 2;
		if (Mouse.getEventButton() == 2)
		    mButtonDown -= 4;
	    }

	}

    }

}
