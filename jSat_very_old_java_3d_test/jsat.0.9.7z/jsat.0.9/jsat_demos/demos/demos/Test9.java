package demos;

/**
 * @file Test9.java
 *
 * @author mjt, mixut@hotmail.com
 *
 */

/*
 * fbo test
 * 6dof kamera (t�ysin vapaa kamera, liikkuu sinne minne nokka n�ytt��)
 *
 * w,s eteen/taakse
 * a,d sivuille
 * z,x roll
 *
 *
 */
import jsat.*;
import static org.lwjgl.opengl.GL11.*;
import org.lwjgl.util.vector.Vector3f;

public class Test9 extends BaseGame
{
    Input6DOF input = new Input6DOF();

    Font fnt = null;

    Image2D pic = null;

    BillBoard lightImg = null;

    public void init()
    {
	try
	{
	    setDisplayMode();

	    fnt = new Font("font.png");
	    pic = new Image2D("jsat.png");

	    Object3D mesh = new Object3D("scene", "scene1.obj");
	    world.add(mesh);

	    // aseta valo
	    Light light = new Light("valo", 0);
	    light.setPosition(0, 0, 0); // paikka 0,0,0 koska liitet��n
	    // billboardiin joka m��r�� sitten valon
	    // paikan

	    light.setAmbient(new Colorf(0.4f, 0.4f, 0.4f, 1));
	    light.setSpecular(new Colorf(1.0f, 0.1f, 0f, 1));
	    light.setDiffuse(new Colorf(0.3f, 0.5f, 0.8f, 1));
	    light.enable();

	    lightImg = new BillBoard("light", "lightimg.png", new Vector3f(0, 10, 0), GL_LINEAR, GL_LINEAR);
	    lightImg.add(light);
	    world.add(lightImg);

	    shadowMap.setPosition(lightImg.getPosition());

	    camera.setPosition(0, 10, 15);

	    // Mouse.setGrabbed(true); // hiiri ei poistu ikkunasta

	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}
    }

    public void cleanup()
    {

    }

    public void render(float time)
    {
	input.checkKeyb(time * 5);
	input.checkMouse();

	camera.update(); // 6 DOF cam, t�ysin vapaa liikkuvuus, ei vain
	// xz tasolla

	/*
	 * // pid� up-vektori aina yl�sp�in. roll ei tietty en�� t�m�n j�lkeen
	 * toimi. camera.getUp().x=0; camera.getUp().y=1; camera.getUp().z=0;
	 */

	/*
	 * bindataan texture1 asetetaan viewport ja rendataan.
	 * 
	 * fbo:lla world.render renderoi suoraan textureen, jolloin copyscreen
	 * ei tee mit��n. jos fbo:ta ei tueta, copyscreen nappaa kuvan talteen.
	 */
	screen.bind(); // renderoi screen textureen (jos fbo)
	screen.setViewport();
	world.render();
	world.renderBillboards();
	screen.copyScreen(); // kopioi kuva talteen (jos ei fbo)
	screen.restoreViewport();
	Screen.unbind();
	// ---------

	glClear(Settings.CLEARBUFFERS);

	set2DMode();
	screen.renderQuads(5, 10, 0.4f); // renderoi screen-texture
	// moneen kertaan pienent�en
	// joka piirrolla

	pic.render(10, 10, 1, 1, 0); // logo

	fnt.print("FPS:" + Main.calcFPS() + " objsRend:" + objectsRendered + " camxyz: " + camera.getPosition().x + " " + camera.getPosition().y + " "
		+ camera.getPosition().z, 5, 10);

	set3DMode();

    }

}
