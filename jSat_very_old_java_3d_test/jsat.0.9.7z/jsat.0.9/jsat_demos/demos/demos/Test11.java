package demos;

/**
 * @file Test11.java
 *
 * @author mjt, mixut@hotmail.com
 *
 */
/*
 * py�rittely�
 * muutama pallo liitetty toisiinsa ja py�ritell��n.
 *
 *
 */
import jsat.*;
import org.lwjgl.util.vector.Vector3f;

public class Test11 extends BaseGame
{
    Input input = new Input();

    Font fnt = null;

    Image2D pic = null;

    Object3D sun, planet1, planet2, moon1, moon2;

    public void init()
    {
	try
	{
	    setDisplayMode();

	    fnt = new Font("font.png");
	    pic = new Image2D("jsat.png");

	    sun = new Object3D("sun", "ball.obj");
	    sun.setPosition(0, 0, 0);
	    sun.useShader(false); // ball.obj:lla on toon shaderi, otetaan
	    // se pois k�yt�st� n�in.

	    planet1 = new Object3D("planet1", "planet.obj");
	    planet1.setPosition(-10, 0, 0);
	    sun.add(planet1);

	    // kloonaa
	    planet2 = Object3D.makeClone("planet2", planet1);
	    planet2.setPosition(13, 0, -10);
	    sun.add(planet2);

	    moon1 = Object3D.makeClone("moon1", sun);
	    moon1.setPosition(4, 0, -2);
	    // moon1.scale(0.5f, 0.5f, 0.5f); (ei onnistu kloonatuille
	    // obuille)
	    planet1.add(moon1);

	    moon2 = Object3D.makeClone("moon2", sun);
	    moon2.setPosition(2, 0, 4);
	    planet2.add(moon2);

	    // aseta palloille sphere bounding testaus
	    sun.setBoundingMode(-1, BoundingArea.SPHERE);
	    world.add(sun);

	    // aseta valo
	    Light light = new Light("sun", 0);
	    light.setPosition(0, 0, 0);
	    light.setAmbient(new Colorf(0.5f, 0.5f, 0f, 1));
	    light.setSpecular(new Colorf(3.0f, 3.0f, 3.0f, 1));
	    light.setDiffuse(new Colorf(0.8f, 0.8f, 0.3f, 1));
	    light.enable();
	    world.add(light); // lis�� valo

	    camera.setPosition(0, 7, 45);

	    // Mouse.setGrabbed(true); // hiiri ei poistu ikkunasta
	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}
    }

    public void cleanup()
    {

    }

    void preRender(float time)
    {
	input.checkKeyb(time * 3);
	input.checkMouse();
	time *= 1000;

	sun.addRotation(0, 0.1f, 0);

	planet1.addRotation(0, time * 0.4f, 0);
	planet2.addRotation(0, time * 0.2f, 0);

	moon1.addRotation(time * 0.4f, 0, 0);
	moon2.addRotation(0, 0, time * 2.2f);

	// kuut py�r�th�� viel� v�h�n kun planeetta on rendattu..
	Vector3f.add(planet1.rotateObject, new Vector3f(0, -0.3f * time, 0), planet1.rotateObject);
	Vector3f.add(planet2.rotateObject, new Vector3f(0, -0.5f * time, 0), planet2.rotateObject);
    }

    public void render(float time)
    {
	preRender(time);

	camera.updateXZ();
	world.render();

	world.renderBillboards();

	set2DMode();
	pic.render(10, 10, 1, 1, 0); // logo

	fnt.print("FPS:" + Main.calcFPS() + " objsRend:" + objectsRendered + " camxyz: " + camera.getPosition().x + " " + camera.getPosition().y + " "
		+ camera.getPosition().z, 5, 10);
	set3DMode();
    }

}
