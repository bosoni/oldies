package demos;

/**
 * @file Test6.java
 *
 * @author mjt, mixut@hotmail.com
 *
 * ruudulla n�kyv� -z,  monitorista ulos +z
 *
 */
/*
 * ray-triangle testausta
 *
 *
 */
import jsat.*;
import org.lwjgl.input.Keyboard;
import static org.lwjgl.opengl.GL11.*;
import org.lwjgl.util.vector.Vector3f;

public class Test6 extends BaseGame
{
    Input input = new Input();

    Font fnt = null;

    Image2D pic = null;

    BillBoard lightImg = null;

    Intersection ray = new Intersection();

    public void init()
    {
	Settings.DEBUG = true; // n�kee mihin polygoniin vektori osuu

	try
	{
	    setDisplayMode();

	    fnt = new Font("palatino14.PNG");
	    pic = new Image2D("jsat.png");

	    // aseta valo
	    Light light = new Light("valo", 0);
	    light.setPosition(0, 0, 0); // paikka 0,0,0 koska liitet��n
	    // billboardiin joka m��r�� sitten valon
	    // paikan

	    light.setAmbient(new Colorf(0.1f, 0.1f, 0f, 1));
	    light.setSpecular(new Colorf(0.5f, 0.5f, .5f, 1));
	    light.setDiffuse(new Colorf(0.5f, 0.4f, 0.7f, 1));
	    light.enable();

	    lightImg = new BillBoard("light", "lightimg.png", new Vector3f(0, 5, 0), GL_LINEAR, GL_LINEAR);
	    lightImg.add(light);
	    world.add(lightImg);

            // �l� k��nn� objektia 90 astetta, siit� tuo vika parametri
	    Object3D obj = new Object3D("star", "star_obj.obj", false); 
	    world.add(obj);

	    camera.setPosition(0, 5, 25);

	    // Mouse.setGrabbed(true); // hiiri ei poistu ikkunasta
	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}
    }

    public void cleanup()
    {

    }

    void preRender(float time)
    {
	input.checkKeyb(time * 4);
	input.checkMouse();

	// UHJK
	if (Keyboard.isKeyDown(Keyboard.KEY_U))
	{
	    lightImg.getPosition().z -= time;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_J))
	{
	    lightImg.getPosition().z += time;
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_H))
	{
	    lightImg.getPosition().x -= time;

	}
	if (Keyboard.isKeyDown(Keyboard.KEY_K))
	{
	    lightImg.getPosition().x += time;
	}

    }

    public void render(float time)
    {
	preRender(time);

	camera.updateXZ();
	world.render();

	// ---
	drawGrid();
	glPolygonMode(GL_FRONT, GL_LINE);
	world.render();
	glPolygonMode(GL_FRONT, GL_FILL);

	// viiva lightImg:sta alasp�in
	Vector3f newp = new Vector3f(lightImg.getPosition());
	newp.y = 2;
	newp.y = 1;
	newp.y = -10;

	glColor4f(1, 1, 0, 1); // yellow line
	glBegin(GL_LINES);
	glVertex3f(lightImg.getPosition().x, lightImg.getPosition().y, lightImg.getPosition().z);
	glVertex3f(newp.x, newp.y, newp.z);
	glEnd();
	glColor4f(1, 1, 1, 1); // white color
	glEnable(GL_TEXTURE_2D);

	boolean intersection = false;
	if (ray.checkIntersection(lightImg.getPosition(), newp, world) == true)
	    intersection = true;

	world.renderBillboards();
	set2DMode();
	pic.render(10, 10, 1, 1, 0); // logo

	fnt.print("FPS:" + Main.calcFPS() + ((intersection == true) ? "  intersection" : "  no intersection"), 5, 10);
	set3DMode();

    }

}
