package demos;

/**
 * @file Test20.java
 *
 * @author mjt, mixut@hotmail.com
 *
 *
 */
/*
 *
 * picking, object callback
 * ruudulla erilaisia objekteja ja hiiren p��lle viemisell� vaikutetaan niihin haluamallaan tavalla
 *
 */
import jsat.*;
import static org.lwjgl.opengl.GL11.*;
import org.lwjgl.util.vector.Vector3f;

public class Test20 extends BaseGame implements Callback
{
    Input input = new Input(false);

    public void init()
    {

	try
	{
	    setDisplayMode();

	    // lataa objekti. seuraa my�s samaa reitti� mit� kamera, v�h�n
	    // edell� vaan
	    Object3D sobj = new Object3D("obu", "car.obj");
	    world.add(sobj);
	    sobj.setCallback(this); // rendauksesa kutsutaan t�m�n luokan
	    // objAction metodia

	    // luo muutama objekti
	    Object3D tmp = Object3D.makeClone("klooni1", sobj);
	    tmp.setPosition(2, 0, 0);
	    tmp.setRotation(0, 0, 90);
	    tmp.setCallback(this);
	    world.add(tmp);

	    tmp = Object3D.makeClone("klooni2", sobj);
	    tmp.setPosition(4, 0, 0);
	    tmp.setCallback(this);
	    world.add(tmp);

	    tmp = Object3D.makeClone("skaalattava", sobj);
	    tmp.setPosition(6, 0, 0);
	    tmp.setCallback(this);
	    world.add(tmp);

	    camera.setPosition(0, 0, 3);

	    // aseta valo
	    Light light = new Light("valo", 0);
	    light.setPosition(10, 50, 10);
	    light.setAmbient(new Colorf(0.1f, 0.1f, 0f, 1));
	    light.setSpecular(new Colorf(0.5f, 0.5f, 0.5f, 1));
	    light.setDiffuse(new Colorf(0f, 0.4f, 0.7f, 1));
	    light.enable();
	    world.add(light);

	    // Mouse.setGrabbed(true); // hiiri ei poistu ikkunasta
	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}
    }

    public void cleanup()
    {

    }

    public void render(float time)
    {
	input.checkKeyb(time * 5);
	input.checkMouse();

	camera.updateXZ();

	// ota valittu objekti v�rin perusteella
	ObjectInfo.getSelection((float) input.cursorX, (float) input.cursorY);

	// select bufferin perusteella (voi olla hidas jollain ajureilla)
	// world.getSelection_2((float) input.cursorX, (float)input.cursorY);

	world.render();

    }

    /*
     * callback metodi. kutsutaan kun renderoidaan objektia, id on objektin
     * tunniste
     * 
     * obj: alkuper�inen objekti pos rot: paikka ja asento. obj on aina
     * alkuper�inen (ei siis klooni) mutta n�m� pos ja rot voi olla kloonin
     * paikka ja asento.
     */
    public void objAction(String objName, int id, Node obj, Vector3f pos, Vector3f rot)
    {

	// nyt rendataan valittu objekti
	if (ObjectInfo.selectedObj == id)
	{
	    glColor3f(1, 0, 0); // valittu obu punaiseksi

	    // yhden kloonin nimi on skaalattava, skaalataan y-suunnassa
	    if (objName.equals("skaalattava"))
	    {
		glScalef(1, 2, 1);
	    }

	    // toiselle tehd��n jotain muuta
	    if (objName.equals("klooni1"))
	    {
		glColor3f(0, 0f, 1f); // vaihda v�ri
		rot.y += 0.1f;
	    }
	} else
	{
	    glColor3f(1, 1, 1);

	}

    }

    float frot = 0;

}
