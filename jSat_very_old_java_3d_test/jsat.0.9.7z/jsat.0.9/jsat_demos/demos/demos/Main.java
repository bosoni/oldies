package demos;

/**
 * @file Main.java
 *
 * @author mjt, mixut@hotmail.com
 *
 */
import jsat.*;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Scanner;
import murlen.util.fscript.BasicIO;
import murlen.util.fscript.FSException;
import org.lwjgl.opengl.Display;
import org.lwjgl.util.Timer;
import static org.lwjgl.opengl.GL11.*;

public class Main
{
    private static boolean running = true;

    private static Timer timer = new Timer();

    private static float animTime = 0, lastTime = 0, startTime = 0;

    private static int frames = 0, fps = 0;

    static BaseGame app = null;

    public static void main(String[] args)
    {
	// ladataan settings.cfg tiedosto jossa kerrottu hakemistot ym
	// asetuksia.
	try
	{
	    BasicIO fscript = loadBasicScript("settings.cfg"); // lataa
	    // asetukset

	    Settings.TITLE = (String) fscript.getScriptVar("TITLE");
	    Settings.width = (Integer) fscript.getScriptVar("width");
	    Settings.height = (Integer) fscript.getScriptVar("height");
	    Settings.bpp = (Integer) fscript.getScriptVar("bpp");

	    Settings.fullScreen = ((Integer) fscript.getScriptVar("fullScreen") == 0) ? false : true;
	    Settings.vsync = ((Integer) fscript.getScriptVar("vsync") == 0) ? false : true;
	    Settings.alphaBits = (Integer) fscript.getScriptVar("alphaBits");
	    Settings.zbufBits = (Integer) fscript.getScriptVar("zbufBits");
	    Settings.stencilBits = (Integer) fscript.getScriptVar("stencilBits");

	    Settings.DATADIR = (String) fscript.getScriptVar("DATADIR");
	    Settings.TEXTUREDIR = (String) fscript.getScriptVar("TEXTUREDIR");
	    Settings.FONTDIR = (String) fscript.getScriptVar("FONTDIR");
	    Settings.SHADERDIR = (String) fscript.getScriptVar("SHADERDIR");

	    Log.printNotes = ((Integer) fscript.getScriptVar("printNotes") == 0) ? false : true;
	    Settings.DISABLE_FBO = ((Integer) fscript.getScriptVar("DISABLE_FBO") == 0) ? false : true;
	    Settings.DISABLE_VBO = ((Integer) fscript.getScriptVar("DISABLE_VBO") == 0) ? false : true;

	    
	} catch (FSException e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}

	int t = 1;

	// mik� testi ajetaan?
	if (args.length > 0)
	{
	    t = Integer.parseInt(args[0]);
	} else
	{
	    System.out.println("Valitse: ");
	    System.out.println("* 1-20, esimerkit");
	    System.out.println("* 91, LightMapInfo-apuohjelma joka nappaa lightmap skenen uv:t talteen");
	    System.out.println("* 92, SetBoundings-apuohjelma, fysiikkamoottoria varten (kesken)");
	    System.out.println("\n> ");
	    Scanner in = new Scanner(System.in);
	    t = in.nextInt();
	}

	switch (t)
	{
	// esimerkit:
	case 91:
	    app = new LightMapInfo();
	    break;
	case 92:
	{
	    SetBoundingsGUI.initGUI();
	    app = new SetBoundings();
	    break;
	}

	case 1:
	    app = new Test1();
	    break;
	case 2:
	    app = new Test2();
	    break;
	case 3:
	    app = new Test3();
	    break;
	case 4:
	    app = new Test4();
	    break;
	case 5:
	    app = new Test5();
	    break;
	case 6:
	    app = new Test6();
	    break;
	case 7:
	    app = new Test7();
	    break;
	case 8:
	    app = new Test8();
	    break;
	case 9:
	    app = new Test9();
	    break;
	case 10:
	    app = new Test10();
	    break;
	case 11:
	    app = new Test11();
	    break;
	case 12:
	    app = new Test12();
	    break;
	case 13:
	    app = new Test13();
	    break;
	case 14:
	    app = new Test14();
	    break;
	case 15:
	    app = new Test15();
	    break;
	case 16: 
	    app=new Test16();
            break;
	case 17:
	    app = new Test17();
	    break;
	case 18:
	    app = new Test18();
	    break;
	case 19:
	    app = new Test19();
	    break;
	case 20:
	    app = new Test20();
	    break;

	default:
	{
	    FileIO.ErrorMessage("Test " + t + " not found!");
	}
	}

	Log.createLog("log.txt");
	app.init();

	/**
	 * aloittaa silmukan jossa suoritetaan render() looppaa niin kauan
	 * kunnes ikkuna suljetaan tai running==false
	 */
	while (!Display.isCloseRequested() && (running == true))
	{
	    calcTime();
	    if (Display.isVisible())
	    {
		setupFrame();

		app.render(animTime);
	    } else
	    {
		try
		{
		    Thread.sleep(200);
		} catch (InterruptedException i)
		{
		}
	    }

	    Display.update();
	}

	closeApp();
    }

    /**
     * kutsutaan loopissa ennenkuin tehd��n mit��n muuta calcPositions
     * laskee objekteille oikeat paikat 3d-avaruudessa (childien paikat
     * parenttien paikoista)
     */
    static void setupFrame()
    {
	glClear(Settings.CLEARBUFFERS);
	glLoadIdentity();
	BaseGame.world.calcPositions();
	BaseGame.objectsRendered = 0;
    }

    static void closeApp()
    {
	// loppul�tin�t
	app.cleanup();
	Log.closeFile();
	System.exit(0);
    }

    static void setRunning(boolean fl)
    {
	running = fl;
    }

    static void calcTime()
    {
	Timer.tick();
	animTime = timer.getTime() - lastTime;
	lastTime = timer.getTime();
    }

    static int calcFPS()
    {
	// laske fps
	frames++;
	if (timer.getTime() - startTime >= 1)
	{
	    startTime = timer.getTime();
	    fps = frames;
	    frames = 0;
	}
	return fps;
    }

    static BasicIO loadBasicScript(String file)
    {
	BasicIO fscript = new BasicIO();
	try
	{
	    URL url = null;
	    FileReader f = null;
	    // tsekkaa l�ytyyk� tiedosto file
	    if (Main.app != null)
	    {
		url = Main.app.getClass().getResource(file);
		if (url == null)
		{
		    File fl = new File(file);
		    if (!fl.exists())
		    {
			return null;
		    }
		}
	    }

	    if (url == null)
	    {
		f = new FileReader(file);
		fscript.load(f);
	    } else
	    {
		InputStream in = Main.app.getClass().getResourceAsStream(file);
		InputStreamReader inR = new InputStreamReader(in);
		fscript.load(inR);
	    }
	    fscript.run();

	} catch (IOException e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	} catch (FSException e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}

	return fscript;
    }
}
