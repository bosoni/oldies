package demos;

/**
 * @file Test10.java
 *
 * @author mjt, mixut@hotmail.com
 *
 */

/*
 * DDS, S3TC testaus
 *
 * normal mapping
 *
 * http://zarria.net/nrmphoto/nrmphoto.html
 */
import jsat.*;
import org.lwjgl.input.Keyboard;
import static org.lwjgl.opengl.GL11.*;
import org.lwjgl.util.vector.Vector3f;

public class Test10 extends BaseGame
{
    Input input = new Input();

    Font fnt = null;

    Image2D pic = null;

    BillBoard lightImg = null;

    Texture normalmap;

    GLSL bumpShader = new GLSL();

    public void init()
    {

	try
	{
	    setDisplayMode();

	    fnt = new Font("font.png");
	    pic = new Image2D("jsat.DDS"); // lataa dxt5 pakattu texture

	    Object3D mesh = new Object3D("scene", "scene1.obj");
	    // mesh.generateTangentSpace();
	    world.add(mesh);

	    // aseta valo
	    Light light = new Light("valo", 0);
	    light.setPosition(0, 0, 0); // paikka 0,0,0 koska liitet��n
	    // billboardiin joka m��r�� sitten valon
	    // paikan
	    light.setAmbient(new Colorf(0, 0, 0, 0));
	    light.setSpecular(new Colorf(0.7f, 0.7f, 0.7f, 1));
	    light.setDiffuse(new Colorf(0.7f, 0.7f, 0.7f, 1));
	    light.enable();

	    lightImg = new BillBoard("light", "lightimg.DDS", new Vector3f(0, 10, 0), GL_LINEAR, GL_LINEAR);
	    lightImg.add(light);
	    world.add(lightImg);

	    camera.setPosition(0, 10, 15);

	    bumpShader.loadPrograms("normalmapping.vert", "normalmapping.frag");
	    bumpShader.bind();
	    bumpShader.setUniform("texture", null, new int[] { 0 });
	    bumpShader.setUniform("normalMap", null, new int[] { 1 });
	    GLSL.unbind();

	    normalmap = new Texture(Settings.TEXTUREDIR + "normal_map.jpg");

	    // Mouse.setGrabbed(true); // hiiri ei poistu ikkunasta
	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}
    }

    public void cleanup()
    {

    }

    void preRender(float time)
    {
	time *= 5;

	input.checkKeyb(time * 3);
	input.checkMouse();

	// UHJK
	if (Keyboard.isKeyDown(Keyboard.KEY_U))
	{
	    lightImg.getPosition().y += 2 * time;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_J))
	{
	    lightImg.getPosition().y -= 2 * time;
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_H))
	{
	    lightImg.getPosition().x -= 2 * time;

	}
	if (Keyboard.isKeyDown(Keyboard.KEY_K))
	{
	    lightImg.getPosition().x += 2 * time;
	}

    }

    public void render(float time)
    {
	preRender(time);

	camera.updateXZ();

	normalmap.bind(1);

	bumpShader.bind();
	bumpShader.setUniform("lightPos", new float[] { lightImg.getPosition().x, lightImg.getPosition().y, lightImg.getPosition().z, 1 }, null);
	bumpShader.setUniform("cameraPos", new float[] { camera.getPosition().x, camera.getPosition().y, camera.getPosition().z, 1 }, null);

	world.render();

	GLSL.unbind(); // bumpShader

	Texture.unbind(1);

	world.renderBillboards();
	set2DMode();
	pic.render(10, 10, 1, 1, 0); // logo

	fnt.print("FPS:" + Main.calcFPS() + " objsRend:" + objectsRendered + " camxyz: " + camera.getPosition().x + " " + camera.getPosition().y + " "
		+ camera.getPosition().z, 5, 10);
	set3DMode();

    }

}
