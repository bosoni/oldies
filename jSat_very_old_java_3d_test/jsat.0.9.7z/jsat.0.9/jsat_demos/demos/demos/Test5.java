package demos;

/**
 * @file Test5.java
 *
 * @author mjt, mixut@hotmail.com
 *
 */
/*
 * terrain -testi
 *
 */
import jsat.*;

public class Test5 extends BaseGame
{
    Input input = new Input(false); // ei t�rm�ystarkistusta

    Font fnt = null;

    Image2D pic = null;

    Terrain terrain = new Terrain("terrain");

    public void init()
    {
	try
	{
	    setDisplayMode();

	    fnt = new Font("font.png");
	    pic = new Image2D("jsat.png");

	    // aseta valo
	    Light light = new Light("valo", 0);
	    light.setPosition(230, 50, 220);

	    light.setAmbient(new Colorf(0.1f, 0.1f, 0f, 1));
	    light.setSpecular(new Colorf(1.0f, 0.1f, 0f, 1));
	    light.setDiffuse(new Colorf(0f, 0.4f, 0.7f, 1));
	    light.enable();

	    camera.setPosition(50, 20, 200);

	    // Mouse.setGrabbed(true); // hiiri ei poistu ikkunasta

	    // Settings.texture3DSupported=true; // pakotus
	    String[] names = { "grass.jpg", "sand.jpg", "part.jpg" };
	    terrain.load("terrain.jpg", names);

	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}
    }

    public void cleanup()
    {

    }

    void preRender(float time)
    {
	time *= 5;

	input.checkKeyb(time * 3);
	input.checkMouse();

    }

    public void render(float time)
    {
	preRender(time);

	camera.updateXZ();

	terrain.render();

	terrain.cameraOnGround(15); // aseta kameran y seuraamaan maaston
	// pintaa (parametrina matka maasta)

	world.renderBillboards();
	set2DMode();
	pic.render(10, 10, 1, 1, 0); // logo

	fnt.print("FPS:" + Main.calcFPS() + " terrainpolys:" + terrain.getPolyCount() + " objsRend:" + objectsRendered + " camxyz: " + camera.getPosition().x
		+ " " + camera.getPosition().y + " " + camera.getPosition().z, 5, 10);

	set3DMode();

    }

}
