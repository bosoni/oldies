package demos;

/**
 * @file Test4.java
 *
 * @author mjt, mixut@hotmail.com
 *
 */

/*
 * shadow mapping -testi
 *--
 * renderoi z-buffer valostap�in, sitten varjot kamerasta, otetaan talteen
 * renderoi skene ilman varjoja
 * blurrataan varjot skenen p��lle
 *
 *
 * hiirennappi pohjassa ja hiirt� liikuttamalla voi vaihtaa kuvakulmaa, kuten
 * m�ys nuolin�pp�imill�.
 *
 * w,s,a,d liikuttaa kameraa.
 *
 * billboardia liikuttamalla u,j,h,k -napeista valo liikkuu mukana.
 */
import jsat.*;
import org.lwjgl.input.Keyboard;
import static org.lwjgl.opengl.GL11.*;
import org.lwjgl.util.vector.Vector3f;

public class Test4 extends BaseGame
{
    final int RENDSHADOWS=0, BLURPROG = 1;

    final int SHADOWPASS = 0, TEXTUREPASS = 1;

    Input input = new Input();

    Font fnt = null;

    Image2D pic = null;

    BillBoard lightImg = null;

    BlurParameters blurParameters;

    GLSL shaders[] = new GLSL[2];

    /**
     * aseta glsl shader
     * 
     * 2.tapa ladata shaderit. asetetaan shader ennen renderointia jolloin
     * sit� k�ytet��n
     */
    void loadShaders()
    {
	shaders[SHADOWPASS] = new GLSL();
	shaders[TEXTUREPASS] = new GLSL();

	if (Settings.GL10_11_12)
	    shaders[SHADOWPASS].loadPrograms("shadowpass.vert", "shadowpass_2.frag");
	else
	    shaders[SHADOWPASS].loadPrograms("shadowpass.vert", "shadowpass.frag");

	shaders[SHADOWPASS].bind();
	shaders[SHADOWPASS].setUniform("shadow0", null, new int[] { 1 });
	shaders[SHADOWPASS].setUniform("lightmask", null, new int[] { 2 });

	shaders[TEXTUREPASS] = new GLSL();
	shaders[TEXTUREPASS].loadPrograms("texture_pass.vert", "texture_pass.frag");
	shaders[TEXTUREPASS].bind();
	shaders[TEXTUREPASS].setUniform("diffuse", null, new int[] { 0 });
	shaders[TEXTUREPASS].setUniform("lightmap", null, new int[] { 1 });
	shaders[TEXTUREPASS].setUniform("lightEnergy", new float[] { 150.0f }, null); // valon kirkkaus (suurempi=kirkkaampi)
	shaders[TEXTUREPASS].setUniform("ambient", new float[] { 0.5f }, null); // objektin
	// tummuus (pienempi=tummempi)

	GLSL.unbind();
    }

    public void init()
    {
	try
	{
	    setDisplayMode();

	    useShadowMapping(true);

	    fnt = new Font("font.png");
	    pic = new Image2D("jsat.png");

	    Object3D mesh = new Object3D("scene", "scene1.obj");
	    world.add(mesh);

	    // aseta valo
	    Light light = new Light("valo", 0);
	    light.setPosition(0, 0, 0); // paikka 0,0,0 koska liitet��n
	    // billboardiin joka m��r�� sitten valon
	    // paikan

	    light.setAmbient(new Colorf(0.1f, 0.1f, 0.1f, 1));
	    light.setSpecular(new Colorf(0.3f, 0.3f, 0.3f, 1));
	    light.setDiffuse(new Colorf(0.4f, 0.4f, 0.6f, 1));
	    light.enable();

	    lightImg = new BillBoard("light", "lightimg.png", new Vector3f(0, 10, 0), GL_LINEAR, GL_LINEAR);
	    lightImg.add(light);
	    world.add(lightImg);

	    shadowMap.setPosition(lightImg.getPosition());

	    camera.setPosition(0, 10, 15);

	    loadShaders();

	    screen.loadFilter(RENDSHADOWS, "rendshadow.vert", "rendshadow.frag"); 
	    screen.loadFilter(BLURPROG, "blur.vert", "blur_shadow.frag");

	    blurParameters = new BlurParameters(BLURPROG, 0.5f, 256, 1.5f);

	    // Mouse.setGrabbed(true); // hiiri ei poistu ikkunasta

	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}
    }

    public void cleanup()
    {

    }

    void preRender(float time)
    {
	time *= 5;

	input.checkKeyb(time * 3);
	input.checkMouse();

	// UHJK
	if (Keyboard.isKeyDown(Keyboard.KEY_U))
	{
	    lightImg.getPosition().y += 2 * time;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_J))
	{
	    lightImg.getPosition().y -= 2 * time;
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_H))
	{
	    lightImg.getPosition().x -= 2 * time;

	}
	if (Keyboard.isKeyDown(Keyboard.KEY_K))
	{
	    lightImg.getPosition().x += 2 * time;
	}

    }

    public void render(float time)
    {
	preRender(time);

	camera.updateXZ();

	shaders[SHADOWPASS].bind(); // shadowpass -shaderi
	// renderoi vain varjot screen-textureen, k�ytet��n valostap�in olevaa
	// z-bufferia apuna (otetaan samassa metodissa)
	shadowMap.renderShadowMapped2Texture();

	// renderoi skene ilman varjoja
	shaders[TEXTUREPASS].bind(); // texture_pass -shader
	world.render();

	GLSL.unbind();

	set2DMode();

	screen.renderShadows(RENDSHADOWS, 5, 5, 0.2f); // renderoi shadowmapattu kuva skenen p��lle
//	screen.blur(blurParameters); // tai toinen vaihtoehto, blurrataan

	pic.render(10, 10, 0.5f, 0.5f, 35); // logo
	fnt.print("FPS:" + Main.calcFPS() + " objsRend:" + objectsRendered + " camxyz: " + camera.getPosition().x + " " + camera.getPosition().y + " "
		+ camera.getPosition().z, 5, 10);

	set3DMode();

	// renderoidaan vasta blurrauksen j�lkeen joten valoa (aurinko
	// bitmappia) ei blurrata
	world.renderBillboards();

    }

}
