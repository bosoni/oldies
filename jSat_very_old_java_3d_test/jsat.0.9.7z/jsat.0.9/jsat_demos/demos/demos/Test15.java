package demos;

/**
 * @file Test15.java
 *
 * @author mjt, mixut@hotmail.com
 *
 * ruudulla n�kyv� -z,  monitorista ulos +z
 *
 */
/**
 * huone testi
 *
 * n�pp�imet:
 *
 * 1, 2 : skenen yhten� objektina / jaettu huoneisiin jolloin cullataan joka huone
 * 
 * eli rooms2.obj (1 objekti) ja rooms2_eriks_valot.obj (huoneet erikseen, valoineen)
 * 
 */
import jsat.*;

import org.lwjgl.input.Keyboard;
import org.lwjgl.util.vector.Vector3f;
import static org.lwjgl.opengl.GL11.*;

public class Test15 extends BaseGame
{
    Input input = new Input();

    Font fnt = null;

    BillBoard lightImg = null;

    public void init()
    {

	try
	{
	    setDisplayMode();

	    fnt = new Font("georgia12.PNG");

	    // Mouse.setGrabbed(true); // hiiri ei poistu ikkunasta
	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}
    }

    public void cleanup()
    {

    }

    // n�yt� logo alussa
    boolean showLogo = true;

    Image2D pic = null;

    float alpha = 0, mul = 1;

    void showLogo(float time)
    {
	if (pic == null)
	    pic = new Image2D("jsat.png");
	alpha += time * 0.5f * mul;
	if (alpha >= 2)
	{
	    alpha = 1;
	    mul = -1;
	}
	if (alpha <= 0)
	    showLogo = false;
	glColor4f(0, alpha, 0, alpha);
	set2DMode();
	pic.render(getScreenWidth() / 2 - pic.texture.getWidth() / 2, getScreenHeight() / 2 - pic.texture.getHeight(), 2, 4, 0);
	set3DMode();
	glColor4f(1, 1, 1, 1);
	if (input.mButtonDown == 1)
	    showLogo = false;
    }

    boolean divided = false;

    // --------------------
    int inited = -1;

    void initDemo(int num)
    {
	if (inited == num)
	    return;
	inited = num;
	try
	{
	    if (num == 0)
	    {
		world.remove("scene");
		world.remove("valo");
		world = null;
		world = new Node("world");

		Object3D mesh = null;
		if (divided == true)
		    mesh = new Object3D("scene", "rooms2_eriks.obj", 30, 10, 30, false);
		else
		    mesh = new Object3D("scene", "rooms2.obj", 30, 10, 30, false);

		BillBoard.billboards.clear();

		// aseta valoihin lightImg
		for (int q = 0; q < Light.lights.size(); q++)
		{
		    lightImg = new BillBoard("light", "lightimg.png", new Vector3f(0, 10, 0), GL_LINEAR, GL_LINEAR);
		    lightImg.setPosition(Light.lights.get(q).getPosition());
		    world.add(lightImg);
		}

		world.add(mesh);

		if (divided == false)
		{
		    // aseta valo
		    Light light = new Light("valo", 0);
		    light.setPosition(10, 50, 10);
		    light.setAmbient(new Colorf(0.1f, 0.1f, 0f, 1));
		    light.setSpecular(new Colorf(0.5f, 0.5f, 0.5f, 1));
		    light.setDiffuse(new Colorf(0f, 0.4f, 0.7f, 1));
		    light.enable();
		    world.add(light);
		}

		camera.setPosition(0, 6, 0);

		pic = null; // logon poisto

		// luo sumu
		Fog.setColor(new Colorf(0.5f, 0.6f, 0.7f));
		Fog.createFog(2, 20, 90, 0.1f); // GL_LINEAR fog
	    }
	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}

	// ohje
	Log.write("\n#########################################################\n1, 2 : vaihtaa skenen yhdest� objektista huoneisiin jaettuun skeneen.");

    }

    public void render(float time)
    {
	input.checkKeyb(time * 25);
	input.checkMouse();

	if (showLogo)
	{
	    showLogo(time);
	    return;
	} else
	    initDemo(0);

	camera.updateXZ();

	world.render();

	// 1 ja 2 n�pp�imet vaihtaa skene�, toinen on 1 objekti, toinen on
	// jaettu huoneisiin
	if (Keyboard.isKeyDown(Keyboard.KEY_1))
	{
	    divided = false;
	    inited = -1;
	    initDemo(0);
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_2))
	{
	    divided = true;
	    inited = -1;
	    Light.lights.clear();
	    initDemo(0);
	}

	world.renderBillboards();
	set2DMode();
	fnt.print("FPS:" + Main.calcFPS() + " mode:" + mode + " objsRend:" + objectsRendered + " divided: " + divided, 5, 10);

	fnt.print("Camerapos: " + camera.getPosition().x + " " + camera.getPosition().y + " " + camera.getPosition().z, 10, 30);
	set3DMode();

    }

}
