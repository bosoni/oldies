/**
 * @file Test8.java
 *
 * @author mjt, mixut@hotmail.com
 *
 */
/*
 * MD5 tiedoston lataus ja animointi -testi
 *
 * --- MD5 koodi ei toimi hyvin. blender md5 exportterin mukana
 * --- tuleva kala toimii, muut objektit ei oikein
 * --- tahdo tulla oikein (blender ja gmax testiss�). 
 * 
 * -----------------------------------------------------------------------------
 * 
 * 
 * lataa my�s ei-animoidun objektin, luomaan lis�� varjoja.
 * luo siit� klooni (muuten samat tiedot paitsi paikka ja asento)
 *
 * N�pp�imet:
 * w,s,a,d napeilla ohjaat animoitua objektia.
 * o,p liikutat ei-animoitua objektia (alkup ja kloonattua, liikkuu eri suuntiin)
 *
 * TAB vaihtaa kamerakulmaa vapaasta kikkaran taakse -kuvakulmaan jolloin kamera seuraa kikkara�.
 * silloin kameralla voi kiert�� objektien ymp�ri.
 *
 * lataa kikkaran, lataa toisen kikkaran (jota animoidaan nopeemmin kuin eka kikkara�).
 * liit� toinen kikkara ekaan.
 * luo ekasta kikkarasta klooni (animoituu t�sm�lleen samalla tavalla kuin se mist� klooni luodaan).
 * liit� ekaan kikkara�n.
 *
 * klooni-kikkarassa on valo, liikkuu kikkaran mukana.  toinen valo on skenen yl�puolella.
 *
 * world
 *   lightImg (billboard)
 *     * light
 *   mesh (scene)
 *   kikkara
 *     * kikkara1 (toinen lataus)
 *     * kikkara2 (clone)
 *         * light2
 *
 */
package demos;

import jsat.*;
import org.lwjgl.input.Keyboard;
import org.lwjgl.util.vector.Vector3f;
import static org.lwjgl.opengl.GL11.*;

public class Test8 extends BaseGame
{
    BillBoard lightImg = null;

    Input input = new Input();

    Font fnt = null;

    Image2D pic = null;

    MD5Model obj = null;

    Object3D sobj = null; // ei-animoitu liikuteltava objekti

    Object3D clone_obj = null; // ei-animoitu liikuteltava objekti

    int viewMode = 0; // 0=normaali kamera, 1=kamera kikkaran takana

    public void init()
    {
	try
	{
	    setDisplayMode();

            useShadowVolumes(true);
	    fnt = new Font("font.png");
	    pic = new Image2D("jsat.png");

            // �l�s k��nn� skene�, siit� vika false
	    Object3D mesh = new Object3D("scene", "scene2.obj", 30, 30, 30, false);
	    mesh.setPosition(75, -5, 10);
	    world.add(mesh);

	    sobj = new Object3D("s_objekti", "obj.obj");
	    sobj.setPosition(2, 3, 0);
	    world.add(sobj);

	    // kloonaa
	    clone_obj = Object3D.makeClone("clone_obj", sobj);
	    // ja anna uudet paikkatiedot
	    clone_obj.setPosition(-2, 2, 0);
	    world.add(clone_obj);

	    Light light;

	    // aseta valo
	    light = new Light("valo", 0);
	    light.setPosition(0, 0, 0); // billboard m��r�� paikan
	    light.setAmbient(new Colorf(0.5f, 0.5f, 0.5f, 1));
	    light.setSpecular(new Colorf(0.2f, 0.2f, 0.2f, 1));
	    light.setDiffuse(new Colorf(0.2f, 0.2f, 0.2f, 1));
	    light.enable();

	    lightImg = new BillBoard("light", "lightimg.png", new Vector3f(-50, 40, 50), GL_LINEAR, GL_LINEAR);
	    lightImg.add(light);
	    world.add(lightImg); // lis�� valo

	    camera.setPosition(-50, 7, -10);
	    camera.setRotation(0, -90, 0);
 
            obj = new MD5Model();
            
            obj.scale(0.5f, 0.5f, 0.5f);
            obj.load("mesh", "obj.mesh", "obj.anim"); // ei t�m�k��n ihan oikein n�y
            obj.drawSkeleton(true);
           

	    // toinen kikkara
            MD5Model obj2 = new MD5Model();
            obj2.load("mesh1", "md5fish.mesh", "md5fish.anim");
            obj2.drawSkeleton(true);
            obj2.setPosition(-1, 0, 0);
            obj.add(obj2);

	    // aseta valo
	    light = new Light("valo2", 0);
	    light.setPosition(0, 2, 0); // valo toisen kikkaran ylle
	    light.setAmbient(new Colorf(0.3f, 0.3f, 0.3f, 1));
	    light.setSpecular(new Colorf(0.3f, 0.3f, 0.3f, 1));
	    light.setDiffuse(new Colorf(0.3f, 0.3f, 0.3f, 1));
	    light.enable();

	    MD5Model clonemd5 = MD5Model.makeClone(obj, "mesh2");
	    clonemd5.setPosition(0, 0.5f, 1f); // aseta paikka
	    clonemd5.add(light); // liit� valo
	    obj.add(clonemd5); // liit� klooni alkuper�iseen kikkara�n

	    world.add(obj);

	    // Mouse.setGrabbed(true); // hiiri ei poistu ikkunasta
	} catch (Exception e)
	{
	    e.printStackTrace();
	    FileIO.ErrorMessage(e.toString());
	}
    }

    public void cleanup()
    {

    }

    void preRender(float time)
    {
	// UHJK
	float keybtime = time * 5;
	time *= 10;

	if (Keyboard.isKeyDown(Keyboard.KEY_O))
	{
	    sobj.getPosition().z += 0.2f;
	    clone_obj.getPosition().x += 0.2f;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_P))
	{
	    sobj.getPosition().z -= 0.2f;
	    clone_obj.getPosition().x -= 0.2f;
	}

	// eteen
	if (Keyboard.isKeyDown(Keyboard.KEY_U))
	{
	    MD5Model ob = (MD5Model) obj.searchByName("mesh1");
	    if (ob != null)
		ob.update(time *3 );
	    else
		Log.write("mesh1 ei l�ydy!");

	    obj.update(time);
	    obj.strafeXZ(keybtime);
	    // k�ytet��n koska objekti mallinnettu niin ett�
	    // moveXZ(keybtime); liikkuu kylki edell�
	}

	// taakse
	if (Keyboard.isKeyDown(Keyboard.KEY_J))
	{
	    obj.update(time);
	    obj.strafeXZ(-keybtime);
	}

	// vasen
	if (Keyboard.isKeyDown(Keyboard.KEY_H))
	{
	    obj.update(time);
	    obj.turnXZ(-keybtime * 50);

	}

	// oikea
	if (Keyboard.isKeyDown(Keyboard.KEY_K))
	{
	    obj.update(time);
	    obj.turnXZ(keybtime * 50);
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_TAB))
	{
	    if (viewMode == 0)
		viewMode = 11;
	    else if (viewMode == 1)
		viewMode = 10;
	} else
	{
	    if (viewMode == 10) // vapaa kamera
	    {
		viewMode = 0;

		obj.remove("camera");

		// kamera alkupaikkaan
		camera.setPosition(new Vector3f(0, 0, 0));
		camera.setRotation(0, 0, 0);
	    } else if (viewMode == 11) // seuraa objektia
	    {
		viewMode = 1;
		camera.setRotation(0, 0, 0);

		// kamera seuraamaan objektia
		camera.setPosition(new Vector3f(-4, 1, 0)); // -4 on kikkaran
		// takana, y=1
		obj.add(camera);
	    }

	}

	// muuta valoisuutta
	if ((Light) world.searchByName("valo2") != null)
	{
	    ((Light) world.searchByName("valo2")).setDiffuse(new Colorf(0.1f, 0.1f, (float) Math.sin(sin += 0.01f), 1));
	    ((Light) world.searchByName("valo2")).updateLight();
	}

    }

    static float sin = 0;

    public void render(float time)
    {
	// kikkaran liikutukset
	preRender(time);

	if (viewMode == 0)
	    camera.updateXZ(); // liikuta kameraa normaalisti
	else if (viewMode == 1)
	    camera.lookAt(obj.getPosition()); // kamera seuraa kikkara�

	// kameran liikutukset
	input.checkKeyb(time * 8);
	if (viewMode == 0)
	    input.checkMouse(); // jos kamera kikkaran takana, hiirt� ei huomioida

	world.render();

	world.renderBillboards();
	set2DMode();
	pic.render(10, 10, 1, 1, 0); // logo

	fnt.print("FPS:" + Main.calcFPS() + " objsRend:" + objectsRendered + " viewMode:" + viewMode + " camxyz: " + camera.getPosition().x + " "
		+ camera.getPosition().y + " " + camera.getPosition().z, 5, 10);

	set3DMode();

    }

}
