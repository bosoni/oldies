package demos;

/**
 * @file Test16.java
 *
 * @author mjt, mixut@hotmail.com
 *
 *
 */
/**
 *  
 * 2d test
 * 
 *  lataa parit kuvat ja vieritt�� niit� ruudulla
 * 
 * 
 * 
 */
import jsat.*;

import org.lwjgl.util.vector.Vector3f;
import static org.lwjgl.opengl.GL11.*;

public class Test16 extends BaseGame
{

    final int STARS = 100;
    BillBoard stars[] = new BillBoard[STARS];
    Input input = new Input();
    Font fnt = null;
    Image2D img[] = new Image2D[5];

    public void init()
    {
        try
        {
            setDisplayMode();

            fnt = new Font("georgia12.PNG");
            for (int q = 0; q < 5; q++)
            {
                img[q] = new Image2D();
            }
            img[0].load("CHRMWARP.JPG"); // taustalle

            img[1].load("normal_map.jpg"); // py�rim��n

            img[2].load("GRAVSTN.JPG"); // v�l�ys

            img[3].load("tree1.png");
            img[4].load("tree2.png");

            img[3].setPosition(700, 400, 0);
            img[4].setPosition(650, 400, 0);


            for (int q = 0; q < STARS; q++)
            {
                Vector3f pos = new Vector3f();
                pos.x = (float) Math.random() * 60f - 30;
                pos.y = (float) Math.random() * 60f - 30;
                pos.z = -10 - (float) Math.random() * 100f;
                stars[q] = new BillBoard("bb", "lightImg.png", pos, GL_LINEAR, GL_LINEAR);
                world.add(stars[q]);
            }


        // Mouse.setGrabbed(true); // hiiri ei poistu ikkunasta
        } catch (Exception e)
        {
            e.printStackTrace();
            FileIO.ErrorMessage(e.toString());
        }
    }

    public void cleanup()
    {
    }
    float flash = 0.5f;
    boolean flashing = false;
    float angle = 0;

    public void render(float time)
    {
        set2DMode();
        input.checkKeyb(time);

        img[0].render(0, 240, 4, 4, 0);

        glColor4f(1, 0.5f, 0.3f, 0.3f + ((float) Math.sin(angle * 0.1f) * 0.2f));
        img[1].render(0, 0, 2, 2, angle += 0.1f);

        if (Math.random() < 0.01)
        {
            flashing = true; // v�l�ys

        }
        if (flashing)
        {
            glColor4f(1, 1, 1, flash);
            img[2].render(0, 0, 5, 5, 1);
            flash -= 0.005f;
            if (flash <= 0)
            {
                flashing = false;
                flash = 0.5f;
            }
        }
        glColor4f(1, 1, 1, 1);


        // puut
        img[3].getPosition().x -= 0.5f;
        img[4].getPosition().x -= 0.3f;
        if (img[3].getPosition().x < -100)
        {
            img[3].setPosition(700, 400 + (float) Math.random() * 10, 0);
        }
        if (img[4].getPosition().x < -100)
        {
            img[4].setPosition(700, 400 + (float) Math.random() * 10, 0);
        }
        img[3].render();
        img[4].render();

        fnt.print("FPS:" + Main.calcFPS() + " mode:" + mode, 5, 10);

        set3DMode();

        for (int q = 0; q < STARS; q++)
        {
            Vector3f pos=stars[q].getPosition();
            pos.z+=0.1f;
            
            if(pos.z>=0)
            {
                pos.x = (float) Math.random() * 60f - 30;
                pos.y = (float) Math.random() * 60f - 30;
                pos.z = -100 - (float) Math.random() * 10f;
            }
        }


        world.renderBillboards();

    }
}
