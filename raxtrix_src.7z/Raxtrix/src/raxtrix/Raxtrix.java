/*
 * Raxtrix.java
 *
 * raxtrix v0.4 (tetris-klooni)
 * @author mjt
 * email: mixut@hotmail.com
 *
 * lähdekoodista:
 ** freewarea, käytä omalla vastuullasi!
 ** yksinkertainen java-peli joka käyttää java2d:tä piirtämiseen,
 ** ja ImageIO:ta kuvien lataamiseen.
 ** java ja webstart harjoitus.
 *
 * history:
 * 0.1
 * 0.2 bugikorjauksia. tarkistus checkArea metodiin ja
 * alue[] taulukko muutettu 2-ulotteiseksi, alue[][].
 * 0.3 näppäinohjeet (30.1.06)
 * 0.4 bugfix (palikat ei tippunut) piti lisätä pari Thread.sleep(200); riviä
 */
package raxtrix;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Raxtrix extends JPanel implements KeyListener
{
    Object2D tausta; // tausta image
    Object2D[] palImg = new Object2D[10]; // palikoiden imaget
    int numImg = 8; // palImg lukumäärä
    int x = 5; // palikan paikka alue taulukossa
    int y = 0; // palikan paikka alue taulukossa
    int curBlock = 0; // randomilla valitaan palikka palikat taulukosta
    int[] block = new int[9]; // tähän se palikka kopsataan
    int[] tmparray = new int[9]; // just temp
    static boolean gameOver = false; // jos true, peli loppu
    int score = 0; // pisteet
    final int lev = 17;
    final int kor = 19;

    //pelialue
    int[][] alue = new int[kor + 3][lev + 3];

    // 3x3 palikat 
    // palikoiden lukumäärä: palikat.length/9
    int[] palikat =
    {
        1, 0, 0, //
        1, 0, 0, // L
        1, 1, 0, //

        //
        1, 0, 0, //
        1, 1, 0, // 
        0, 1, 0, //

        //
        0, 1, 0, //
        1, 1, 0, //
        1, 0, 0, //

        //
        0, 1, 1, //
        0, 1, 1, //
        0, 0, 0, //

        //      
        1, 1, 1, //
        0, 0, 0, //
        0, 0, 0, //

        //
        0, 1, 0, //
        1, 1, 1, //
        0, 0, 0, //

        //
        0, 1, 0, //
        1, 1, 1, //
        0, 1, 0, //
        //  
        0, 1, 1, //
        0, 1, 1, //
        0, 0, 1, //

        //
        1, 1, 0, //
        1, 1, 0, //
        1, 0, 0, //

        //
        1, 1, 1, //
        1, 1, 1, //
        0, 1, 0, //

        //
        1, 1, 1, //
        1, 0, 1, //
        0, 0, 0, //

        //
        0, 0, 0, //
        0, 1, 0, //
        0, 0, 0, //

        //
        0, 1, 1, //
        0, 1, 0, //
        1, 1, 0 //            
    };
    int numPalikat = palikat.length / 9; // monta palikkaa
    long time = 0; // pelin nopeuteen liittyvät muuttujat
    long last = 0;
    long wait = 1000;
    long level = 0; // kun pelaa, tämä kasvaa ja peli nopeutuu (nopeus wait-level)
    static boolean firstTime = true;

    /**
     pääohjelma

     @param args the command line arguments
     */
    public static void main(String[] args)
    {
        Raxtrix main = new Raxtrix();
        main.run();
    }

    /**
     käynnistää pelin
     */
    void run()
    {
        numPalikat = palikat.length / 9;

        initGame();

        Color col = new Color(0, 0, 0);
        JFrame frame = new JFrame("Raxtrix v0.4");

        frame.setBackground(col);
        this.setBackground(col);
        frame.setSize(500, 400);

        frame.setContentPane(this);
        frame.addKeyListener(this);
        frame.setResizable(false);

        frame.addWindowListener(new WindowAdapter()
        {
            public void windowClosing(WindowEvent e)
            {
                System.exit(0);
            }
        });

        frame.setVisible(true);

        // odota kunnes painetaan S
        while (firstTime)
        {
            try
            {
                Thread.sleep(200);
            } catch (InterruptedException ex)
            {
                Logger.getLogger(Raxtrix.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        //----
        while (true)
        {
            // alustukset
            score = 0;

            int q;
            int w;

            for (q = 0; q < kor; q++)
            {
                for (w = 0; w < lev; w++)
                {
                    alue[q][w] = 0;
                }
            }

            for (q = 0; q < (kor - 1); q++)
            {
                alue[q][0] = alue[q][lev - 1] = 1; // aseta reunat
            }

            for (q = 0; q < lev; q++)
            {
                alue[kor - 1][q] = 1; // pohja
            }

            nextBlock();

            wait = 500;
            x = 5;
            y = 0;
            while (true)
            {
                // odotusaika
                time = System.currentTimeMillis();
                while (time < ((last + wait) - level))
                {
                    time = System.currentTimeMillis();
                }

                last = time;
                level = score / 400;

                if (level > 200)
                {
                    level = 200; // max nopeus
                }

                // jos palikka ei voi enää pudota alaspääin, lisää se alue taulukkoon
                if (checkArea(x, y + 1, block) == true)
                {
                    // jos ollaan painettu välilyöntiä, niin lisää pisteitä
                    if (wait <= 50)
                    {
                        score++;
                    }

                    y++;
                } else
                {
                    for (q = 0; q < 3; q++)
                    {
                        for (w = 0; w < 3; w++)
                        {
                            if (block[(q * 3) + w] >= 1)
                            {
                                //alue[((y + q) * lev) + x + w + 1] = block[(q * 3) + w];
                                alue[y + q][x + w + 1] = block[(q * 3) + w];
                            }
                        }
                    }

                    wait = 500;
                    x = 5;
                    y = 0;
                    nextBlock();

                    // tsekkaa jos tarvii hävittää rivi
                    updateArea();

                    // jos uusi palikka ei mahdu tulemaan enää, peli ohi
                    if (checkArea(x, y + 1, block) == false)
                    {
                        gameOver = true;
                        repaint();

                        break;
                    }
                }

                repaint();
            }

            // näyttää lopputekstit ja pisteet ja odottaa että painetaan R
            // jolloin gameOver=false;
            while (gameOver)
            {
                try
                {
                    Thread.sleep(200);
                } catch (InterruptedException ex)
                {
                    Logger.getLogger(Raxtrix.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    /**
     käy alue taulukon läpi ja pudottaa palikoita alaspäin jos tarvii
     */
    void updateArea()
    {
        int q;
        int w;

        for (q = 1; q < (kor - 1); q++)
        {
            boolean ok = true; // false jos rivi ei ole täynnä

            for (w = 1; w < (lev - 1); w++)
            {
                if (alue[q][w] == 0)
                {
                    score += (lev - 2);

                    ok = false;

                    break;
                }
            }

            // tiputa palikoita alaspäin
            if (ok == true)
            {
                for (int e = q; e > 1; e--)
                {
                    for (int r = 1; r < (lev - 1); r++)
                    {
                        alue[e][r] = alue[e - 1][r];
                    }
                }
            }
        }
    }

    /**
     ladataan kuvat
     */
    void initGame()
    {
        // lataa kuvat
        try
        {
            tausta = new Object2D("tausta.JPG");

            int q;

            for (q = 0; q < numImg; q++)
            {
                palImg[q] = new Object2D("pal" + (q + 1) + ".JPG");
            }
        } catch (IOException e)
        {
            e.printStackTrace();
            System.exit(0);
        }
    }

    /**
     aletaan piirtämään

     @param g
     */
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g); // tyhjennys

        Graphics2D g2d = (Graphics2D) g;

        if (firstTime == false)
        {
            drawAll(g2d);
        } else
        {
            g2d.setColor(new Color(60, 220, 40, 155));
            g2d.setFont(new Font("Dialog", Font.BOLD, 60));

            int q;
            int w;

            for (q = 0; q < 5; q++)
            {
                for (w = 0; w < 5; w++)
                {
                    g2d.drawString("RAXTRIX", 40 + w, 150 + q);
                }
            }

            g2d.setColor(new Color(70, 170, 140, 220));
            g2d.drawString("RAXTRIX", 40 + 3, 150 + 3);

            g2d.setFont(new Font("Dialog", Font.BOLD, 18));
            g2d.drawString("S - Start", 50, 190);
            g2d.drawString("Esc - Exit", 50, 210);

            g2d.drawString("Z/X  - rotate block", 50, 230);
            g2d.drawString("Left/Right arrow - move block", 50, 250);
            g2d.drawString("Space/Down arrow - drop block", 50, 270);

            g2d.drawString("by mjt /2006", 20, 360);

            g2d.setFont(new Font("Dialog", Font.BOLD, 12));
            g2d.drawString("[email: mixut@hotmail.com]", 290, 360);
        }
    }

    /**
     piirrä kaikki ruudulle (taustat, palikat, tekstit)

     @param g2d
     */
    void drawAll(Graphics2D g2d)
    {
        // piirrä tausta
        g2d.drawImage(tausta.getImage(), -80, -275, null);

        // pelialue
        g2d.setColor(Color.BLACK);
        g2d.fillRect(20, 0, (lev - 2) * 20, (kor - 1) * 20);

        // score box
        g2d.fillRect(345, 80, 140, 30);

        drawArea(g2d);

        drawBlock(g2d);

        g2d.setColor(new Color(128, 128, 255, 255));
        g2d.setFont(new Font("Dialog", Font.BOLD, 16));
        g2d.drawString("Score: " + score, 350, 100);

        g2d.setColor(new Color(10, 20, 200, 180));
        g2d.drawString("Raxtrix v0.4", 365, 20);

        if (gameOver == true)
        {
            g2d.setFont(new Font("Dialog", Font.BOLD, 35));

            // varjo
            g2d.setColor(new Color(0, 0, 0, 80));
            g2d.drawString("GAME OVER!", 56, 146);
            g2d.drawString("R  -  Restart", 56, 176);
            g2d.drawString("Esc  -  Exit", 56, 206);

            // reunat
            int q;

            // reunat
            int w;

            for (q = 0; q < 3; q++)
            {
                for (w = 0; w < 3; w++)
                {
                    g2d.drawString("GAME OVER!", 50 + w, 140 + q);
                    g2d.drawString("R   - Restart", 50 + w, 170 + q);
                    g2d.drawString("Esc - Exit", 50 + w, 200 + q);
                }
            }

            // teksti keskel
            g2d.setColor(new Color(238, 28, 55, 220));
            g2d.drawString("GAME OVER!", 51, 141);
            g2d.drawString("R   - Restart", 51, 171);
            g2d.drawString("Esc - Exit", 51, 201);
        }
    }

    /**
     asettaa block taulukkoon seuraavan palikan
     */
    void nextBlock()
    {
        // arvo uusi palikka
        curBlock = (int) (Math.random() * (double) numPalikat);

        int q;

        // kopsaa palikka
        for (q = 0; q < 9; q++)
        {
            block[q] = palikat[(curBlock * 9) + q] * ((int) (Math.random() * numImg) + 1);
        }
    }

    /**
     piirtää ruudulle jääneet palikat

     @param g2d
     */
    void drawArea(Graphics2D g2d)
    {
        int q;
        int w;

        for (w = 0; w < (kor - 1); w++)
        {
            for (q = 1; q < (lev - 1); q++)
            {
                int i = alue[w][q];

                if (i >= 1)
                {
                    g2d.drawImage(palImg[i - 1].getImage(), (q * 20), w * 20, null);
                }
            }
        }
    }

    /**
     piirtää tippuvan palikan

     @param g2d
     */
    void drawBlock(Graphics2D g2d)
    {
        int q;
        int w;

        for (q = 0; q < 3; q++)
        {
            for (w = 0; w < 3; w++)
            {
                int i = block[(q * 3) + w];

                if (i >= 1)
                {
                    g2d.drawImage(palImg[i - 1].getImage(), 20 + ((x + w) * 20), (y + q) * 20, null);
                }
            }
        }
    }

    /**
     tarkistaa voiko palikan pistää xy kohtaan

     @param x x kohta alue-taulukossa
     @param y y kohta alue-taulukossa
     @param ch palikka taulukko (block tai tmparray)
     @return true jos voi laittaa xy kohtaan, muuten false
     */
    boolean checkArea(int x, int y, int[] ch)
    {
        int q;
        int w;

        for (q = 0; q < 3; q++)
        {
            for (w = 0; w < 3; w++)
            {
                if ((1 + (x + w)) < 0)
                {
                    continue;
                }

                if ((alue[y + q][1 + (x + w)] >= 1) && (ch[(q * 3) + w] >= 1))
                {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     pyöritä palikkaa

     @param t +1 pyörittää myötäpäivään, -1 vastapäivään
     */
    void rotateBlock(int t)
    {
        int q;
        int w;

        for (q = 0; q < 9; q++)
        {
            tmparray[q] = 0;
        }

        // painettu x, pyöritä myötäpäivään
        if (t == 1)
        {
            for (q = 0; q < 3; q++)
            {
                for (w = 0; w < 3; w++)
                {
                    tmparray[(w * 3) + (2 - q)] = block[(q * 3) + w];
                }
            }
        } else
        {
            for (q = 0; q < 3; q++)
            {
                for (w = 0; w < 3; w++)
                {
                    tmparray[((2 - w) * 3) + q] = block[(q * 3) + w];
                }
            }
        }

        // tarkista että palikka mahtuu uudella asennolla paikalleen
        if (checkArea(x, y, tmparray) == true)
        {
            // kopsataan talteen
            for (q = 0; q < 9; q++)
            {
                block[q] = tmparray[q];
            }
        }
    }

    /**
     jos nappia painetaan

     @param e
     */
    public void keyPressed(KeyEvent e)
    {
        String jono = e.getKeyText(e.getKeyCode());

        if ((gameOver == false) && (firstTime == false))
        {
            if (jono.equals("Right"))
            {
                if (checkArea(x + 1, y, block) == true)
                {
                    x++;
                }
            }

            if (jono.equals("Left"))
            {
                if (checkArea(x - 1, y, block) == true)
                {
                    x--;
                }
            }

            if (jono.equals("Z")) // käännä palikkaa vastapäivään
            {
                rotateBlock(-1);
            }

            if (jono.equals("X")) // käännä palikkaa myötäpäivään
            {
                rotateBlock(1);
            }
        }

        if (jono.equals("Escape")) // lopeta peli
        {
            System.exit(0);
        }

        if (jono.equals("Space") || jono.equals("Down")) // tiputa palikka vauhdilla alas
        {
            wait = 10;
        }

        if (jono.equals("R")) // kun tulee gameover, R = restart
        {
            Raxtrix.gameOver = false;
        }

        if (jono.equals("S")) // käynnistää pelin ekalla kerralla
        {
            Raxtrix.firstTime = false;
        }

        repaint();
    }

    /**
     ei käytössä
     */
    public void keyTyped(KeyEvent e)
    {
    }

    /**
     ei käytössä
     */
    public void keyReleased(KeyEvent e)
    {
    }
}

/**
 kuvien lataaja
 */
class Object2D
{
    /**
     kuva
     */
    protected BufferedImage image = null;

    /**
     lataa kuvan

     @param file tiedostonimi
     @throws java.io.IOException jos kuvan lataaminen epäonnistui, tulee poikkeus
     */
    Object2D(String file) throws IOException
    {
        loadImage(file);
    }

    /**
     palauttaa kuvan

     @return kuva
     */
    BufferedImage getImage()
    {
        return image;
    }

    /**
     palauttaa leveyden

     @return leveys
     */
    int getWidth()
    {
        return image.getWidth();
    }

    /**
     palauttaa korkeuden

     @return korkeus
     */
    int getHeight()
    {
        return image.getHeight();
    }

    /**
     lataa kuva

     @param file tiedostonimi
     @throws java.io.IOException jos kuvan lataaminen epäonnistui, tulee poikkeus
     */
    void loadImage(String file) throws IOException
    {
        URL url = Thread.currentThread().getContextClassLoader().getResource(file);

        //URL url = this.getClass().getClassLoader().getResource(file);
        //URL url = this.getClass().getResource(file);
        if (url == null)
        {
            throw new IOException("Can't find file: " + file);
        }

        // bufimageen kuva
        BufferedImage bufimage = ImageIO.read(url); //new File(file));

        // luo kuva
        image = new BufferedImage(bufimage.getWidth(), bufimage.getHeight(), BufferedImage.TYPE_INT_RGB);

        // piirrä sinne bufimage..
        Graphics g = image.createGraphics();
        g.drawImage(bufimage, 0, 0, null);
    }
}
