/*
 * Matopeli
 * @author mjt, 2006
 * mixut@hotmail.com
 *
 * @created 11.11.2006
 * 
 * vaatii midp2 koska k�ytt�� sin/cos funkkareita ja floatteja.
 */

import java.util.Random;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.game.GameCanvas;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.io.IOException;

class Point
{
	Point()
	{
		x = y = -1;
	}
	public int x, y;
}

public class Game extends GameCanvas implements Runnable, CommandListener
{
	final int LEN = 30, MAXLEN = 1000;
	final float TURN=0.1f;

	boolean gameover = false;
	private Image head; // kuvat
	int score = 0; // pisteet
	float x, y; // madon p��n paikka

	/**
	 * n�ist� osista mato rakennetaan. ps[pos] on madon p��, ps[pos-wormLen] sen
	 * per�.
	 */
	Point[] ps = new Point[MAXLEN];

	int newlen=LEN; // jos >0, mato kasvaa sen verran
	
	int wormLen = 1; // madon pituus
	float angle = 0; // suunta johon liikutaan
	int pos = wormLen - 1;
	int foodx, foody; // safkan paikka
	boolean food=false;
	
	Graphics graph;
	
	private Command cmExit;
	Wormi worm;

	public Game(Wormi worm)
	{
		super(true);

		this.worm = worm;

		cmExit = new Command("Exit", Command.EXIT, 1);
		addCommand(cmExit);
		setCommandListener(this);

		// luo mato, pituus LEN
		int a;

		for (a = 0; a < MAXLEN; a++)
			ps[a] = new Point(); // varaa muistia madolle

		for (a = 0; a < LEN; a++)
		{
			ps[a].x = getWidth() / 2 - 5 + a;
			ps[a].y = getHeight() / 2;
		}
		x = (float) ps[a - 1].x;
		y = (float) ps[a - 1].y;

	}
	public void commandAction(Command c, Displayable d)
	{
		if (c == cmExit)
		{
			worm.exitMIDlet();
		}
	}

	public void start()
	{

		try
		{
			// lataa kuvat
			head = Image.createImage("/head.PNG");

		} catch (IOException ioex)
		{
			System.err.println(ioex);
			return;
		}

		Thread thr = new Thread(this);
		thr.start();

	}

	void checkWorm()
	{
		// laske madon p��n uusi paikka
		x += (float) Math.cos((float) angle);
		y += (float) Math.sin((float) angle);

		pos++;
		pos %= MAXLEN;
		ps[pos].x = (int) x;
		ps[pos].y = (int) y;

		// tarkista osuuko reunaan tai itseens�
		if(x<0 || x>getWidth() || y<0 || y>getHeight()) gameover=true;
		if(wormLen>20)
		for(int q=20; q<wormLen; q++)
		{
			int p = pos - q;
			if(p<0) p=MAXLEN+p;
			if((int)x==ps[p].x && (int)y==ps[p].y) 
			{
				gameover=true;
				break;
			}

		}
		
		
		
		// mato kasvaa
		if(newlen>0)
		{
			if(wormLen>=MAXLEN)
			{
				newlen=0;
			}
			else
			{
				newlen--;
				wormLen++;
			}
		}
	
		// jos p�� sy�d��n
		if(ps[pos].x > foodx && ps[pos].y > foody &&
				ps[pos].x<foodx+head.getWidth() && ps[pos].y<foody+head.getHeight())
		{
			newlen=40; // lis�� pituutta
			score+=5;
			food=false;
			
			// p�ivit� koko ruutu, eli tyhjenn� se ja piirr� mato uusiksi
			clear();
			for (int q = 0; q < wormLen; q++)
			{
				int p = pos - q;
				if(p<0) p=MAXLEN+p;
				drawCross(ps[p].x, ps[p].y, false);
			}
			
		}
		
	}

	void putFood()
	{
		if(food==false)
		{
			// satunnainen paikka safkalle
			Random random = new Random( );
			foodx = Math.abs( random.nextInt() % (getWidth()-head.getWidth()) );
			foody = Math.abs( random.nextInt() % (getHeight()-head.getHeight()) );
			food=true;
		}
	}
	public void run()
	{
		// ota Graphics olio
		graph = getGraphics();

		while (true)
		{
			checkKeys(); // tarkista n�pp�imet
			putFood(); // ruokaa
			checkWorm(); // tsekkaa sy�k� mato

			draw(); // piirr� kaikki ruudulle

			// pieni viive
			try
			{
				Thread.currentThread().sleep(10);
			} catch (Exception e)
			{
			}

		}

	}

	void checkKeys()
	{
		// ota n�pp�inten tilat
		int keys = getKeyStates();

		if ((keys & LEFT_PRESSED) != 0)
			angle -= TURN;

		if ((keys & RIGHT_PRESSED) != 0)
			angle += TURN;

	}

	private void draw()
	{
		if (gameover == true)
		{
			graph.setColor(0x991111);
			graph.fillRect(0, 0, getWidth(), getHeight());
			graph.setColor(255, 255, 255);
			graph.drawString("Game over!", getWidth() / 2, getHeight() / 2, Graphics.TOP | Graphics.HCENTER);
			graph.drawString("Your score: "+score, getWidth() / 2, getHeight() / 2+20, Graphics.TOP | Graphics.HCENTER);
			flushGraphics();
			return;
		}

		if(food==true)
		{
			graph.drawImage(head, foodx, foody, 0);
		}
		
		graph.setColor(0, 0, 0);
		String txt = "Wormi by mjt Score:" + score;
		graph.drawString(txt, 0, 0, Graphics.TOP | Graphics.LEFT);


		// piirr� uusi p��
		int p = pos;
		if(p<0) p=MAXLEN+p;
		drawCross(ps[p].x, ps[p].y, false);
		
		// poista per�
		p=pos-wormLen;
		if(p<0) p=MAXLEN+p;
		drawCross(ps[p].x, ps[p].y, true);
		
		
		// grafiikat ruutuun
		flushGraphics();
	}

	void clear()
	{
		// tyhjenn� ruutu
		graph.setColor(0xffffff);
		graph.fillRect(0, 0, getWidth(), getHeight());
	}
	
	void drawCross(int x, int y, boolean clear)
	{
		if(clear==false)
		{
			int rc = (x%10) & 0xFF;
			int gc = 20;
			int bc = 150;
			graph.setColor(rc, gc, bc);
		}
		else graph.setColor(255, 255, 255);
		
		graph.drawLine(x - 1, y, x + 1, y);
		graph.drawLine(x, y - 1, x, y + 1);
	}

}
