/*
 * Hy�kk�ys
 * @author mjt, 2006
 * mixut@hotmail.com
 * 
 * toka j2me pelini.
 *
 * 12.8.2006 aloitus
 * 11.11.06 tehty valmiiksi tauon j�lkeen (huom t�m� on valmis vaikkei silt� n�ytt�isi ;)
 */

import java.util.Random;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.game.GameCanvas;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.io.IOException;

public class Game extends GameCanvas implements Runnable, CommandListener
{
	final int XSTEP = 10, PICWIDTH = 30;
	boolean gameover = false;

	private Image alus, alien, bum; // kuvat
	int x = getWidth() / 2; // ohjattavan aluksen x
	int score = 0; // pisteet

	boolean fire = false; // true jos ammutaan

	int bx = -1, by = -1; // pommin koordinaatit
	int ax = 0, ay = 0; // alien ryhm�n koordinaatit
	int axs = 5; // alieneiden suunta

	boolean[][] aliens = new boolean[5][3];

	private Command cmExit;
	Hyokkays hyokkays;
	
	public Game(Hyokkays hyok)
	{
		super(true);

		hyokkays=hyok;
		
		cmExit = new Command("Exit", Command.EXIT, 1);
		addCommand(cmExit);
		setCommandListener(this);

		setAliens();

	}
	public void commandAction(Command c, Displayable d)
	{
		if (c == cmExit)
		{
			hyokkays.exitMIDlet();
		}
	}

	void setAliens()
	{
		int a, b;
		for (a = 0; a < 5; a++)
			for (b = 0; b < 3; b++)
				aliens[a][b] = true;
	}

	public void start()
	{

		try
		{
			// lataa kuvat
			alus = Image.createImage("/alus.PNG");
			alien = Image.createImage("/alien.PNG");
			bum = Image.createImage("/bum.PNG");

		} catch (IOException ioex)
		{
			System.err.println(ioex);
			return;
		}

		Thread thr = new Thread(this);
		thr.start();

	}

	public void run()
	{
		// ota Graphics olio
		Graphics g = getGraphics();

		while (true)
		{
			updateAliens(); // liikuta alien ryhm��
			checkKeys(); // tarkista n�pp�imet
			updateFire(); // jos ammutaan
			draw(g); // piirr� kaikki ruudulle

			// pieni viive
			try
			{
				Thread.currentThread().sleep(50);
			} catch (Exception e)
			{
			}

		}

	}
	void updateFire()
	{
		if (fire == true)
		{
			if (bx == -1)
			{
				bx = x;
				by = getHeight() - 24;
			} else
			{
				by -= 5;
				if (by < -5) // jos poistuu ruudulta
				{
					bx = -1;
					fire = false;
				}

				int a, b;
				// k�y alienit l�pi ja tsekkaa osuuko ammus johonkin
				for (a = 0; a < 5; a++)
				{
					for (b = 0; b < 3; b++)
					{
						if (aliens[a][b] == true)
						{
							// koords: ax + a * 30, ay + b * 24
							if (by < ay + b * 24 && by > ay + b * 24-24)
								if (bx > ax + a * 30 && bx < ax + a * 30 + 30)
								{
									bx = -1;
									aliens[a][b] = false; // osuma
									fire = false;
									score += 15;
									return; // pois t��lt�
								}
						}
					}
				}

			}

		}
	}

	void updateAliens()
	{
		ax += axs;
		if (ax < 0)
		{
			ax = 0;
			axs = -axs;

			ay += 20;
		}

		if (ax > getWidth() - (5 * PICWIDTH))
		{
			axs = -axs;
			ay += 20;
		}

	}

	void checkKeys()
	{
		// ota n�pp�inten tilat
		int keys = getKeyStates();

		if ((keys & LEFT_PRESSED) != 0 && x > PICWIDTH / 2)
		{
			x -= XSTEP;
		}

		if ((keys & RIGHT_PRESSED) != 0 && x < getWidth() - PICWIDTH / 2)
		{
			x += XSTEP;
		}

		if ((keys & UP_PRESSED) != 0 && x < getWidth() - PICWIDTH / 2)
		{
			fire = true;
		}

	}

	private void draw(Graphics g)
	{

		// tyhjenn� ruutu
		g.setColor(0xffffff);
		g.fillRect(0, 0, getWidth(), getHeight());

		// piirr� alienit
		int a, b;
		for (a = 0; a < 5; a++)
		{
			for (b = 0; b < 3; b++)
			{
				// jos alien on elossa
				if (aliens[a][b] == true)
				{
					g.drawImage(alien, ax + a * 30, ay + b * 24, 0);

					if (ay + b * 24 > getHeight() - 24)
						gameover = true;
				}

			}
		}

		if (gameover == true)
		{
			g.setColor(0x990000);
			g.fillRect(0, 0, getWidth(), getHeight());
			g.setColor(255, 255, 255);
			g.drawString("Game over!", getWidth()/2, getHeight()/2, Graphics.TOP | Graphics.HCENTER);
			flushGraphics();
			return;
		}

		// tulta!
		if (fire == true)
			g.drawImage(bum, bx, by, 0);

		// piirr� oma alus
		g.drawImage(alus, x - PICWIDTH / 2, getHeight() - 24, 0);

		g.setColor(0, 0, 0);
		String txt = "Hy�kk�ys by mjt Score:" + score;
		g.drawString(txt, 0, 0, Graphics.TOP | Graphics.LEFT);

		// grafiikat ruutuun
		flushGraphics();

	}

}
