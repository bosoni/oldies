/* Hy�kk�ys 
 *
 * by mjt 2006
 *
 *
 *
 */

import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Display;

public class Hyokkays extends MIDlet
{

	Game game;

	public Hyokkays()
	{
		game = new Game(this);
	}

	/**
	 * k�ynnist� peli
	 */
	public void startApp()
	{

		Display display = Display.getDisplay(this);
		game.start();
		display.setCurrent(game);
	}

	public void pauseApp()
	{
	}

	public void destroyApp(boolean unconditional)
	{
	}
	public void exitMIDlet()
  	{
    		destroyApp(true);
		notifyDestroyed();
  	}
}
