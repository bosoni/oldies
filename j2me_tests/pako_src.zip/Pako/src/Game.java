/*
 * Pako peli
 * @author mjt, 2006-2007
 * mixut@hotmail.com
 *
 * @created 12.11.2006
 * @edited 11.1.2007
 *
 * ohjaat ukkoa linnassa aarteita etsien ja vartijoita v�ltt�en.
 * tarkoitus l�yt�� linnasta ulos lukittujen ovien kautta.
 */
 
import java.util.Random;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.game.GameCanvas;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.io.IOException;

class Objects
{
	// 1=guard, >10=pussi, id-10=pussin sis�lt�
	// jolloin 0=tyhj�, 1=aarre, 2=avain
	public int id;
	public int x, y;

	Objects()
	{
		id = 0;
		x = y = -1;
	}
}

public class Game extends GameCanvas implements Runnable, CommandListener
{
	Random random = new Random();
	
	boolean gameover = false;
	private Image[] pics = new Image[10]; // kuvat
	private Image hero, guard;

	boolean key=false; // onko avain ker�tty jo
	
	int score = 0; // pisteet
	int x = -1, y = -1; // paikka

	final int OBJECTS = 20;
	Objects objs[] = new Objects[OBJECTS];

	Graphics graph;

	private Command cmExit;
	Pako pako;

	public Game(Pako pako)
	{
		super(true);

		this.pako = pako;

		cmExit = new Command("Exit", Command.EXIT, 1);
		addCommand(cmExit);
		setCommandListener(this);

	}
	public void commandAction(Command c, Displayable d)
	{
		if (c == cmExit)
		{
			pako.exitMIDlet();
		}
	}

	final String[] map = {// 
	"3222222222222222222222222223", //
			"3000026000000000000000000663", //
			"3600020000000000000002000003", //
			"3000020000020000000002220223", //
			"3000020000620000000002000003", //
			"3220022222200000002222000003", //
			"3000000002600000006620000003", //
			"3000200002000000000020000063", //
			"3002222000000000000020000063", //
			"3002000062000000000020000063", //
			"3002000002000000000020000003", //
			"3112000002000002222220000003", //
			"3122002222222222000000002204", //
			"3120000000000000000000002003", //
			"3120000000000002000002002013", //
			"3222022200222222011222222113", //
			"3000000000211111111111001163", //
			"2222222222222222222222222222" //

	};

	public void start()
	{

		try
		{
			// lataa kuvat
			hero = Image.createImage("/ukko.PNG");
			guard = Image.createImage("/guard.PNG");
			pics[0] = Image.createImage("/lattia.PNG");
			pics[1] = Image.createImage("/hiekka.PNG");
			pics[2] = Image.createImage("/seina.PNG");
			pics[3] = Image.createImage("/seina2.PNG");
			pics[4] = Image.createImage("/ovi.PNG");
			pics[5] = Image.createImage("/pussi.PNG");
			pics[6] = Image.createImage("/ruukku.PNG");
			pics[7] = Image.createImage("/avain.PNG");
			pics[8] = Image.createImage("/aarre.PNG");

		} catch (IOException ioex)
		{
			System.err.println(ioex);
			return;
		}

		Thread thr = new Thread(this);
		thr.start();

	}

	/**
	 * aseta kartalle oma ukko, vartijat ja tavarat
	 */
	void setObjs()
	{
		int curobj = 0;
		
		while (true)
		{
			// arvo luvut
			int vx = Math.abs(random.nextInt() % map[0].length());
			int vy = Math.abs(random.nextInt() % map.length);

			if (map[vy].charAt(vx) == '0' || map[vy].charAt(vx) == '1') // tyhj� paikka (hiekka tai laatta)
			{
				// jos ohjattavalla ukolla ei viel� paikkaa kartalla
				if (x == -1) 
				{
					x = vx; // aseta sankarille paikka
					y = vy;
					continue;
				}

				if(Math.abs(vx-x)<2 && Math.abs(vy-y)<2) continue; // jos liian l�hell� sankaria, uusi yritys
				
				objs[curobj] = new Objects();
				objs[curobj].x = vx;
				objs[curobj].y = vy;
				byte[] str = map[vy].getBytes();

				if (curobj < OBJECTS / 2) // aseta vartijat
				{
					objs[curobj].id = 1;
					str[vx] += 'A'; // merkkaa paikka varatuksi ettei siihen tule muita objekteja
				} else if (curobj == OBJECTS / 2)// aseta avain
				{
					objs[curobj].id = 12;
					str[vx] += 'A'; // merkkaa paikka varatuksi ettei siihen tule muita objekteja
					
				} else
				// aarteet ja tyhj�t kassit
				{
					int rand = 10 + Math.abs(random.nextInt() % 2);
					objs[curobj].id = rand;
					str[vx] += 'A'; // merkkaa paikka varatuksi ettei siihen tule muita objekteja
				}

				
				map[vy] = "";
				for (int q = 0; q < str.length; q++)
					map[vy] += (char) str[q];
				
				curobj++;
				if (curobj == OBJECTS)
					break;
				continue;

			}

		}

		// seuraavaksi korjaa kartta
		for (int vx = 0; vx < map[0].length(); vx++)
		{
			for (int vy = 0; vy < map.length - 1; vy++)
			{
				byte[] str = map[vy].getBytes();
				char ob = map[vy].charAt(vx);

				// tarkista sein�t
				if (ob == '2')
				{
					if (map[vy + 1].charAt(vx) == '2')
					{
						str[vx] = '3';
					}
				}

				map[vy] = "";
				for (int q = 0; q < str.length; q++)
					map[vy] += (char) str[q];

			}
		}

	}

	/**
	 * liikuta vartija uuteen paikkaan ja p�ivit� kartta
	 */
	void moveGuard(int x, int y, int newx, int newy)
	{
		byte[] str = map[y].getBytes();
		str[x]-='A';

		// p�ivit� kartta
		map[y] = "";
		for (int q = 0; q < str.length; q++)
			map[y] += (char) str[q];
		
		str = map[newy].getBytes();
		str[newx]+='A';
		
		// p�ivit� kartta
		map[newy] = "";
		for (int q = 0; q < str.length; q++)
			map[newy] += (char) str[q];
	}
	
	/**
	 * liikuta vartijoita, tarkista my�s saako ne sankarin kiinni (jos samassa ruudussa)
	 */
	void updateGuards()
	{
		for(int q=0; q<OBJECTS/2; q++)
		{
			int x=objs[q].x;
			int y=objs[q].y;
			int w = Math.abs(random.nextInt() % 6);
			
			// liikuta vartijaa satunnaiseen suuntaan jos pystyy
			switch(w)
			{
				case 0:
					if(canMove(x-1, y)) 
					{
						moveGuard(x, y, x-1, y);
						objs[q].x--;
					}
					break;
				
				case 1:
					if(canMove(x+1, y)) 
					{
						moveGuard(x, y, x+1, y);
						objs[q].x++;
					}
					break;

				case 2:
					if(canMove(x, y-1)) 
					{
						moveGuard(x, y, x, y-1);
						objs[q].y--;
					}
					break;
					
				case 3:
					if(canMove(x, y+1)) 
					{
						moveGuard(x, y, x, y+1);
						objs[q].y++;
					}
					break;
			}
	
			x=objs[q].x;
			y=objs[q].y;
			
			// jos tuli samaan ruutuun sankarin kanssa, peli ohi
			if(this.x==x && this.y==y)
			{
				try
				{
					Thread.currentThread().sleep(200);
				} catch (Exception e)
				{
				}
				gameover=true;
			}
	
	
		}
	}
	
	public void run()
	{
		// ota Graphics olio
		graph = getGraphics();

		
		// n�yt� alkuvalikko
		while(true)
		{
			clear();
			
			graph.setColor(0, 0, 0);
			graph.drawString("PAKO by mjt", getWidth() / 2, 0, Graphics.TOP | Graphics.HCENTER);
			graph.drawString("Yrit� selvit� sokkeloista", getWidth() / 2, 25, Graphics.TOP | Graphics.HCENTER);			
			graph.drawString("ja samalla ker�� aarteita.", getWidth() / 2, 50, Graphics.TOP | Graphics.HCENTER);			
			graph.drawString("Tarvitset avaimen", getWidth() / 2, 75, Graphics.TOP | Graphics.HCENTER);			
			graph.drawString("p��st�ksesi pakoon!", getWidth() / 2, 100, Graphics.TOP | Graphics.HCENTER);			
			graph.drawString("Varo vartijoita!", getWidth() / 2, 125, Graphics.TOP | Graphics.HCENTER);
			
			graph.drawString("2,4,6,8 ohjaa sankaria", getWidth() / 2, 150, Graphics.TOP | Graphics.HCENTER);			
			graph.drawString("5 + suunta", getWidth() / 2, 175, Graphics.TOP | Graphics.HCENTER);			
			graph.drawString("tutkii pussin.", getWidth() / 2, 200, Graphics.TOP | Graphics.HCENTER);			

			// grafiikat ruutuun
			flushGraphics();

			
			// ota n�pp�inten tilat
			int keys = getKeyStates();
			if ((keys & FIRE_PRESSED) != 0) // action
			{
				break;
			}

			// pieni viive
			try
			{
				Thread.currentThread().sleep(100);
			} catch (Exception e)
			{
			}
		}
		
		clear();
		graph.setColor(0, 0, 0);
		graph.drawString("..pakoon!!", getWidth() / 2, getHeight()/2, Graphics.TOP | Graphics.HCENTER);
		flushGraphics();
		
		
		// aseta kassit, vartijat ja sankari kartalle randomilla
		setObjs();

		while (true)
		{
			checkKeys(); // tarkista n�pp�imet
			updateGuards(); // liikuta vartijoita
		
			draw(); // piirr� kaikki ruudulle

			// pieni viive
			try
			{
				Thread.currentThread().sleep(100);
			} catch (Exception e)
			{
			}

		}

	}

	boolean canMove(int x, int y)
	{
		char ob = map[y].charAt(x);
		
		if(ob>='A') // paikassa on joku tavara (tai vartija) jonka l�pi ei voi kulkea
			return false;
			
		if (ob == '0' || ob=='1') // jos hiekka tai laatta
			return true;

		// este joten ei voida liikuttaa xy kohtaan
		return false;
	}

	/**
	 * kun k�ytet��n ACTION nappia ja suuntaa, tarkista onko suunnassa
	 * mit��n mille pit�isi tehd� jotain (esim oven avaus, pussin tutkiminen, tavaran ottaminen)
	 */
	void checkPos(int x, int y)
	{
		char ob = map[y].charAt(x);
		byte[] str = map[y].getBytes();
		if (ob >= 'A') // paikassa on jotain
		{
			for(int q=0; q<OBJECTS; q++)
			{
				if(objs[q].id!=0)
				{
					if(x==objs[q].x && y==objs[q].y)
					{
						// jos siin� on pussi, n�yt� pussin sis�lt�
						if(objs[q].id >= 10)
						{		
							objs[q].id-=10;
							if(objs[q].id==0)
							{
								str[x]-='A'; // tyhj� pussi joten poista se kartalta
							}
							else
							{
								// aseta kartalle oikea pussin sis�lt�
								if(objs[q].id==1) 
									objs[q].id=8; // aarre
								
								if(objs[q].id==2) 
									objs[q].id=7; // avain
								return;
							}
						}
						else
						{
							// ota tavara
							if(objs[q].id==8) // aarre
								score+=10;
							if(objs[q].id==7) // avain
								key=true;
							
							str[x]-='A';
							objs[q].id=0;
						}
						
					}
				}
			}
			
		}
		if(ob=='4' && key==true) // jos ovi ja avain on otettu, avaa ovi
		{
			str[x]='0';
		}

		// p�ivit� kartta
		map[y] = "";
		for (int q = 0; q < str.length; q++)
			map[y] += (char) str[q];
	}
	
	void checkKeys()
	{
		// ota n�pp�inten tilat
		int keys = getKeyStates();

		if ((keys & FIRE_PRESSED) != 0) // action
		{
			if ((keys & LEFT_PRESSED) != 0)
				checkPos(x-1, y);
			
			if ((keys & RIGHT_PRESSED) != 0)
				checkPos(x+1, y);

			if ((keys & UP_PRESSED) != 0)
				checkPos(x, y-1);
			
			if ((keys & DOWN_PRESSED) != 0)
				checkPos(x, y+1);
			return;
		}
			
		if ((keys & LEFT_PRESSED) != 0)
			if (canMove(x - 1, y))
				x--;

		if ((keys & RIGHT_PRESSED) != 0)
			if (canMove(x + 1, y))
				x++;

		if ((keys & UP_PRESSED) != 0)
			if (canMove(x, y - 1))
				y--;

		if ((keys & DOWN_PRESSED) != 0)
			if (canMove(x, y + 1))
				y++;

		if(x==0 || x==map[0].length()-1 ||
				y==0 || y==map.length-1)
			nextLevel();

	}
	
	boolean finished=false;
	void nextLevel()
	{
		score+=100;
		finished=true;
		x=y=1;
		// TODO latais vaik toisen kartan
	}

	private void draw()
	{
		clear();
		int qx = getWidth() / 30 / 2;
		int qy = getHeight() / 30 / 2;

		if(finished==true)
		{
			graph.setColor(0x119911);
			graph.fillRect(0, 0, getWidth(), getHeight());
			graph.setColor(255, 255, 255);
			graph.drawString("Selvisit!", getWidth() / 2, getHeight() / 2-20, Graphics.TOP | Graphics.HCENTER);
			graph.drawString("Pisteet: " + score, getWidth() / 2, getHeight() / 2 + 20, Graphics.TOP
					| Graphics.HCENTER);
			flushGraphics();
			return;
		}
		if (gameover == true)
		{
			graph.setColor(0x991111);
			graph.fillRect(0, 0, getWidth(), getHeight());
			graph.setColor(255, 255, 255);
			graph.drawString("Peli loppu!", getWidth() / 2, getHeight() / 2-20, Graphics.TOP | Graphics.HCENTER);
			graph.drawString("Vartija sai kiinni!", getWidth() / 2, getHeight() / 2, Graphics.TOP | Graphics.HCENTER);
			graph.drawString("Pisteet: " + score, getWidth() / 2, getHeight() / 2 + 20, Graphics.TOP
					| Graphics.HCENTER);
			flushGraphics();
			return;
		}

		// piirr� kartta
		for (int vx = 0; vx < map[0].length(); vx++)
			for (int vy = 0; vy < map.length; vy++)
			{
				char ob = map[vy].charAt(vx);
				if (ob >= 'A') ob-='A';

				int objnu = (int) ob - '0';
				
				if(objnu==6) // ruukku
				{
					// jos ymp�rill� laattaa, pist� ruukun alle laatta. muuten hiekka
					if(map[vy].charAt(vx-1)=='0' || map[vy-1].charAt(vx)=='0' ||
						map[vy].charAt(vx+1)=='0' || map[vy+1].charAt(vx)=='0')
						graph.drawImage(pics[0], (vx - x + qx) * 30, (vy - y + qy) * 30, 0);
					else graph.drawImage(pics[1], (vx - x + qx) * 30, (vy - y + qy) * 30, 0);
				}
				
				graph.drawImage(pics[objnu], (vx - x + qx) * 30, (vy - y + qy) * 30, 0);
			}

		// piirr� roinat
		for (int q = 0; q < OBJECTS; q++)
		{
			int ob = objs[q].id;
			if (ob >= 10)
				ob = 5; // pussi
				
			if(ob==1) // vartija
				graph.drawImage(guard, (-x+qx+objs[q].x) * 30, (-y+qy+objs[q].y) * 30, 0);
			else
				if(ob>1)
					graph.drawImage(pics[ob], (-x+qx+objs[q].x) * 30, (-y+qy+objs[q].y) * 30, 0);
		}

		graph.drawImage(hero, qx * 30, qy * 30, 0);

		String txt = "Pako by mjt Score:" + score;
		graph.setColor(40, 100, 200);
		graph.drawString(txt, 0, 0, Graphics.TOP | Graphics.LEFT);
		graph.setColor(255, 0, 100);
		graph.drawString(txt, 2, 0, Graphics.TOP | Graphics.LEFT);
		graph.setColor(0, 0, 0);
		graph.drawString(txt, 1, 0, Graphics.TOP | Graphics.LEFT);

		// grafiikat ruutuun
		flushGraphics();
	}

	void clear()
	{
		// tyhjenn� ruutu
		graph.setColor(0xffffff);
		graph.fillRect(0, 0, getWidth(), getHeight());
	}

}
