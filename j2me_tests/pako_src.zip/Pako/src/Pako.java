import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Display;

public class Pako extends MIDlet
{

	Game game;

	public Pako()
	{
		game = new Game(this);
	}

	/**
	 * k�ynnist� peli
	 */
	public void startApp()
	{

		Display display = Display.getDisplay(this);
		game.start();
		display.setCurrent(game);
	}

	public void pauseApp()
	{
	}

	public void destroyApp(boolean unconditional)
	{
	}
	public void exitMIDlet()
  	{
    		destroyApp(true);
		notifyDestroyed();
  	}
}
