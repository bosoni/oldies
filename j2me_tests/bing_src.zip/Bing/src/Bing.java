/* Bing Bong 
 *
 * by mjt 2006
 *
 *
 *
 */
 
import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Display;

public class Bing extends MIDlet {

	Game game;

	public Bing() {
		game = new Game();
	}

	/**
	 * k�ynnist� peli
	 */
	public void startApp() {
		
		Display display = Display.getDisplay(this);
		game.start();
		display.setCurrent(game);
	}

	public void pauseApp() {
	}

	public void destroyApp(boolean unconditional) {
	}
}
