/*
 * Bing Bong
 * @author mjt
 * mixut@hotmail.com
 * 
 * @created 12.8.2006
 * @edited 11.11.2006
 * 
 * ensinm�inen j2me pelini.
 *
 *
 */

import java.util.Random; 
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.game.GameCanvas;

import java.io.IOException;

public class Game extends GameCanvas implements Runnable 
{
	final int YSTEP=10, PICWIDTH=12, PICHEIGHT=74;
	
	private Image[] maila=new Image [2]; // mailojen kuvat
	private Image ball;

	int[] ys=new int [2]; // mailojen y

	int bx, by;// pallon koordinaatit
	int bxs=5, bys=5; // x ja y suunta
	

	int[] scores=new int [2]; // mailojen pisteet


	public Game() 
	{
		super(true);

		ys[0]=getHeight()/2- (PICHEIGHT/2);
		ys[1]=getHeight()/2- (PICHEIGHT/2);
		
		bx=getWidth()/2;// pallon koordinaatit
		by=getHeight()/2; 

		scores[0]=scores[1]=0;

	}

	public void start() {
	
		try {
	
			// lataa kuvat
			maila[0]=Image.createImage("/blue.PNG");
			maila[1]=Image.createImage("/red.PNG");
			ball=Image.createImage("/ball.PNG");

		} catch(IOException ioex) 
		{ 
			System.err.println(ioex); 
			return;
		}
	
		Thread thr = new Thread(this);
		thr.start();

	}

	public void run() {

		// ota Graphics olio
		Graphics g = getGraphics();
		
		while(true)
		{
			updateRed(); // p�ivit� punaisen mailan paikka (AI)
			
			checkKeys(); // tarkista n�pp�imet
			updateBall(); // muuta pallon koordinaatteja ja tarkista t�rm�ykset
			draw(g); // piirr� kaikki ruudulle
	  
	  		// pieni viive
			try {
				Thread.currentThread().sleep(50);
			} catch(Exception e) {}
			

		}

	}
	
	void updateRed()
	{
		if(ys[1]>by) ys[1]-=YSTEP;
		if(ys[1]+PICHEIGHT<by) ys[1]+=YSTEP;
	}
	
	void checkKeys()
	{
			// ota n�pp�inten tilat
			int keys=getKeyStates();
		
			if((keys & UP_PRESSED)!=0 && ys[0]>0)
			{
				ys[0]-=YSTEP;
			}

			if((keys & DOWN_PRESSED)!=0 && ys[0]<getHeight()-PICHEIGHT)
			{
				ys[0]+=YSTEP;
			}
	}


	private void draw(Graphics g) 
	{

		// tyhjenn� ruutu
		g.setColor(0xffffff);
		g.fillRect(0, 0, getWidth(), getHeight());
		
		
		g.drawImage(maila[0], 5, ys[0], 0);
		g.drawImage(maila[1], getWidth()-PICWIDTH-5, ys[1], 0);
		
		
		g.drawImage(ball, bx, by, Graphics.HCENTER | Graphics.VCENTER);
		
		g.setColor(0, 0, 0);
		g.drawString(""+scores[0], 0, 0, Graphics.TOP | Graphics.LEFT);
		g.drawString(""+scores[1], getWidth(), 0, Graphics.TOP | Graphics.RIGHT);
		
		// grafiikat ruutuun
		flushGraphics();

	}
	
	void updateBall()
	{
		// muuta koordinaatit
		bx+=bxs;
		by+=bys;
		
		
		if(bx<5+PICWIDTH + 13)
		{
			// testaa osuuko mailaan
			if(ys[0]<by && ys[0]+PICHEIGHT>by) bxs=-bxs;
			else
			{
				bx=getWidth()/2;
				by=getHeight()/2; // pallon koordinaatit
				
				bxs=-(getRandomInt()%5 + 5);
				bys=getRandomInt()%20 - 5;
							
				scores[1]++;
			}
			
		}
		
		if(bx>getWidth()-5-PICWIDTH - 13)
		{
			// testaa osuuko mailaan
			if(ys[1]<by && ys[1]+PICHEIGHT>by) bxs=-bxs;
			else
			{
				bx=getWidth()/2;
				by=getHeight()/2; // pallon koordinaatit
				
				bxs=getRandomInt()%5 + 5;
				bys=getRandomInt()%20 - 5;
				
				scores[0]++;
			}
			
		}

		// pallo kimpoo yl�- ja alareunasta		
		if(by<0) bys=-bys;
		if(by>getHeight()) bys=-bys;
		
		
	}

	// "random" funkkari, palauttaa arvon joka lasketaan y koordinaateista
	int getRandomInt()
	{
		int luku=ys[0]+ys[1]+by+5;

		//System.err.println("luku="+luku); 		


		return luku;
	}


}
