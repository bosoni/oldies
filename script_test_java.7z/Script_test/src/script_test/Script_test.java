//   http://viralpatel.net/blogs/java-dynamic-class-loading-java-reflection-api/

package script_test;
import java.lang.reflect.Method;

public class Script_test
{
    public static void main(String[] args)
    {
        
        System.out.println("> "+ RunScript("Room1", "Look", "door"));
        System.out.println("> "+ RunScript("Room1", "Take", "door"));
        System.out.println("> "+ RunScript("Room1", "Look", "gaa"));
        System.out.println("> "+ RunScript("Room2", "Look", "door"));
        System.out.println("> "+ RunScript("Room2", "Look", "ag"));
        System.out.println("> "+ RunScript("Room2", "Take", "door"));

    }
    
    public static String RunScript(String room, String action, String id)
    {
        System.out.println("Place["+room+"]: "+action+" "+id);
        
        try
        {
            ClassLoader myClassLoader = ClassLoader.getSystemClassLoader();

            // Step 2: Define a class to be loaded.
            String classNameToBeLoaded = "script_test."+room;

            // Step 3: Load the class
            Class myClass = myClassLoader.loadClass(classNameToBeLoaded);

            // Step 4: create a new instance of that class
            Object whatInstance = myClass.newInstance();

            // Step 5: get the method, with proper parameter signature.
            // The second parameter is the parameter type.
            // There can be multiple parameters for the method we are trying to call,
            // hence the use of array.
            Method myMethod = myClass.getMethod(action,
                    new Class[]
            {
                String.class
            });

            // Step 6:
            // Calling the real method. Passing methodParameter as
            // parameter. You can pass multiple parameters based on
            // the signature of the method you are calling. Hence
            // there is an array.
            String returnValue = (String) myMethod.invoke(whatInstance,
                    new Object[]
            {
                id
            });

            return returnValue;
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }        
        return "";
    }
    
}
