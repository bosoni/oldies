/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package script_test;

/**
 *
 * @author ogre
 */
public class ScriptBase
{
    public String Look(String id)
    {
        return "";
    }
    public String Take(String id)
    {
        return "";
    }
    public String Talk(String id)
    {
        return "";
    }
    public String Use(String id)
    {
        return "";
    }
}
