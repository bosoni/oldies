/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package script_test;

/**
 *
 * @author ogre
 */
public class Room1 extends ScriptBase
{
    @Override
    public String Look(String id)
    {
        if(id.equals("door"))
            return "It's the fucking door!";
        
        return "hä?";
    }
    
    @Override
    public String Take(String id)
    {
        if(id.equals("door"))
            return "Too heavy.";
        
        return "Cant take.";
    }

}
