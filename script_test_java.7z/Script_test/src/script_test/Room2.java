/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package script_test;

/**
 *
 * @author ogre
 */
public class Room2 extends ScriptBase
{
    @Override
    public String Look(String id)
    {
        if(id.equals("door"))
            return "Opened door!";
        
        return "wtf?";
    }
    
}
